"""
app_enhanced_ui.py - Enhanced UI for the Advanced Stock Scanner with sentiment analysis and price predictions
"""

import streamlit as st
import pandas as pd
import numpy as np
import datetime
import logging
import os
import sys
import time
from config.enhanced_config import get_config
from data_acquisition_enhanced import EnhancedDataAcquisition
from utils.sentiment_analysis import SentimentAnalysis
from utils.price_prediction import PricePrediction
from utils.technical_analysis_enhanced import EnhancedTechnicalAnalysis
from stock_list_500 import get_default_symbols

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("scanner_app.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('app')

# Initialize configuration
config = get_config()

# Initialize components
def initialize_components():
    logger.info("Initializing components...")
    
    # Initialize data acquisition
    data_acquisition = EnhancedDataAcquisition(config)
    
    # Initialize technical analysis
    technical_analysis = EnhancedTechnicalAnalysis(config)
    
    # Initialize sentiment analysis
    sentiment_analysis = SentimentAnalysis(config)
    
    # Initialize price prediction
    price_prediction = PricePrediction(config)
    
    logger.info("Components initialized successfully")
    
    return {
        'data_acquisition': data_acquisition,
        'technical_analysis': technical_analysis,
        'sentiment_analysis': sentiment_analysis,
        'price_prediction': price_prediction
    }

# Check data sources health
def check_data_sources(components):
    data_acquisition = components['data_acquisition']
    
    # Check Alpha Vantage
    alpha_vantage_status = "Available" if data_acquisition.check_alpha_vantage() else "Unavailable"
    
    # Check YFinance
    yfinance_status = "Available" if data_acquisition.check_yfinance() else "Unavailable"
    
    # Check Alpaca if configured
    alpaca_status = "Not Configured"
    if hasattr(data_acquisition, 'check_alpaca'):
        alpaca_status = "Available" if data_acquisition.check_alpaca() else "Unavailable"
    
    return {
        'Alpha Vantage': alpha_vantage_status,
        'YFinance': yfinance_status,
        'Alpaca': alpaca_status
    }

# Run scan for a single symbol
def scan_symbol(components, symbol, timeframe, start_date, end_date):
    try:
        # Get data
        data = components['data_acquisition'].get_symbol_data(symbol, timeframe, start_date, end_date)
        
        if data is None or data.empty:
            return None
        
        # Calculate technical indicators
        data = components['technical_analysis'].calculate_indicators(data)
        
        # Perform sentiment analysis
        data = components['sentiment_analysis'].analyze_sentiment(data)
        
        # Calculate price predictions
        data = components['price_prediction'].predict_prices(data)
        
        return data
    except Exception as e:
        logger.error(f"Error scanning symbol {symbol}: {e}")
        return None

# Run scan for multiple symbols
def run_scan(components, symbols, timeframe, start_date, end_date):
    results = {}
    
    # Use default symbols if none provided
    if not symbols:
        symbols = get_default_symbols()[:20]  # Limit to 20 for testing
    
    # Process each symbol
    for symbol in symbols:
        try:
            logger.info(f"Scanning {symbol}...")
            data = scan_symbol(components, symbol, timeframe, start_date, end_date)
            
            if data is not None and not data.empty:
                # Store only the latest data point for summary
                results[symbol] = data.iloc[-1].to_dict()
                logger.info(f"Scan completed for {symbol}")
            else:
                logger.warning(f"No data returned for {symbol}")
        except Exception as e:
            logger.error(f"Error processing {symbol}: {e}")
    
    return results

# Format sentiment with color
def format_sentiment(sentiment):
    if sentiment in ['Very Bullish', 'Bullish']:
        return f"<span style='color:green;font-weight:bold'>{sentiment}</span>"
    elif sentiment in ['Very Bearish', 'Bearish']:
        return f"<span style='color:red;font-weight:bold'>{sentiment}</span>"
    else:
        return f"<span style='color:gray'>{sentiment}</span>"

# Format evidence with color and style
def format_evidence(evidence):
    if 'Very Strong' in evidence:
        return f"<span style='color:darkblue;font-style:italic'>({evidence})</span>"
    elif 'Strong' in evidence:
        return f"<span style='color:blue;font-style:italic'>({evidence})</span>"
    else:
        return f"<span style='color:gray;font-style:italic'>({evidence})</span>"

# Format price with color based on comparison to current price
def format_price(price, current_price):
    if price > current_price * 1.05:
        return f"<span style='color:green;font-weight:bold'>${price:.2f}</span>"
    elif price < current_price * 0.95:
        return f"<span style='color:red;font-weight:bold'>${price:.2f}</span>"
    else:
        return f"<span style='color:black'>${price:.2f}</span>"

# Main app
def main():
    st.set_page_config(
        page_title="Advanced Stock Scanner",
        page_icon="📈",
        layout="wide"
    )
    
    st.title("Advanced Stock Scanner")
    
    # Initialize session state
    if 'components' not in st.session_state:
        st.session_state.components = initialize_components()
    
    if 'scan_results' not in st.session_state:
        st.session_state.scan_results = {}
    
    if 'data_sources' not in st.session_state:
        st.session_state.data_sources = {}
    
    if 'selected_symbol' not in st.session_state:
        st.session_state.selected_symbol = None
    
    # Sidebar
    with st.sidebar:
        st.header("Navigation")
        
        # Page selection
        page = st.selectbox("Select Page", ["Scanner"])
        
        # User info
        st.write("Logged in as: demo (demo)")
        
        # Offline mode toggle
        offline_mode = st.checkbox("Offline Mode")
        
        # Data source health check
        if st.button("Check Data Sources"):
            st.session_state.data_sources = check_data_sources(st.session_state.components)
        
        # Display data sources status
        if st.session_state.data_sources:
            st.subheader("Data Sources")
            for source, status in st.session_state.data_sources.items():
                if status == "Available":
                    st.success(f"{source}: {status}")
                else:
                    st.error(f"{source}: {status}")
        
        # Logout button
        st.button("Logout")
    
    # Main content
    col1, col2 = st.columns([1, 1])
    
    with col1:
        # Date range selection
        start_date = st.date_input("Start Date", datetime.datetime.now() - datetime.timedelta(days=30))
        symbols_input = st.text_area("Symbols (comma-separated, leave empty for default list)", "")
    
    with col2:
        # Date range selection
        end_date = st.date_input("End Date", datetime.datetime.now())
        timeframe = st.selectbox("Timeframe", ["1day", "1hour", "1week"], index=0)
    
    # Advanced settings
    with st.expander("Advanced Settings"):
        st.checkbox("Use Performance Optimization")
        st.checkbox("Technical Analysis Only")
        st.checkbox("Include Machine Learning Predictions")
        st.slider("Confidence Threshold", 0, 100, 50)
    
    # Run scan button
    if st.button("Run Scan"):
        # Parse symbols
        symbols = [s.strip() for s in symbols_input.split(',')] if symbols_input else []
        
        # Convert dates to string format
        start_date_str = start_date.strftime('%Y-%m-%d')
        end_date_str = end_date.strftime('%Y-%m-%d')
        
        with st.spinner("Running scan..."):
            # Run the scan
            st.session_state.scan_results = run_scan(
                st.session_state.components,
                symbols,
                timeframe,
                start_date_str,
                end_date_str
            )
    
    # Display scan results
    if st.session_state.scan_results:
        st.subheader("Scan Results")
        
        # Convert results to DataFrame for display
        results_df = pd.DataFrame.from_dict(st.session_state.scan_results, orient='index')
        
        # Create a summary table
        if not results_df.empty:
            summary_df = pd.DataFrame(index=results_df.index)
            
            # Add relevant columns
            summary_df['Symbol'] = summary_df.index
            summary_df['Last Price'] = results_df['close'].round(2)
            
            # Add sentiment columns if available
            if 'short_term_sentiment' in results_df.columns:
                summary_df['Short-Term'] = results_df['short_term_sentiment']
            
            if 'medium_term_sentiment' in results_df.columns:
                summary_df['Medium-Term'] = results_df['medium_term_sentiment']
            
            if 'long_term_sentiment' in results_df.columns:
                summary_df['Long-Term'] = results_df['long_term_sentiment']
            
            # Add price targets if available
            if 'price_target_1d' in results_df.columns:
                summary_df['1-Day Target'] = results_df['price_target_1d'].round(2)
            
            if 'price_target_1w' in results_df.columns:
                summary_df['1-Week Target'] = results_df['price_target_1w'].round(2)
            
            if 'price_target_1m' in results_df.columns:
                summary_df['1-Month Target'] = results_df['price_target_1m'].round(2)
            
            # Add buy/sell prices if available
            if 'buy_price' in results_df.columns:
                summary_df['Buy Price'] = results_df['buy_price'].round(2)
            
            if 'sell_price' in results_df.columns:
                summary_df['Sell Price'] = results_df['sell_price'].round(2)
            
            if 'stop_loss' in results_df.columns:
                summary_df['Stop Loss'] = results_df['stop_loss'].round(2)
            
            # Display the summary table
            st.dataframe(summary_df)
            
            # Symbol selection for detailed view
            selected_symbol = st.selectbox("Select Symbol for Detailed Analysis", summary_df.index.tolist())
            
            if selected_symbol:
                st.session_state.selected_symbol = selected_symbol
        else:
            st.warning("No scan results to display")
    else:
        st.info("Run a scan to see results")
    
    # Display detailed analysis for selected symbol
    if st.session_state.selected_symbol and st.session_state.selected_symbol in st.session_state.scan_results:
        st.header(f"Detailed Analysis: {st.session_state.selected_symbol}")
        
        symbol_data = st.session_state.scan_results[st.session_state.selected_symbol]
        
        # Create three columns for different timeframes
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.subheader("Technical Analysis")
            
            # Technical Outlook section
            st.markdown("### Technical Outlook")
            
            # Short-Term sentiment
            if 'short_term_sentiment' in symbol_data and 'short_term_evidence' in symbol_data:
                st.markdown(f"**Short-Term:** {format_sentiment(symbol_data['short_term_sentiment'])} {format_evidence(symbol_data['short_term_evidence'])}", unsafe_allow_html=True)
            
            # Medium-Term sentiment
            if 'medium_term_sentiment' in symbol_data and 'medium_term_evidence' in symbol_data:
                st.markdown(f"**Medium-Term:** {format_sentiment(symbol_data['medium_term_sentiment'])} {format_evidence(symbol_data['medium_term_evidence'])}", unsafe_allow_html=True)
            
            # Long-Term sentiment
            if 'long_term_sentiment' in symbol_data and 'long_term_evidence' in symbol_data:
                st.markdown(f"**Long-Term:** {format_sentiment(symbol_data['long_term_sentiment'])} {format_evidence(symbol_data['long_term_evidence'])}", unsafe_allow_html=True)
            
            # Key Technical Levels
            st.markdown("### Key Technical Levels")
            
            # Support level
            if 'support' in symbol_data:
                st.markdown(f"**Support:** ${symbol_data['support']:.2f}")
            
            # Resistance level
            if 'resistance' in symbol_data:
                st.markdown(f"**Resistance:** ${symbol_data['resistance']:.2f}")
            
            # Stop Loss
            if 'stop_loss' in symbol_data:
                st.markdown(f"**Stop Loss:** ${symbol_data['stop_loss']:.2f}")
        
        with col2:
            st.subheader("Price Predictions")
            
            current_price = symbol_data['close']
            
            # Price targets
            st.markdown("### Price Targets")
            
            # 1-Day target
            if 'price_target_1d' in symbol_data:
                st.markdown(f"**1-Day Target:** {format_price(symbol_data['price_target_1d'], current_price)}", unsafe_allow_html=True)
            
            # 1-Week target
            if 'price_target_1w' in symbol_data:
                st.markdown(f"**1-Week Target:** {format_price(symbol_data['price_target_1w'], current_price)}", unsafe_allow_html=True)
            
            # 1-Month target
            if 'price_target_1m' in symbol_data:
                st.markdown(f"**1-Month Target:** {format_price(symbol_data['price_target_1m'], current_price)}", unsafe_allow_html=True)
            
            # Expected movement
            st.markdown("### Expected Movement")
            
            # 1-Day movement
            if 'expected_movement_1d_pct' in symbol_data:
                movement = symbol_data['expected_movement_1d_pct']
                color = "green" if movement > 0 else "red"
                st.markdown(f"**1-Day:** <span style='color:{color}'>{movement:.2f}%</span>", unsafe_allow_html=True)
            
            # 1-Week movement
            if 'expected_movement_1w_pct' in symbol_data:
                movement = symbol_data['expected_movement_1w_pct']
                color = "green" if movement > 0 else "red"
                st.markdown(f"**1-Week:** <span style='color:{color}'>{movement:.2f}%</span>", unsafe_allow_html=True)
            
            # 1-Month movement
            if 'expected_movement_1m_pct' in symbol_data:
                movement = symbol_data['expected_movement_1m_pct']
                color = "green" if movement > 0 else "red"
                st.markdown(f"**1-Month:** <span style='color:{color}'>{movement:.2f}%</span>", unsafe_allow_html=True)
        
        with col3:
            st.subheader("Trading Recommendations")
            
            # Entry and exit points
            st.markdown("### Entry/Exit Points")
            
            # Buy price
            if 'buy_price' in symbol_data:
                st.markdown(f"**Buy Price:** ${symbol_data['buy_price']:.2f}")
            
            # Sell price
            if 'sell_price' in symbol_data:
                st.markdown(f"**Sell Price:** ${symbol_data['sell_price']:.2f}")
            
            # Risk/Reward ratio
            if 'buy_price' in symbol_data and 'sell_price' in symbol_data and 'stop_loss' in symbol_data:
                buy_price = symbol_data['buy_price']
                sell_price = symbol_data['sell_price']
                stop_loss = symbol_data['stop_loss']
                
                # Calculate risk/reward
                risk = abs(buy_price - stop_loss)
                reward = abs(sell_price - buy_price)
                
                if risk > 0:
                    risk_reward = reward / risk
                    st.markdown(f"**Risk/Reward Ratio:** {risk_reward:.2f}")
            
            # Confidence score
            if 'prediction_confidence' in symbol_data:
                confidence = symbol_data['prediction_confidence']
                
                # Color based on confidence level
                if confidence >= 70:
                    color = "green"
                elif confidence >= 50:
                    color = "orange"
                else:
                    color = "red"
                
                st.markdown(f"**Prediction Confidence:** <span style='color:{color}'>{confidence:.1f}%</span>", unsafe_allow_html=True)
            
            # Trading summary
            st.markdown("### Trading Summary")
            
            # Generate a trading summary based on all data
            if 'short_term_sentiment' in symbol_data:
                sentiment = symbol_data['short_term_sentiment']
                
                if sentiment in ['Very Bullish', 'Bullish']:
                    st.markdown("**Recommendation:** 🟢 **BUY**")
                    st.markdown("Look for entry points near the suggested buy price. Set stop loss as indicated to manage risk.")
                elif sentiment == 'Neutral':
                    st.markdown("**Recommendation:** 🟡 **HOLD/NEUTRAL**")
                    st.markdown("Market conditions are unclear. Wait for stronger signals before entering a position.")
                else:
                    st.markdown("**Recommendation:** 🔴 **SELL/AVOID**")
                    st.markdown("Current technical indicators suggest avoiding this stock or considering short positions.")

# Run the app
if __name__ == "__main__":
    main()
