"""
admin_panel_enhanced.py - Enhanced Admin Panel for the Advanced Stock Scanner
"""

import streamlit as st
import pandas as pd
import datetime
import logging
import os
import sys
import json
from config.enhanced_config import get_config
from utils.user_management import UserManagement
from utils.continuous_operation import ContinuousOperation
from data_acquisition_enhanced import EnhancedDataAcquisition
from utils.technical_analysis_enhanced import EnhancedTechnicalAnalysis
from utils.sentiment_analysis import SentimentAnalysis
from utils.price_prediction import PricePrediction

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("admin_panel.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('admin_panel')

# Initialize configuration
config = get_config()

# Initialize components
def initialize_components():
    logger.info("Initializing components...")
    
    # Initialize data acquisition
    data_acquisition = EnhancedDataAcquisition(config)
    
    # Initialize technical analysis
    technical_analysis = EnhancedTechnicalAnalysis(config)
    
    # Initialize sentiment analysis
    sentiment_analysis = SentimentAnalysis(config)
    
    # Initialize price prediction
    price_prediction = PricePrediction(config)
    
    # Initialize user management
    user_management = UserManagement(config)
    
    # Initialize continuous operation
    continuous_operation = ContinuousOperation(
        config, 
        data_acquisition, 
        technical_analysis, 
        sentiment_analysis, 
        price_prediction
    )
    
    logger.info("Components initialized successfully")
    
    return {
        'data_acquisition': data_acquisition,
        'technical_analysis': technical_analysis,
        'sentiment_analysis': sentiment_analysis,
        'price_prediction': price_prediction,
        'user_management': user_management,
        'continuous_operation': continuous_operation
    }

# Login page
def login_page():
    st.title("Admin Panel Login")
    
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    
    if st.button("Login"):
        if not username or not password:
            st.error("Please enter username and password")
            return False
        
        # Authenticate user
        success, result = st.session_state.components['user_management'].authenticate(username, password)
        
        if success:
            user_data = result["user"]
            session_id = result["session_id"]
            
            # Check if user is admin
            if user_data["role"] != "admin":
                st.error("Access denied. Admin privileges required.")
                return False
            
            # Store session data
            st.session_state.logged_in = True
            st.session_state.username = username
            st.session_state.session_id = session_id
            st.session_state.user_data = user_data
            
            st.success(f"Welcome, {username}!")
            return True
        else:
            st.error(result)
            return False
    
    return False

# User management page
def user_management_page():
    st.title("User Management")
    
    # Get users
    success, result = st.session_state.components['user_management'].get_users(st.session_state.session_id)
    
    if not success:
        st.error(result)
        return
    
    users = result
    
    # Display users
    st.subheader("Current Users")
    
    users_df = pd.DataFrame.from_dict(users, orient='index')
    st.dataframe(users_df)
    
    # Create new user
    st.subheader("Create New User")
    
    with st.form("create_user_form"):
        new_username = st.text_input("Username")
        new_password = st.text_input("Password", type="password")
        new_email = st.text_input("Email")
        new_role = st.selectbox("Role", ["user", "admin"])
        
        submit_button = st.form_submit_button("Create User")
        
        if submit_button:
            if not new_username or not new_password or not new_email:
                st.error("Please fill all fields")
                return
            
            # Create user
            success, message = st.session_state.components['user_management'].create_user(
                st.session_state.session_id,
                new_username,
                new_password,
                new_email,
                new_role
            )
            
            if success:
                st.success(message)
                st.experimental_rerun()
            else:
                st.error(message)
    
    # Update user
    st.subheader("Update User")
    
    with st.form("update_user_form"):
        update_username = st.selectbox("Select User", list(users.keys()))
        update_email = st.text_input("New Email", users[update_username]["email"])
        update_role = st.selectbox("New Role", ["user", "admin"], 0 if users[update_username]["role"] == "user" else 1)
        update_password = st.text_input("New Password (leave blank to keep current)", type="password")
        update_active = st.checkbox("Active", users[update_username]["is_active"])
        
        update_button = st.form_submit_button("Update User")
        
        if update_button:
            # Prepare update data
            update_data = {
                "email": update_email,
                "role": update_role,
                "is_active": update_active
            }
            
            # Add password if provided
            if update_password:
                update_data["password"] = update_password
            
            # Update user
            success, message = st.session_state.components['user_management'].update_user(
                st.session_state.session_id,
                update_username,
                **update_data
            )
            
            if success:
                st.success(message)
                st.experimental_rerun()
            else:
                st.error(message)
    
    # Delete user
    st.subheader("Delete User")
    
    with st.form("delete_user_form"):
        delete_username = st.selectbox("Select User to Delete", [u for u in list(users.keys()) if u != "admin"])
        
        delete_button = st.form_submit_button("Delete User")
        
        if delete_button:
            # Confirm deletion
            if st.checkbox(f"Confirm deletion of user '{delete_username}'"):
                # Delete user
                success, message = st.session_state.components['user_management'].delete_user(
                    st.session_state.session_id,
                    delete_username
                )
                
                if success:
                    st.success(message)
                    st.experimental_rerun()
                else:
                    st.error(message)
            else:
                st.warning("Please confirm deletion")

# Continuous operation page
def continuous_operation_page():
    st.title("Continuous Operation")
    
    # Get continuous operation status
    status_info = st.session_state.components['continuous_operation'].status()
    
    # Display status
    st.subheader("Current Status")
    
    status_text = "Running" if status_info["running"] else "Stopped"
    status_color = "green" if status_info["running"] else "red"
    
    st.markdown(f"**Status:** <span style='color:{status_color}'>{status_text}</span>", unsafe_allow_html=True)
    
    # Display next scheduled scans
    if status_info["running"] and status_info["next_scans"]:
        st.subheader("Next Scheduled Scans")
        
        for scan in status_info["next_scans"]:
            st.markdown(f"- {scan['job']} at {scan['next_run']}")
    
    # Start/Stop buttons
    col1, col2 = st.columns(2)
    
    with col1:
        if not status_info["running"]:
            if st.button("Start Continuous Operation"):
                success = st.session_state.components['continuous_operation'].start()
                
                if success:
                    st.success("Continuous operation started")
                    st.experimental_rerun()
                else:
                    st.error("Failed to start continuous operation")
    
    with col2:
        if status_info["running"]:
            if st.button("Stop Continuous Operation"):
                success = st.session_state.components['continuous_operation'].stop()
                
                if success:
                    st.success("Continuous operation stopped")
                    st.experimental_rerun()
                else:
                    st.error("Failed to stop continuous operation")
    
    # Schedule configuration
    st.subheader("Schedule Configuration")
    
    # Daily scan configuration
    st.markdown("### Daily Scan")
    
    daily_config = status_info["schedule"]["daily_scan"]
    
    daily_enabled = st.checkbox("Enable Daily Scan", daily_config["enabled"])
    daily_time = st.text_input("Time (HH:MM)", daily_config["time"])
    daily_days = st.multiselect(
        "Days",
        ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
        daily_config["days"]
    )
    daily_timeframe = st.selectbox("Timeframe", ["1day", "1hour", "1week"], 
                                  0 if daily_config["timeframe"] == "1day" else 
                                  1 if daily_config["timeframe"] == "1hour" else 2)
    daily_lookback = st.number_input("Lookback Days", min_value=1, max_value=365, value=daily_config["lookback_days"])
    
    if st.button("Update Daily Scan Configuration"):
        success = st.session_state.components['continuous_operation'].update_schedule(
            "daily_scan",
            enabled=daily_enabled,
            time=daily_time,
            days=daily_days,
            timeframe=daily_timeframe,
            lookback_days=daily_lookback
        )
        
        if success:
            st.success("Daily scan configuration updated")
            st.experimental_rerun()
        else:
            st.error("Failed to update daily scan configuration")
    
    # Weekly scan configuration
    st.markdown("### Weekly Scan")
    
    weekly_config = status_info["schedule"]["weekly_scan"]
    
    weekly_enabled = st.checkbox("Enable Weekly Scan", weekly_config["enabled"])
    weekly_day = st.selectbox(
        "Day",
        ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
        ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].index(weekly_config["day"])
    )
    weekly_time = st.text_input("Time (HH:MM)", weekly_config["time"], key="weekly_time")
    weekly_timeframe = st.selectbox("Timeframe", ["1day", "1hour", "1week"], 
                                   0 if weekly_config["timeframe"] == "1day" else 
                                   1 if weekly_config["timeframe"] == "1hour" else 2,
                                   key="weekly_timeframe")
    weekly_lookback = st.number_input("Lookback Days", min_value=1, max_value=365, value=weekly_config["lookback_days"], key="weekly_lookback")
    
    if st.button("Update Weekly Scan Configuration"):
        success = st.session_state.components['continuous_operation'].update_schedule(
            "weekly_scan",
            enabled=weekly_enabled,
            day=weekly_day,
            time=weekly_time,
            timeframe=weekly_timeframe,
            lookback_days=weekly_lookback
        )
        
        if success:
            st.success("Weekly scan configuration updated")
            st.experimental_rerun()
        else:
            st.error("Failed to update weekly scan configuration")
    
    # Manual scan
    st.subheader("Run Manual Scan")
    
    manual_timeframe = st.selectbox("Timeframe", ["1day", "1hour", "1week"])
    manual_lookback = st.number_input("Lookback Days", min_value=1, max_value=365, value=30)
    manual_symbols = st.text_input("Symbols (comma-separated, leave empty for default list)")
    
    if st.button("Run Manual Scan"):
        symbols = [s.strip() for s in manual_symbols.split(',')] if manual_symbols else None
        
        with st.spinner("Running scan..."):
            results = st.session_state.components['continuous_operation'].run_manual_scan(
                symbols=symbols,
                timeframe=manual_timeframe,
                lookback_days=manual_lookback
            )
        
        if results:
            st.success(f"Scan completed with {len(results)} results")
        else:
            st.warning("No results returned from scan")
    
    # Latest results
    st.subheader("Latest Results")
    
    result_timeframe = st.selectbox("Filter by Timeframe", ["All", "1day", "1hour", "1week"])
    
    if st.button("View Latest Results"):
        timeframe = None if result_timeframe == "All" else result_timeframe
        
        with st.spinner("Loading results..."):
            results = st.session_state.components['continuous_operation'].get_latest_results(timeframe)
        
        if results:
            # Convert results to DataFrame for display
            results_df = pd.DataFrame.from_dict(results, orient='index')
            
            # Create a summary table
            if not results_df.empty:
                summary_df = pd.DataFrame(index=results_df.index)
                
                # Add relevant columns
                summary_df['Symbol'] = summary_df.index
                summary_df['Last Price'] = results_df['close'].round(2)
                
                # Add sentiment columns if available
                if 'short_term_sentiment' in results_df.columns:
                    summary_df['Short-Term'] = results_df['short_term_sentiment']
                
                if 'medium_term_sentiment' in results_df.columns:
                    summary_df['Medium-Term'] = results_df['medium_term_sentiment']
                
                if 'long_term_sentiment' in results_df.columns:
                    summary_df['Long-Term'] = results_df['long_term_sentiment']
                
                # Add price targets if available
                if 'price_target_1d' in results_df.columns:
                    summary_df['1-Day Target'] = results_df['price_target_1d'].round(2)
                
                if 'price_target_1w' in results_df.columns:
                    summary_df['1-Week Target'] = results_df['price_target_1w'].round(2)
                
                if 'price_target_1m' in results_df.columns:
                    summary_df['1-Month Target'] = results_df['price_target_1m'].round(2)
                
                # Add buy/sell prices if available
                if 'buy_price' in results_df.columns:
                    summary_df['Buy Price'] = results_df['buy_price'].round(2)
                
                if 'sell_price' in results_df.columns:
                    summary_df['Sell Price'] = results_df['sell_price'].round(2)
                
                if 'stop_loss' in results_df.columns:
                    summary_df['Stop Loss'] = results_df['stop_loss'].round(2)
                
                # Display the summary table
                st.dataframe(summary_df)
            else:
                st.warning("No results to display")
        else:
            st.warning("No results found")

# System settings page
def system_settings_page():
    st.title("System Settings")
    
    # API configuration
    st.subheader("API Configuration")
    
    # Alpha Vantage API key
    alpha_vantage_key = config.get('alpha_vantage', {}).get('api_key', '')
    new_alpha_vantage_key = st.text_input("Alpha Vantage API Key", alpha_vantage_key)
    
    if st.button("Update Alpha Vantage API Key"):
        if new_alpha_vantage_key:
            # Update configuration
            config['alpha_vantage'] = {
                'api_key': new_alpha_vantage_key,
                'primary': True
            }
            
            # Save configuration
            config_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'user_config.json')
            try:
                with open(config_file, 'w') as f:
                    json.dump(config, f, indent=4)
                st.success("Alpha Vantage API key updated successfully")
            except Exception as e:
                st.error(f"Error saving configuration: {e}")
        else:
            st.warning("Please enter an API key")
    
    # Data source priority
    st.subheader("Data Source Priority")
    
    data_sources = ["alpha_vantage", "yfinance", "alpaca"]
    primary_source = st.selectbox(
        "Primary Data Source",
        data_sources,
        data_sources.index(next((s for s in data_sources if config.get(s, {}).get('primary', False)), data_sources[0]))
    )
    
    if st.button("Update Data Source Priority"):
        # Update configuration
        for source in data_sources:
            if source in config:
                config[source]['primary'] = (source == primary_source)
            else:
                config[source] = {'primary': (source == primary_source)}
        
        # Save configuration
        config_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'user_config.json')
        try:
            with open(config_file, 'w') as f:
                json.dump(config, f, indent=4)
            st.success("Data source priority updated successfully")
        except Exception as e:
            st.error(f"Error saving configuration: {e}")
    
    # Cache settings
    st.subheader("Cache Settings")
    
    cache_enabled = st.checkbox("Enable Data Caching", config.get('cache', {}).get('enabled', True))
    cache_expiry = st.number_input(
        "Cache Expiry (hours)",
        min_value=1,
        max_value=168,
        value=config.get('cache', {}).get('expiry_hours', 24)
    )
    
    if st.button("Update Cache Settings"):
        # Update configuration
        config['cache'] = {
            'enabled': cache_enabled,
            'expiry_hours': cache_expiry
        }
        
        # Save configuration
        config_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'user_config.json')
        try:
            with open(config_file, 'w') as f:
                json.dump(config, f, indent=4)
            st.success("Cache settings updated successfully")
        except Exception as e:
            st.error(f"Error saving configuration: {e}")
    
    # System information
    st.subheader("System Information")
    
    # Python version
    st.markdown(f"**Python Version:** {sys.version}")
    
    # Streamlit version
    import streamlit as st
    st.markdown(f"**Streamlit Version:** {st.__version__}")
    
    # Current directory
    st.markdown(f"**Current Directory:** {os.getcwd()}")
    
    # Data directory
    data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
    st.markdown(f"**Data Directory:** {data_dir}")
    
    # Cache directory
    cache_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'cache')
    st.markdown(f"**Cache Directory:** {cache_dir}")
    
    # Log files
    log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
    st.markdown(f"**Log Directory:** {log_dir}")
    
    # Clear cache button
    if st.button("Clear Cache"):
        try:
            # Get list of cache files
            cache_files = [f for f in os.listdir(cache_dir) if f.endswith('.pkl')]
            
            # Delete cache files
            for file in cache_files:
                os.remove(os.path.join(cache_dir, file))
            
            st.success(f"Cleared {len(cache_files)} cache files")
        except Exception as e:
            st.error(f"Error clearing cache: {e}")

# Main app
def main():
    st.set_page_config(
        page_title="Admin Panel",
        page_icon="🔧",
        layout="wide"
    )
    
    # Initialize session state
    if 'components' not in st.session_state:
        st.session_state.components = initialize_components()
    
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    
    # Login check
    if not st.session_state.logged_in:
        login_page()
        return
    
    # Sidebar
    st.sidebar.title("Admin Panel")
    
    # User info
    st.sidebar.write(f"Logged in as: {st.session_state.username} (admin)")
    
    # Page selection
    page = st.sidebar.selectbox(
        "Select Page",
        ["User Management", "Continuous Operation", "System Settings"]
    )
    
    # Logout button
    if st.sidebar.button("Logout"):
        # Logout user
        st.session_state.components['user_management'].logout(st.session_state.session_id)
        
        # Clear session state
        st.session_state.logged_in = False
        st.session_state.username = None
        st.session_state.session_id = None
        st.session_state.user_data = None
        
        st.experimental_rerun()
    
    # Display selected page
    if page == "User Management":
        user_management_page()
    elif page == "Continuous Operation":
        continuous_operation_page()
    elif page == "System Settings":
        system_settings_page()

# Run the app
if __name__ == "__main__":
    main()
