"""
app_enhanced.py - Enhanced Streamlit interface for the Advanced Stock Scanner with improved connectivity
"""

import streamlit as st
import pandas as pd
import numpy as np
import os
import datetime
import time
import json
import traceback
import logging
from datetime import datetime, timedelta
import threading
import socket
import requests
from io import StringIO

# Import modules
from data_acquisition_enhanced import EnhancedDataAcquisition
from utils.accuracy_optimizer import AccuracyOptimizer
from utils.technical_analysis_enhanced import EnhancedTechnicalAnalysis
from utils.machine_learning_enhanced import EnhancedMachineLearningEngine
from utils.performance_optimizer import PerformanceOptimizer
from scanner_enhanced import EnhancedStockScanner
from config.enhanced_config import get_config
from utils.watchlist import WatchlistManager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("scanner_app.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('app')

# Set page config
st.set_page_config(
    page_title="Advanced Stock Scanner",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
    
if 'username' not in st.session_state:
    st.session_state.username = None
    
if 'scanner_results' not in st.session_state:
    st.session_state.scanner_results = None
    
if 'selected_symbol' not in st.session_state:
    st.session_state.selected_symbol = None
    
if 'detailed_analysis' not in st.session_state:
    st.session_state.detailed_analysis = None
    
if 'portfolio' not in st.session_state:
    st.session_state.portfolio = []
    
if 'watchlist' not in st.session_state:
    st.session_state.watchlist = []
    
if 'alerts' not in st.session_state:
    st.session_state.alerts = []
    
if 'scan_error' not in st.session_state:
    st.session_state.scan_error = None
    
if 'data_sources_health' not in st.session_state:
    st.session_state.data_sources_health = {}
    
if 'offline_mode' not in st.session_state:
    st.session_state.offline_mode = False
    
if 'last_scan_time' not in st.session_state:
    st.session_state.last_scan_time = None
    
if 'scan_in_progress' not in st.session_state:
    st.session_state.scan_in_progress = False
    
if 'scan_progress' not in st.session_state:
    st.session_state.scan_progress = 0
    
if 'scan_thread' not in st.session_state:
    st.session_state.scan_thread = None

# Load configuration
config = get_config()

# Define user credentials (in a real app, this would be in a database)
users = {
    'admin': {
        'password': 'admin',
        'role': 'admin'
    },
    'user': {
        'password': 'user',
        'role': 'user'
    }
}

# Initialize components
@st.cache_resource
def initialize_components():
    """Initialize all components of the application"""
    try:
        logger.info("Initializing components...")
        
        # Initialize data acquisition
        data_acquisition = EnhancedDataAcquisition(config)
        
        # Initialize technical analysis
        technical_analysis = EnhancedTechnicalAnalysis(config)
        
        # Initialize machine learning
        machine_learning = EnhancedMachineLearningEngine(config)
        
        # Initialize performance optimizer
        performance_optimizer = PerformanceOptimizer(config)
        
        # Initialize scanner
        scanner = EnhancedStockScanner(config, data_acquisition, technical_analysis, machine_learning)
        
        # Initialize watchlist manager - FIX: Pass config parameter
        watchlist_manager = WatchlistManager(config)
        
        logger.info("Components initialized successfully")
        
        return {
            'data_acquisition': data_acquisition,
            'technical_analysis': technical_analysis,
            'machine_learning': machine_learning,
            'performance_optimizer': performance_optimizer,
            'scanner': scanner,
            'watchlist_manager': watchlist_manager
        }
    except Exception as e:
        logger.error(f"Error initializing components: {e}")
        st.error(f"Error initializing components: {e}")
        return None

# Check internet connectivity
def check_internet_connection():
    """Check if internet connection is available"""
    try:
        # Try to connect to Google's DNS server
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False

# Check data source health
def check_data_sources_health():
    """Check health of all data sources"""
    try:
        components = initialize_components()
        if components:
            data_acquisition = components['data_acquisition']
            health = data_acquisition.get_source_health()
            st.session_state.data_sources_health = health
            return health
        return {}
    except Exception as e:
        logger.error(f"Error checking data sources health: {e}")
        return {}

# Background scan function
def background_scan(symbols, timeframe, start_date, end_date, use_optimization):
    """Run scan in background thread"""
    try:
        st.session_state.scan_in_progress = True
        st.session_state.scan_progress = 10
        
        # Initialize components
        components = initialize_components()
        if not components:
            st.session_state.scan_error = "Failed to initialize components"
            st.session_state.scan_in_progress = False
            return
        
        scanner = components['scanner']
        
        # Update progress
        st.session_state.scan_progress = 30
        
        # Convert date strings to datetime objects if needed
        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
        if isinstance(end_date, str):
            end_date = datetime.strptime(end_date, '%Y-%m-%d')
        
        # Run scan
        try:
            st.session_state.scan_progress = 50
            results = scanner.scan(symbols, [timeframe], start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
            st.session_state.scan_progress = 90
            
            # Store results in session state
            st.session_state.scanner_results = results
            st.session_state.last_scan_time = datetime.now()
            st.session_state.scan_error = None
            
            # Update data sources health
            st.session_state.data_sources_health = components['data_acquisition'].get_source_health()
            
            logger.info(f"Scan completed with {len(results)} results")
        except Exception as e:
            logger.error(f"Error during scan: {e}")
            st.session_state.scan_error = str(e)
            st.session_state.scanner_results = None
    except Exception as e:
        logger.error(f"Error in background scan: {e}")
        st.session_state.scan_error = str(e)
        st.session_state.scanner_results = None
    finally:
        st.session_state.scan_in_progress = False
        st.session_state.scan_progress = 100

# Export results to CSV
def export_to_csv(results):
    """Export results to CSV"""
    if results is None or results.empty:
        return None
    
    csv = results.to_csv(index=False)
    return csv

# Export results to JSON
def export_to_json(results):
    """Export results to JSON"""
    if results is None or results.empty:
        return None
    
    return results.to_json(orient='records', date_format='iso')

# Login page
def login_page():
    st.title("Login to Advanced Stock Scanner")
    
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")
        
        if submit:
            if username in users and users[username]['password'] == password:
                st.session_state.logged_in = True
                st.session_state.username = username
                st.success(f"Welcome, {username}!")
                st.rerun()
            else:
                st.error("Invalid username or password")
    
    # Add demo mode option
    if st.button("Enter Demo Mode"):
        st.session_state.logged_in = True
        st.session_state.username = "demo"
        st.rerun()

# Main app
def main_app():
    # Check internet connectivity
    internet_available = check_internet_connection()
    
    # Update offline mode based on internet connectivity
    if not internet_available and not st.session_state.offline_mode:
        st.session_state.offline_mode = True
        st.warning("Internet connection not available. Switching to offline mode.")
    elif internet_available and st.session_state.offline_mode:
        # Don't automatically switch back to online mode
        pass
    
    # Sidebar
    with st.sidebar:
        st.title("Navigation")
        
        # Page selection
        page = st.selectbox(
            "Select Page",
            options=["Scanner", "Portfolio", "Watchlist", "Alerts", "Settings"]
        )
        
        # Display logged in user
        if st.session_state.username in users:
            st.write(f"Logged in as: {st.session_state.username} ({users[st.session_state.username]['role']})")
        else:
            st.write(f"Logged in as: {st.session_state.username} (demo)")
        
        # Offline mode toggle
        offline_mode = st.checkbox("Offline Mode", value=st.session_state.offline_mode)
        if offline_mode != st.session_state.offline_mode:
            st.session_state.offline_mode = offline_mode
            if offline_mode:
                st.info("Switched to offline mode. Only cached data will be used.")
            else:
                st.info("Switched to online mode. Live data will be fetched.")
        
        # Data sources health
        if st.button("Check Data Sources"):
            with st.spinner("Checking data sources..."):
                health = check_data_sources_health()
                
                st.subheader("Data Sources Health")
                for source, status in health.items():
                    if status['status'] == 'available':
                        st.success(f"{source}: {status['status']}")
                    elif status['status'] == 'degraded':
                        st.warning(f"{source}: {status['status']}")
                    elif status['status'] == 'unavailable' or status['status'] == 'error':
                        st.error(f"{source}: {status['status']}")
                    else:
                        st.info(f"{source}: {status['status']}")
        
        # Logout button
        if st.button("Logout"):
            st.session_state.logged_in = False
            st.session_state.username = None
            st.rerun()
    
    # Display selected page
    if page == "Scanner":
        scanner_page()
    elif page == "Portfolio":
        portfolio_page()
    elif page == "Watchlist":
        watchlist_page()
    elif page == "Alerts":
        alerts_page()
    elif page == "Settings":
        settings_page()

# Scanner page
def scanner_page():
    st.title("Advanced Stock Scanner")
    
    # Display any scan errors
    if st.session_state.scan_error:
        st.error(f"Scan Error: {st.session_state.scan_error}")
    
    # Scanner form
    with st.form("scanner_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            # Date range
            start_date = st.date_input(
                "Start Date",
                value=datetime.now() - timedelta(days=30)
            )
            
            # Symbol input
            symbols_input = st.text_area(
                "Symbols (comma-separated, leave empty for default list)",
                value="",
                help="Enter stock symbols separated by commas, or leave empty to use the default list"
            )
            
            # Offline mode notice
            if st.session_state.offline_mode:
                st.info("Running in offline mode. Only cached data will be used.")
        
        with col2:
            # End date
            end_date = st.date_input(
                "End Date",
                value=datetime.now()
            )
            
            # Timeframe selection
            timeframe = st.selectbox(
                "Timeframe",
                options=["1min", "5min", "15min", "30min", "1hour", "1day", "1week"],
                index=5,  # Default to 1day
                help="Select the timeframe for analysis"
            )
        
        # Advanced settings
        with st.expander("Advanced Settings"):
            # Performance optimization
            use_optimization = st.checkbox(
                "Use Performance Optimization",
                value=True,
                help="Enable performance optimization for faster scanning"
            )
            
            # Technical indicators
            st.subheader("Technical Indicators")
            
            # SMA parameters
            col1, col2 = st.columns(2)
            with col1:
                sma_fast = st.number_input(
                    "Fast SMA Period",
                    min_value=1,
                    max_value=50,
                    value=14,
                    help="Fast Simple Moving Average period"
                )
            
            with col2:
                sma_slow = st.number_input(
                    "Slow SMA Period",
                    min_value=1,
                    max_value=200,
                    value=40,
                    help="Slow Simple Moving Average period"
                )
            
            # RSI parameters
            col1, col2 = st.columns(2)
            with col1:
                rsi_period = st.number_input(
                    "RSI Period",
                    min_value=1,
                    max_value=50,
                    value=14,
                    help="Relative Strength Index period"
                )
            
            with col2:
                rsi_threshold = st.number_input(
                    "RSI Threshold",
                    min_value=1,
                    max_value=100,
                    value=30,
                    help="RSI threshold for oversold condition"
                )
        
        # Submit button
        submit = st.form_submit_button("Run Scan")
        
        if submit:
            # Parse symbols
            if symbols_input.strip():
                symbols = [s.strip().upper() for s in symbols_input.split(',')]
            else:
                symbols = config['data']['default_symbols']
            
            # Check if scan is already in progress
            if st.session_state.scan_in_progress:
                st.warning("Scan already in progress. Please wait.")
            else:
                # Start scan in background thread
                scan_thread = threading.Thread(
                    target=background_scan,
                    args=(symbols, timeframe, start_date, end_date, use_optimization)
                )
                scan_thread.daemon = True
                scan_thread.start()
                
                st.session_state.scan_thread = scan_thread
                st.rerun()
    
    # Display scan progress
    if st.session_state.scan_in_progress:
        st.progress(st.session_state.scan_progress / 100)
        st.info("Scan in progress... This may take a few minutes.")
        
        # Add refresh button
        if st.button("Refresh Status"):
            st.rerun()
    
    # Display results
    if st.session_state.scanner_results is not None:
        results = st.session_state.scanner_results
        
        # Display last scan time
        if st.session_state.last_scan_time:
            st.info(f"Last scan completed at: {st.session_state.last_scan_time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Display results count
        st.subheader(f"Scan Results: {len(results)} stocks found")
        
        # Filter options
        with st.expander("Filter Results"):
            col1, col2 = st.columns(2)
            
            with col1:
                # Signal type filter
                signal_types = ['All']
                if 'signal_type' in results.columns:
                    signal_types.extend(results['signal_type'].unique())
                
                signal_filter = st.selectbox(
                    "Signal Type",
                    options=signal_types,
                    index=0
                )
            
            with col2:
                # Confidence score filter
                min_confidence = st.slider(
                    "Minimum Confidence Score",
                    min_value=0.0,
                    max_value=1.0,
                    value=0.5,
                    step=0.1,
                    help="Minimum confidence score for signals"
                )
        
        # Apply filters
        filtered_results = results.copy()
        
        if signal_filter != 'All':
            filtered_results = filtered_results[filtered_results['signal_type'] == signal_filter]
        
        if 'confidence_score' in filtered_results.columns:
            filtered_results = filtered_results[filtered_results['confidence_score'] >= min_confidence]
        
        # Display filtered results
        st.subheader(f"Filtered Results: {len(filtered_results)} stocks")
        
        # Display results table
        if not filtered_results.empty:
            # Select columns to display
            display_columns = ['symbol', 'signal_type', 'confidence_score', 'close']
            
            # Add additional columns if available
            for col in ['rsi', 'macd', 'trend_direction']:
                if col in filtered_results.columns:
                    display_columns.append(col)
            
            # Display table
            st.dataframe(filtered_results[display_columns])
            
            # Add export options
            col1, col2 = st.columns(2)
            
            with col1:
                if st.button("Export to CSV"):
                    csv = export_to_csv(filtered_results)
                    if csv:
                        st.download_button(
                            label="Download CSV",
                            data=csv,
                            file_name=f"scan_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                            mime="text/csv"
                        )
            
            with col2:
                if st.button("Export to JSON"):
                    json_data = export_to_json(filtered_results)
                    if json_data:
                        st.download_button(
                            label="Download JSON",
                            data=json_data,
                            file_name=f"scan_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                            mime="application/json"
                        )
            
            # Symbol selection for detailed analysis
            st.subheader("Detailed Analysis")
            
            selected_symbol = st.selectbox(
                "Select Symbol for Detailed Analysis",
                options=filtered_results['symbol'].unique()
            )
            
            if st.button("Analyze Symbol"):
                st.session_state.selected_symbol = selected_symbol
                
                # Get detailed analysis
                try:
                    components = initialize_components()
                    if components:
                        scanner = components['scanner']
                        
                        with st.spinner(f"Analyzing {selected_symbol}..."):
                            analysis = scanner.get_detailed_analysis(
                                selected_symbol,
                                [timeframe],
                                start_date.strftime('%Y-%m-%d'),
                                end_date.strftime('%Y-%m-%d')
                            )
                            
                            st.session_state.detailed_analysis = analysis
                            st.rerun()
                except Exception as e:
                    st.error(f"Error analyzing {selected_symbol}: {e}")
            
            # Display detailed analysis
            if st.session_state.detailed_analysis and st.session_state.selected_symbol == selected_symbol:
                analysis = st.session_state.detailed_analysis
                
                # Display summary
                st.subheader(f"Analysis Summary for {analysis['symbol']}")
                
                # Display signal and confidence
                col1, col2 = st.columns(2)
                
                with col1:
                    st.metric("Signal", analysis['summary'].get('signal', 'Neutral'))
                
                with col2:
                    st.metric("Confidence", f"{analysis['summary'].get('confidence', 0.5):.2f}")
                
                # Display trend information
                if 'trend' in analysis['summary']:
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.metric("Trend Direction", analysis['summary']['trend'].get('direction', 'Neutral'))
                    
                    with col2:
                        st.metric("Trend Strength", f"{analysis['summary']['trend'].get('strength', 0):.2f}")
                
                # Display support and resistance
                if 'support_resistance' in analysis['summary']:
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Support", f"${analysis['summary']['support_resistance'].get('support', 0):.2f}")
                    
                    with col2:
                        st.metric("Current Price", f"${analysis['latest'].get('close', 0):.2f}")
                    
                    with col3:
                        st.metric("Resistance", f"${analysis['summary']['support_resistance'].get('resistance', 0):.2f}")
                
                # Display technical indicators
                if 'indicators' in analysis['summary']:
                    st.subheader("Technical Indicators")
                    
                    indicators = analysis['summary']['indicators']
                    cols = st.columns(len(indicators))
                    
                    for i, (indicator, value) in enumerate(indicators.items()):
                        with cols[i]:
                            st.metric(indicator.upper(), f"{value:.2f}")
                
                # Display price targets
                if 'price_targets' in analysis['summary']:
                    st.subheader("Price Targets")
                    
                    targets = analysis['summary']['price_targets']
                    cols = st.columns(len(targets))
                    
                    for i, (period, target) in enumerate(targets.items()):
                        with cols[i]:
                            st.metric(
                                f"{period} Target",
                                f"${target.get('price', 0):.2f}",
                                f"{target.get('change', 0):.2f}%"
                            )
                
                # Display risk/reward ratio
                if 'risk_reward_ratio' in analysis['summary']:
                    st.metric("Risk/Reward Ratio", f"{analysis['summary']['risk_reward_ratio']:.2f}")
                
                # Display chart
                if 'data' in analysis and not analysis['data'].empty:
                    st.subheader("Price Chart")
                    
                    # Prepare chart data
                    chart_data = analysis['data'][['close']].copy()
                    
                    # Add SMA if available
                    for col in ['sma_14', 'sma_40']:
                        if col in analysis['data'].columns:
                            chart_data[col] = analysis['data'][col]
                    
                    # Display chart
                    st.line_chart(chart_data)
                    
                    # Display additional charts
                    with st.expander("Additional Charts"):
                        # RSI chart
                        if 'rsi' in analysis['data'].columns:
                            st.subheader("RSI Chart")
                            rsi_data = analysis['data'][['rsi']].copy()
                            
                            # Add overbought/oversold lines
                            rsi_data['Overbought (70)'] = 70
                            rsi_data['Oversold (30)'] = 30
                            
                            st.line_chart(rsi_data)
                        
                        # MACD chart
                        if all(col in analysis['data'].columns for col in ['macd', 'macd_signal']):
                            st.subheader("MACD Chart")
                            macd_data = analysis['data'][['macd', 'macd_signal']].copy()
                            st.line_chart(macd_data)
                
                # Add to watchlist button
                if st.button("Add to Watchlist"):
                    try:
                        components = initialize_components()
                        if components:
                            watchlist_manager = components['watchlist_manager']
                            
                            if watchlist_manager.add_to_watchlist(st.session_state.username, selected_symbol):
                                st.success(f"{selected_symbol} added to watchlist")
                                
                                # Update watchlist in session state
                                st.session_state.watchlist = watchlist_manager.get_watchlist(st.session_state.username)
                            else:
                                st.error(f"Failed to add {selected_symbol} to watchlist")
                    except Exception as e:
                        st.error(f"Error adding to watchlist: {e}")
        else:
            st.info("No results match the selected filters")
    else:
        st.info("Run a scan to see results")

# Portfolio page
def portfolio_page():
    st.title("Portfolio")
    st.info("Portfolio functionality coming soon")

# Watchlist page
def watchlist_page():
    st.title("Watchlist")
    
    # Initialize components
    components = initialize_components()
    if not components:
        st.error("Failed to initialize components")
        return
    
    watchlist_manager = components['watchlist_manager']
    
    # Get watchlist
    watchlist = watchlist_manager.get_watchlist(st.session_state.username)
    st.session_state.watchlist = watchlist
    
    # Display watchlist
    if watchlist:
        st.subheader(f"Watchlist: {len(watchlist)} symbols")
        
        # Display symbols
        for symbol in watchlist:
            col1, col2 = st.columns([4, 1])
            
            with col1:
                st.write(symbol)
            
            with col2:
                if st.button("Remove", key=f"remove_{symbol}"):
                    if watchlist_manager.remove_from_watchlist(st.session_state.username, symbol):
                        st.success(f"{symbol} removed from watchlist")
                        
                        # Update watchlist in session state
                        st.session_state.watchlist = watchlist_manager.get_watchlist(st.session_state.username)
                        st.rerun()
                    else:
                        st.error(f"Failed to remove {symbol} from watchlist")
        
        # Add scan watchlist button
        if st.button("Scan Watchlist"):
            # Check if scan is already in progress
            if st.session_state.scan_in_progress:
                st.warning("Scan already in progress. Please wait.")
            else:
                # Start scan in background thread
                scan_thread = threading.Thread(
                    target=background_scan,
                    args=(watchlist, "1day", datetime.now() - timedelta(days=30), datetime.now(), True)
                )
                scan_thread.daemon = True
                scan_thread.start()
                
                st.session_state.scan_thread = scan_thread
                st.rerun()
        
        # Clear watchlist button
        if st.button("Clear Watchlist"):
            if watchlist_manager.clear_watchlist(st.session_state.username):
                st.success("Watchlist cleared")
                
                # Update watchlist in session state
                st.session_state.watchlist = []
                st.rerun()
            else:
                st.error("Failed to clear watchlist")
    else:
        st.info("Your watchlist is empty")
    
    # Add symbol form
    with st.form("add_symbol_form"):
        symbol = st.text_input("Symbol").strip().upper()
        submit = st.form_submit_button("Add Symbol")
        
        if submit and symbol:
            if watchlist_manager.add_to_watchlist(st.session_state.username, symbol):
                st.success(f"{symbol} added to watchlist")
                
                # Update watchlist in session state
                st.session_state.watchlist = watchlist_manager.get_watchlist(st.session_state.username)
                st.rerun()
            else:
                st.error(f"Failed to add {symbol} to watchlist")

# Alerts page
def alerts_page():
    st.title("Alerts")
    st.info("Alerts functionality coming soon")

# Settings page
def settings_page():
    st.title("Settings")
    
    # Get current config
    current_config = config.copy()
    
    # Data sources
    st.subheader("Data Sources")
    
    # Primary data source
    primary_source = st.selectbox(
        "Primary Data Source",
        options=["yfinance", "alpha_vantage", "alpaca", "datasource_api"],
        index=0 if current_config['data']['primary_source'] == "yfinance" else
              1 if current_config['data']['primary_source'] == "alpha_vantage" else
              2 if current_config['data']['primary_source'] == "alpaca" else 3
    )
    
    # Backup data source
    backup_source = st.selectbox(
        "Backup Data Source",
        options=["None", "yfinance", "alpha_vantage", "alpaca", "datasource_api"],
        index=0 if not current_config['data']['backup_source'] else
              1 if current_config['data']['backup_source'] == "yfinance" else
              2 if current_config['data']['backup_source'] == "alpha_vantage" else
              3 if current_config['data']['backup_source'] == "alpaca" else 4
    )
    
    # API keys
    st.subheader("API Keys")
    
    # Alpha Vantage API key
    alpha_vantage_key = st.text_input(
        "Alpha Vantage API Key",
        value=current_config['data']['api_keys']['alpha_vantage']['api_key'],
        type="password"
    )
    
    # Alpaca API keys
    alpaca_api_key = st.text_input(
        "Alpaca API Key",
        value=current_config['data']['api_keys']['alpaca']['api_key'],
        type="password"
    )
    
    alpaca_api_secret = st.text_input(
        "Alpaca API Secret",
        value=current_config['data']['api_keys']['alpaca']['api_secret'],
        type="password"
    )
    
    # Cache settings
    st.subheader("Cache Settings")
    
    cache_expiry_hours = st.number_input(
        "Cache Expiry (hours)",
        min_value=1,
        max_value=72,
        value=current_config['data'].get('cache_expiry_hours', 24)
    )
    
    # Clear cache button
    if st.button("Clear Cache"):
        try:
            components = initialize_components()
            if components:
                data_acquisition = components['data_acquisition']
                data_acquisition.clear_cache()
                st.success("Cache cleared successfully")
        except Exception as e:
            st.error(f"Error clearing cache: {e}")
    
    # Save settings button
    if st.button("Save Settings"):
        try:
            # Update config
            current_config['data']['primary_source'] = primary_source
            current_config['data']['backup_source'] = None if backup_source == "None" else backup_source
            current_config['data']['api_keys']['alpha_vantage']['api_key'] = alpha_vantage_key
            current_config['data']['api_keys']['alpaca']['api_key'] = alpaca_api_key
            current_config['data']['api_keys']['alpaca']['api_secret'] = alpaca_api_secret
            current_config['data']['cache_expiry_hours'] = cache_expiry_hours
            
            # Save to file
            config_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config')
            user_config_path = os.path.join(config_dir, 'user_config.json')
            
            with open(user_config_path, 'w') as f:
                json.dump(current_config, f, indent=4)
            
            st.success("Settings saved successfully. Please restart the application for changes to take effect.")
        except Exception as e:
            st.error(f"Error saving settings: {e}")
    
    # Advanced settings
    with st.expander("Advanced Settings"):
        # Performance settings
        st.subheader("Performance Settings")
        
        use_multithreading = st.checkbox(
            "Use Multithreading",
            value=current_config['performance'].get('use_multithreading', True)
        )
        
        use_multiprocessing = st.checkbox(
            "Use Multiprocessing",
            value=current_config['performance'].get('use_multiprocessing', False)
        )
        
        max_workers = st.number_input(
            "Max Workers",
            min_value=1,
            max_value=16,
            value=current_config['performance'].get('max_workers', 4)
        )
        
        # Save advanced settings button
        if st.button("Save Advanced Settings"):
            try:
                # Update config
                current_config['performance']['use_multithreading'] = use_multithreading
                current_config['performance']['use_multiprocessing'] = use_multiprocessing
                current_config['performance']['max_workers'] = max_workers
                
                # Save to file
                config_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config')
                user_config_path = os.path.join(config_dir, 'user_config.json')
                
                with open(user_config_path, 'w') as f:
                    json.dump(current_config, f, indent=4)
                
                st.success("Advanced settings saved successfully. Please restart the application for changes to take effect.")
            except Exception as e:
                st.error(f"Error saving advanced settings: {e}")

# Main function
def main():
    if not st.session_state.logged_in:
        login_page()
    else:
        main_app()

if __name__ == "__main__":
    main()
