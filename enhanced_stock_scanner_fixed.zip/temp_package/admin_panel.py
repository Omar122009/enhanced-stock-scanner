"""
admin_panel.py - Admin panel for the Advanced Stock Scanner
"""

import streamlit as st
import pandas as pd
import os
import sys
import json
from utils.auth import AuthManager

class AdminPanel:
    """
    Admin panel for user management and system settings
    """
    
    def __init__(self, config):
        """
        Initialize the admin panel
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        self.auth_manager = AuthManager(config)
        
        # Setup config directory
        self.config_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config')
        os.makedirs(self.config_dir, exist_ok=True)
        
        # User config file
        self.user_config_file = os.path.join(self.config_dir, 'user_config.json')
    
    def render(self):
        """Render the admin panel"""
        st.title("Admin Panel")
        
        # Check if user is logged in and is admin
        if 'token' not in st.session_state:
            st.warning("Please log in first")
            return
        
        is_valid, username, role = self.auth_manager.validate_token(st.session_state['token'])
        
        if not is_valid:
            st.warning("Your session has expired. Please log in again.")
            return
        
        if role != 'admin':
            st.error("You don't have permission to access the admin panel")
            return
        
        # Admin panel tabs
        tabs = st.tabs(["User Management", "System Settings", "Scanner Configuration"])
        
        # User Management tab
        with tabs[0]:
            self._render_user_management(username)
        
        # System Settings tab
        with tabs[1]:
            self._render_system_settings()
        
        # Scanner Configuration tab
        with tabs[2]:
            self._render_scanner_configuration()
    
    def _render_user_management(self, admin_username):
        """Render user management section"""
        st.header("User Management")
        
        # Get all users
        users = self.auth_manager.get_all_users(admin_username)
        
        # Convert to DataFrame for display
        if users:
            users_df = pd.DataFrame(users)
            st.dataframe(users_df)
        else:
            st.info("No users found")
        
        # Add new user section
        st.subheader("Add New User")
        with st.form("add_user_form"):
            new_username = st.text_input("Username")
            new_password = st.text_input("Password", type="password")
            new_role = st.selectbox("Role", ["user", "admin"])
            
            submit_button = st.form_submit_button("Add User")
            
            if submit_button:
                if new_username and new_password:
                    success = self.auth_manager.register_user(new_username, new_password, new_role)
                    if success:
                        st.success(f"User {new_username} added successfully")
                        st.rerun()
                    else:
                        st.error(f"Failed to add user {new_username}")
                else:
                    st.warning("Please enter username and password")
        
        # Manage existing users
        st.subheader("Manage Users")
        
        # Select user to manage
        selected_username = st.selectbox(
            "Select User",
            [user['username'] for user in users if user['username'] != admin_username],
            index=None
        )
        
        if selected_username:
            # Get user info
            user_info = self.auth_manager.get_user_info(selected_username)
            
            if user_info:
                st.write(f"Username: {user_info['username']}")
                st.write(f"Role: {user_info['role']}")
                st.write(f"Created: {user_info['created_at']}")
                st.write(f"Last Login: {user_info['last_login'] or 'Never'}")
                
                # User actions
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if user_info['role'] == 'admin':
                        if st.button("Demote to User"):
                            success = self.auth_manager.demote_from_admin(selected_username, admin_username)
                            if success:
                                st.success(f"User {selected_username} demoted to user")
                                st.rerun()
                            else:
                                st.error(f"Failed to demote user {selected_username}")
                    else:
                        if st.button("Promote to Admin"):
                            success = self.auth_manager.promote_to_admin(selected_username, admin_username)
                            if success:
                                st.success(f"User {selected_username} promoted to admin")
                                st.rerun()
                            else:
                                st.error(f"Failed to promote user {selected_username}")
                
                with col2:
                    if st.button("Reset Password"):
                        new_password = "password123"  # Default reset password
                        # We need to implement a method to reset password without old password
                        # For now, we'll just show a message
                        st.info(f"Password reset functionality would be implemented here")
                
                with col3:
                    if st.button("Delete User"):
                        success = self.auth_manager.delete_user(selected_username, admin_username)
                        if success:
                            st.success(f"User {selected_username} deleted")
                            st.rerun()
                        else:
                            st.error(f"Failed to delete user {selected_username}")
    
    def _render_system_settings(self):
        """Render system settings section"""
        st.header("System Settings")
        
        # Load current settings
        settings = self._load_settings()
        
        # System settings form
        with st.form("system_settings_form"):
            # Performance settings
            st.subheader("Performance Settings")
            
            use_multithreading = st.checkbox("Use Multithreading", value=settings.get('performance', {}).get('use_multithreading', True))
            use_multiprocessing = st.checkbox("Use Multiprocessing", value=settings.get('performance', {}).get('use_multiprocessing', False))
            max_workers = st.number_input("Max Workers", min_value=1, max_value=32, value=settings.get('performance', {}).get('max_workers', 4))
            chunk_size = st.number_input("Chunk Size", min_value=1, max_value=100, value=settings.get('performance', {}).get('chunk_size', 10))
            use_caching = st.checkbox("Use Caching", value=settings.get('performance', {}).get('use_caching', True))
            
            # Data settings
            st.subheader("Data Settings")
            
            default_timeframe = st.selectbox(
                "Default Timeframe",
                ["1min", "5min", "15min", "30min", "60min", "1day", "1week", "1month"],
                index=["1min", "5min", "15min", "30min", "60min", "1day", "1week", "1month"].index(settings.get('data', {}).get('default_timeframe', "1day"))
            )
            
            default_period = st.selectbox(
                "Default Period",
                ["1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "10y", "ytd", "max"],
                index=["1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "10y", "ytd", "max"].index(settings.get('data', {}).get('default_period', "1y"))
            )
            
            # Save settings
            submit_button = st.form_submit_button("Save Settings")
            
            if submit_button:
                # Update settings
                settings['performance'] = {
                    'use_multithreading': use_multithreading,
                    'use_multiprocessing': use_multiprocessing,
                    'max_workers': max_workers,
                    'chunk_size': chunk_size,
                    'use_caching': use_caching
                }
                
                settings['data'] = {
                    'default_timeframe': default_timeframe,
                    'default_period': default_period
                }
                
                # Save settings
                success = self._save_settings(settings)
                
                if success:
                    st.success("Settings saved successfully")
                else:
                    st.error("Failed to save settings")
    
    def _render_scanner_configuration(self):
        """Render scanner configuration section"""
        st.header("Scanner Configuration")
        
        # Load current settings
        settings = self._load_settings()
        
        # Scanner configuration form
        with st.form("scanner_config_form"):
            # Technical analysis settings
            st.subheader("Technical Analysis Settings")
            
            # SMA periods
            sma_periods_str = st.text_input(
                "SMA Periods (comma-separated)",
                value=",".join(map(str, settings.get('technical_analysis', {}).get('sma_periods', [14, 40])))
            )
            
            # RSI settings
            rsi_period = st.number_input(
                "RSI Period",
                min_value=1,
                max_value=100,
                value=settings.get('technical_analysis', {}).get('rsi_period', 14)
            )
            
            rsi_overbought = st.number_input(
                "RSI Overbought Level",
                min_value=50,
                max_value=100,
                value=settings.get('technical_analysis', {}).get('rsi_overbought', 70)
            )
            
            rsi_oversold = st.number_input(
                "RSI Oversold Level",
                min_value=0,
                max_value=50,
                value=settings.get('technical_analysis', {}).get('rsi_oversold', 30)
            )
            
            # MACD settings
            macd_periods_str = st.text_input(
                "MACD Periods (fast,slow,signal)",
                value=",".join(map(str, settings.get('technical_analysis', {}).get('macd_periods', [12, 26, 9])))
            )
            
            # Bollinger Bands settings
            bollinger_periods = st.number_input(
                "Bollinger Bands Period",
                min_value=1,
                max_value=100,
                value=settings.get('technical_analysis', {}).get('bollinger_periods', 20)
            )
            
            bollinger_std = st.number_input(
                "Bollinger Bands Standard Deviation",
                min_value=0.1,
                max_value=5.0,
                value=settings.get('technical_analysis', {}).get('bollinger_std', 2.0),
                step=0.1
            )
            
            # Machine learning settings
            st.subheader("Machine Learning Settings")
            
            use_machine_learning = st.checkbox(
                "Use Machine Learning",
                value=settings.get('machine_learning', {}).get('use_machine_learning', True)
            )
            
            confidence_threshold = st.slider(
                "Confidence Threshold",
                min_value=0,
                max_value=100,
                value=settings.get('machine_learning', {}).get('confidence_threshold', 60)
            )
            
            # Scanner settings
            st.subheader("Scanner Settings")
            
            max_stocks = st.number_input(
                "Maximum Stocks to Scan",
                min_value=1,
                max_value=1000,
                value=settings.get('scanner', {}).get('max_stocks', 500)
            )
            
            batch_size = st.number_input(
                "Batch Size",
                min_value=1,
                max_value=100,
                value=settings.get('scanner', {}).get('batch_size', 50)
            )
            
            # Save settings
            submit_button = st.form_submit_button("Save Configuration")
            
            if submit_button:
                try:
                    # Parse SMA periods
                    sma_periods = [int(p.strip()) for p in sma_periods_str.split(",")]
                    
                    # Parse MACD periods
                    macd_periods = [int(p.strip()) for p in macd_periods_str.split(",")]
                    if len(macd_periods) != 3:
                        st.error("MACD periods must be 3 comma-separated values")
                        return
                    
                    # Update settings
                    settings['technical_analysis'] = {
                        'sma_periods': sma_periods,
                        'rsi_period': rsi_period,
                        'rsi_overbought': rsi_overbought,
                        'rsi_oversold': rsi_oversold,
                        'macd_periods': macd_periods,
                        'bollinger_periods': bollinger_periods,
                        'bollinger_std': bollinger_std
                    }
                    
                    settings['machine_learning'] = {
                        'use_machine_learning': use_machine_learning,
                        'confidence_threshold': confidence_threshold
                    }
                    
                    settings['scanner'] = {
                        'max_stocks': max_stocks,
                        'batch_size': batch_size
                    }
                    
                    # Save settings
                    success = self._save_settings(settings)
                    
                    if success:
                        st.success("Configuration saved successfully")
                    else:
                        st.error("Failed to save configuration")
                except Exception as e:
                    st.error(f"Error saving configuration: {e}")
    
    def _load_settings(self):
        """Load settings from file"""
        if os.path.exists(self.user_config_file):
            try:
                with open(self.user_config_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                st.error(f"Error loading settings: {e}")
                return {}
        else:
            return {}
    
    def _save_settings(self, settings):
        """Save settings to file"""
        try:
            with open(self.user_config_file, 'w') as f:
                json.dump(settings, f, indent=4)
            return True
        except Exception as e:
            st.error(f"Error saving settings: {e}")
            return False
