"""
test_fixed_scanner.py - Test script for the fixed enhanced stock scanner
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import json

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('test_scanner')

# Import modules
from data_acquisition_enhanced import EnhancedDataAcquisition
from utils.technical_analysis_enhanced import EnhancedTechnicalAnalysis
from utils.machine_learning_enhanced import EnhancedMachineLearningEngine
from scanner_enhanced_fixed import EnhancedStockScanner
from config.enhanced_config import get_config
from utils.integration_manager import IntegrationManager

def test_fixed_scanner():
    """Test the fixed enhanced scanner"""
    logger.info("Testing fixed enhanced scanner...")
    
    # Get configuration
    config = get_config()
    
    # Initialize components
    data_acquisition = EnhancedDataAcquisition(config)
    technical_analysis = EnhancedTechnicalAnalysis(config)
    machine_learning = EnhancedMachineLearningEngine(config)
    scanner = EnhancedStockScanner(config, data_acquisition, technical_analysis, machine_learning)
    
    # Test scanning a small list of symbols
    symbols = ["AAPL", "MSFT", "GOOGL"]
    timeframe = "1day"
    
    # Get date range
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    
    try:
        logger.info(f"Scanning {symbols} with timeframe {timeframe}...")
        results = scanner.scan(symbols, [timeframe], start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
        
        if results is not None and not results.empty:
            logger.info(f"Successfully scanned {len(results)} symbols")
            logger.info(f"Results columns: {results.columns.tolist()}")
            
            # Check if results have expected columns
            expected_columns = ['symbol', 'timeframe', 'close', 'signal_type', 'confidence_score']
            missing_columns = []
            for col in expected_columns:
                if col not in results.columns:
                    missing_columns.append(col)
                    logger.warning(f"Missing expected column {col} in results")
            
            if missing_columns:
                logger.error(f"Missing required columns: {missing_columns}")
                return False
            
            logger.info("All required columns present in results")
            return True
        else:
            logger.error("No results from scanner")
            return False
    except Exception as e:
        logger.error(f"Error testing scanner: {e}")
        return False

def test_integration_with_fixed_scanner():
    """Test integration with the fixed scanner"""
    logger.info("Testing integration with fixed scanner...")
    
    # Get configuration
    config = get_config()
    
    # Initialize components
    data_acquisition = EnhancedDataAcquisition(config)
    technical_analysis = EnhancedTechnicalAnalysis(config)
    machine_learning = EnhancedMachineLearningEngine(config)
    scanner = EnhancedStockScanner(config, data_acquisition, technical_analysis, machine_learning)
    integration_manager = IntegrationManager(config, data_acquisition, technical_analysis, machine_learning, scanner)
    
    # Test running scan with retry
    symbols = ["AAPL", "MSFT", "GOOGL"]
    timeframe = "1day"
    
    # Get date range
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    
    try:
        logger.info(f"Running scan with retry for {symbols}...")
        results = integration_manager.run_scan_with_retry(symbols, [timeframe], start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
        
        if results is not None and not results.empty:
            logger.info(f"Successfully ran scan with retry for {len(results)} symbols")
            logger.info(f"Results columns: {results.columns.tolist()}")
            
            # Check if results have expected columns
            expected_columns = ['symbol', 'timeframe', 'close', 'signal_type', 'confidence_score']
            missing_columns = []
            for col in expected_columns:
                if col not in results.columns:
                    missing_columns.append(col)
                    logger.warning(f"Missing expected column {col} in results")
            
            if missing_columns:
                logger.error(f"Missing required columns: {missing_columns}")
                return False
            
            logger.info("All required columns present in results")
            
            # Test getting detailed analysis
            logger.info("Getting detailed analysis for AAPL...")
            analysis = integration_manager.get_detailed_analysis_with_retry("AAPL", [timeframe], start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
            
            if analysis and 'symbol' in analysis and analysis['symbol'] == "AAPL":
                logger.info("Successfully got detailed analysis for AAPL")
                return True
            else:
                logger.error("Failed to get detailed analysis for AAPL")
                return False
        else:
            logger.error("No results from scan with retry")
            return False
    except Exception as e:
        logger.error(f"Error testing integration with fixed scanner: {e}")
        return False

if __name__ == "__main__":
    # Test fixed scanner
    scanner_result = test_fixed_scanner()
    logger.info(f"Fixed scanner test: {'PASSED' if scanner_result else 'FAILED'}")
    
    # Test integration with fixed scanner
    integration_result = test_integration_with_fixed_scanner()
    logger.info(f"Integration with fixed scanner test: {'PASSED' if integration_result else 'FAILED'}")
    
    # Overall result
    overall = scanner_result and integration_result
    logger.info(f"Overall: {'PASSED' if overall else 'FAILED'}")
    
    sys.exit(0 if overall else 1)
