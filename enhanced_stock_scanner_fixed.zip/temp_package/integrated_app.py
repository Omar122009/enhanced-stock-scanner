import streamlit as st
import pandas as pd
import numpy as np
import datetime
import json
import os
import sys
from utils.technical_analysis_enhanced import EnhancedTechnicalAnalysis
from utils.sentiment_analysis import SentimentAnalysis
from utils.price_prediction import PricePrediction
from utils.user_management import UserManagement
from utils.continuous_operation import ContinuousOperation
from data_acquisition_enhanced import EnhancedDataAcquisition
from config.enhanced_config import get_config
from stock_list_500 import get_default_symbols

# Initialize session state variables if they don't exist
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'username' not in st.session_state:
    st.session_state.username = ""
if 'is_admin' not in st.session_state:
    st.session_state.is_admin = False
if 'current_page' not in st.session_state:
    st.session_state.current_page = "Scanner"

# Initialize components
config = get_config()
st.set_page_config(page_title="Advanced Stock Scanner", layout="wide")

# Initialize logger
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('app')

# Initialize components
logger.info("Initializing components...")
data_acquisition = EnhancedDataAcquisition(config)
technical_analysis = EnhancedTechnicalAnalysis(config)
sentiment_analysis = SentimentAnalysis(config)
price_prediction = PricePrediction(config)
user_management = UserManagement()
continuous_operation = ContinuousOperation(config, data_acquisition, technical_analysis, sentiment_analysis, price_prediction)
logger.info("Components initialized successfully")

# Login functionality
def login_user():
    st.title("Advanced Stock Scanner - Login")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.write("### Please login to access the scanner")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        
        if st.button("Login", use_container_width=True):
            if user_management.verify_user(username, password):
                st.session_state.logged_in = True
                st.session_state.username = username
                st.session_state.is_admin = user_management.is_admin(username)
                st.experimental_rerun()
            else:
                st.error("Invalid username or password")
        
        st.info("Default admin credentials: username 'admin', password 'admin'")

# Logout functionality
def logout_user():
    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.username = ""
        st.session_state.is_admin = False
        st.experimental_rerun()

# Navigation
def navigation():
    st.sidebar.title("Navigation")
    pages = ["Scanner", "Watchlist", "Results History"]
    
    # Add Admin Panel option only for admin users
    if st.session_state.is_admin:
        pages.append("Admin Panel")
    
    selected_page = st.sidebar.selectbox("Select Page", pages)
    
    if selected_page != st.session_state.current_page:
        st.session_state.current_page = selected_page
        st.experimental_rerun()
    
    st.sidebar.write(f"Logged in as: {st.session_state.username}")
    
    # Offline mode toggle
    offline_mode = st.sidebar.checkbox("Offline Mode")
    
    # Data source health check
    if st.sidebar.button("Check Data Sources"):
        with st.spinner("Checking data sources..."):
            health_status = data_acquisition.check_data_sources()
            for source, status in health_status.items():
                if status:
                    st.sidebar.success(f"{source}: Available")
                else:
                    st.sidebar.error(f"{source}: Unavailable")
    
    logout_user()
    
    return offline_mode

# Scanner page
def scanner_page(offline_mode):
    st.title("Advanced Stock Scanner")
    
    col1, col2 = st.columns(2)
    
    with col1:
        start_date = st.date_input("Start Date", datetime.datetime.now() - datetime.timedelta(days=30))
    
    with col2:
        end_date = st.date_input("End Date", datetime.datetime.now())
    
    symbols_input = st.text_area("Symbols (comma-separated, leave empty for default list)", "")
    symbols = symbols_input.replace(" ", "").split(",") if symbols_input else get_default_symbols()
    
    timeframe = st.selectbox("Timeframe", ["1day", "1hour", "1week", "1month"])
    
    with st.expander("Advanced Settings"):
        use_performance_optimization = st.checkbox("Use Performance Optimization", value=True)
        technical_indicators = st.multiselect("Technical Indicators", 
                                             ["RSI", "MACD", "Moving Averages", "Bollinger Bands", "Volume Profile"],
                                             ["RSI", "MACD", "Moving Averages"])
        sentiment_strength = st.slider("Sentiment Analysis Strength", 1, 10, 5)
        prediction_confidence = st.slider("Prediction Confidence Threshold", 50, 95, 70)
    
    if st.button("Run Scan"):
        with st.spinner("Running scan..."):
            try:
                # Get data
                data = {}
                for symbol in symbols[:10]:  # Limit to 10 symbols for demo
                    try:
                        symbol_data = data_acquisition.get_historical_data([symbol], timeframe, period=f"{(end_date - start_date).days}day", use_cache=offline_mode)
                        if symbol in symbol_data:
                            symbol_data = symbol_data[symbol]
                        else:
                            symbol_data = None
                        if symbol_data is not None and not symbol_data.empty:
                            data[symbol] = symbol_data
                    except Exception as e:
                        st.error(f"Error fetching data for {symbol}: {str(e)}")
                
                if not data:
                    st.error("No data available for the selected symbols and timeframe.")
                    return
                
                # Process data and display results
                results = []
                
                for symbol, symbol_data in data.items():
                    try:
                        # Technical Analysis
                        technical_indicators = technical_analysis.calculate_indicators(symbol_data)
                        
                        # Sentiment Analysis
                        sentiment_result = sentiment_analysis.analyze_sentiment(symbol_data, technical_indicators)
                        
                        # Price Prediction
                        prediction_result = price_prediction.predict_prices(symbol_data, technical_indicators)
                        
                        # Combine results
                        result = {
                            "Symbol": symbol,
                            "Last Price": symbol_data['close'].iloc[-1],
                            "Short-Term Sentiment": sentiment_result['short_term']['sentiment'],
                            "Short-Term Evidence": sentiment_result['short_term']['evidence'],
                            "Medium-Term Sentiment": sentiment_result['medium_term']['sentiment'],
                            "Medium-Term Evidence": sentiment_result['medium_term']['evidence'],
                            "Long-Term Sentiment": sentiment_result['long_term']['sentiment'],
                            "Long-Term Evidence": sentiment_result['long_term']['evidence'],
                            "Support": sentiment_result['key_levels']['support'],
                            "Resistance": sentiment_result['key_levels']['resistance'],
                            "Stop Loss": sentiment_result['key_levels']['stop_loss'],
                            "Price Target": prediction_result['price_target'],
                            "Confidence": prediction_result['confidence'],
                            "Buy Price": prediction_result['buy_price'],
                            "Sell Price": prediction_result['sell_price'],
                            "Risk/Reward": prediction_result['risk_reward']
                        }
                        
                        results.append(result)
                    except Exception as e:
                        st.error(f"Error processing {symbol}: {str(e)}")
                
                if results:
                    results_df = pd.DataFrame(results)
                    st.dataframe(results_df)
                    
                    # Save results
                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    results_file = f"data/results/scan_{timeframe}_{timestamp}.json"
                    os.makedirs(os.path.dirname(results_file), exist_ok=True)
                    with open(results_file, 'w') as f:
                        json.dump(results, f)
                    
                    # Display detailed analysis for the first symbol
                    if results:
                        st.subheader(f"Detailed Analysis for {results[0]['Symbol']}")
                        
                        # Technical Analysis
                        st.write("### Technical Analysis")
                        
                        st.write("#### Technical Outlook")
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.write("Short-Term: ", end="")
                            sentiment = results[0]['Short-Term Sentiment']
                            evidence = results[0]['Short-Term Evidence']
                            if sentiment == "Very Bullish":
                                st.markdown(f"<span style='color:green'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Bullish":
                                st.markdown(f"<span style='color:lightgreen'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Neutral":
                                st.markdown(f"<span style='color:gray'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Bearish":
                                st.markdown(f"<span style='color:orange'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Very Bearish":
                                st.markdown(f"<span style='color:red'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                        
                        with col2:
                            st.write("Medium-Term: ", end="")
                            sentiment = results[0]['Medium-Term Sentiment']
                            evidence = results[0]['Medium-Term Evidence']
                            if sentiment == "Very Bullish":
                                st.markdown(f"<span style='color:green'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Bullish":
                                st.markdown(f"<span style='color:lightgreen'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Neutral":
                                st.markdown(f"<span style='color:gray'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Bearish":
                                st.markdown(f"<span style='color:orange'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Very Bearish":
                                st.markdown(f"<span style='color:red'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                        
                        with col3:
                            st.write("Long-Term: ", end="")
                            sentiment = results[0]['Long-Term Sentiment']
                            evidence = results[0]['Long-Term Evidence']
                            if sentiment == "Very Bullish":
                                st.markdown(f"<span style='color:green'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Bullish":
                                st.markdown(f"<span style='color:lightgreen'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Neutral":
                                st.markdown(f"<span style='color:gray'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Bearish":
                                st.markdown(f"<span style='color:orange'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                            elif sentiment == "Very Bearish":
                                st.markdown(f"<span style='color:red'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                        
                        st.write("#### Key Technical Levels")
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.write(f"Support: ${results[0]['Support']:.2f}")
                        
                        with col2:
                            st.write(f"Resistance: ${results[0]['Resistance']:.2f}")
                        
                        with col3:
                            st.write(f"Stop Loss: ${results[0]['Stop Loss']:.2f}")
                        
                        # Price Prediction
                        st.write("### Price Prediction")
                        
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.write(f"Price Target: ${results[0]['Price Target']:.2f}")
                        
                        with col2:
                            st.write(f"Confidence: {results[0]['Confidence']:.1f}%")
                        
                        with col3:
                            st.write(f"Risk/Reward: {results[0]['Risk/Reward']:.2f}")
                        
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write(f"Buy Price: ${results[0]['Buy Price']:.2f}")
                        
                        with col2:
                            st.write(f"Sell Price: ${results[0]['Sell Price']:.2f}")
                
                else:
                    st.error("No results generated. Please try different symbols or timeframe.")
            
            except Exception as e:
                st.error(f"Error during scan: {str(e)}")
    else:
        st.info("Run a scan to see results")

# Watchlist page
def watchlist_page():
    st.title("Watchlist")
    
    # Get user's watchlist
    watchlist = user_management.get_watchlist(st.session_state.username)
    
    # Add to watchlist
    st.subheader("Add to Watchlist")
    new_symbol = st.text_input("Symbol")
    if st.button("Add"):
        if new_symbol:
            user_management.add_to_watchlist(st.session_state.username, new_symbol.upper())
            st.success(f"Added {new_symbol.upper()} to watchlist")
            st.experimental_rerun()
    
    # Display watchlist
    st.subheader("Your Watchlist")
    if watchlist:
        for symbol in watchlist:
            col1, col2 = st.columns([4, 1])
            with col1:
                st.write(symbol)
            with col2:
                if st.button("Remove", key=f"remove_{symbol}"):
                    user_management.remove_from_watchlist(st.session_state.username, symbol)
                    st.success(f"Removed {symbol} from watchlist")
                    st.experimental_rerun()
    else:
        st.info("Your watchlist is empty")

# Results History page
def results_history_page():
    st.title("Results History")
    
    # Get list of result files
    results_dir = "data/results"
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)
    
    result_files = [f for f in os.listdir(results_dir) if f.endswith('.json')]
    result_files.sort(reverse=True)
    
    if not result_files:
        st.info("No scan results found")
        return
    
    # Display results
    selected_file = st.selectbox("Select Result", result_files)
    
    if selected_file:
        file_path = os.path.join(results_dir, selected_file)
        with open(file_path, 'r') as f:
            results = json.load(f)
        
        results_df = pd.DataFrame(results)
        st.dataframe(results_df)
        
        # Display detailed analysis for selected symbol
        if not results_df.empty:
            symbols = results_df["Symbol"].tolist()
            selected_symbol = st.selectbox("Select Symbol for Detailed Analysis", symbols)
            
            if selected_symbol:
                selected_result = results_df[results_df["Symbol"] == selected_symbol].to_dict('records')[0]
                
                st.subheader(f"Detailed Analysis for {selected_symbol}")
                
                # Technical Analysis
                st.write("### Technical Analysis")
                
                st.write("#### Technical Outlook")
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.write("Short-Term: ", end="")
                    sentiment = selected_result['Short-Term Sentiment']
                    evidence = selected_result['Short-Term Evidence']
                    if sentiment == "Very Bullish":
                        st.markdown(f"<span style='color:green'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Bullish":
                        st.markdown(f"<span style='color:lightgreen'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Neutral":
                        st.markdown(f"<span style='color:gray'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Bearish":
                        st.markdown(f"<span style='color:orange'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Very Bearish":
                        st.markdown(f"<span style='color:red'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                
                with col2:
                    st.write("Medium-Term: ", end="")
                    sentiment = selected_result['Medium-Term Sentiment']
                    evidence = selected_result['Medium-Term Evidence']
                    if sentiment == "Very Bullish":
                        st.markdown(f"<span style='color:green'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Bullish":
                        st.markdown(f"<span style='color:lightgreen'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Neutral":
                        st.markdown(f"<span style='color:gray'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Bearish":
                        st.markdown(f"<span style='color:orange'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Very Bearish":
                        st.markdown(f"<span style='color:red'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                
                with col3:
                    st.write("Long-Term: ", end="")
                    sentiment = selected_result['Long-Term Sentiment']
                    evidence = selected_result['Long-Term Evidence']
                    if sentiment == "Very Bullish":
                        st.markdown(f"<span style='color:green'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Bullish":
                        st.markdown(f"<span style='color:lightgreen'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Neutral":
                        st.markdown(f"<span style='color:gray'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Bearish":
                        st.markdown(f"<span style='color:orange'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                    elif sentiment == "Very Bearish":
                        st.markdown(f"<span style='color:red'><b>{sentiment}</b></span> ({evidence})", unsafe_allow_html=True)
                
                st.write("#### Key Technical Levels")
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.write(f"Support: ${selected_result['Support']:.2f}")
                
                with col2:
                    st.write(f"Resistance: ${selected_result['Resistance']:.2f}")
                
                with col3:
                    st.write(f"Stop Loss: ${selected_result['Stop Loss']:.2f}")
                
                # Price Prediction
                st.write("### Price Prediction")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.write(f"Price Target: ${selected_result['Price Target']:.2f}")
                
                with col2:
                    st.write(f"Confidence: {selected_result['Confidence']:.1f}%")
                
                with col3:
                    st.write(f"Risk/Reward: {selected_result['Risk/Reward']:.2f}")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write(f"Buy Price: ${selected_result['Buy Price']:.2f}")
                
                with col2:
                    st.write(f"Sell Price: ${selected_result['Sell Price']:.2f}")

# Admin Panel page
def admin_panel_page():
    st.title("Admin Panel")
    
    tab1, tab2, tab3, tab4 = st.tabs(["User Management", "Continuous Operation", "System Settings", "Manual Scan"])
    
    with tab1:
        st.header("User Management")
        
        # Create new user
        st.subheader("Create New User")
        new_username = st.text_input("Username")
        new_password = st.text_input("Password", type="password")
        is_admin = st.checkbox("Admin Privileges")
        
        if st.button("Create User"):
            if new_username and new_password:
                user_management.create_user(new_username, new_password, is_admin)
                st.success(f"User {new_username} created successfully")
            else:
                st.error("Username and password are required")
        
        # List users
        st.subheader("User List")
        users = user_management.get_users()
        
        for username, user_data in users.items():
            col1, col2, col3 = st.columns([3, 1, 1])
            with col1:
                st.write(f"{username} ({'Admin' if user_data['is_admin'] else 'User'})")
            with col2:
                if st.button("Reset Password", key=f"reset_{username}"):
                    new_pwd = st.text_input(f"New password for {username}", type="password", key=f"new_pwd_{username}")
                    if st.button("Confirm", key=f"confirm_{username}"):
                        user_management.update_password(username, new_pwd)
                        st.success(f"Password for {username} updated")
            with col3:
                if username != st.session_state.username:  # Prevent deleting own account
                    if st.button("Delete", key=f"delete_{username}"):
                        user_management.delete_user(username)
                        st.success(f"User {username} deleted")
                        st.experimental_rerun()
    
    with tab2:
        st.header("Continuous Operation")
        
        # Load schedule configuration
        schedule_file = "config/schedule.json"
        if os.path.exists(schedule_file):
            with open(schedule_file, 'r') as f:
                schedule_config = json.load(f)
        else:
            schedule_config = {
                "daily_scan": {
                    "enabled": True,
                    "time": "17:00",
                    "days": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                    "symbols": [],
                    "timeframe": "1day",
                    "lookback_days": 30
                },
                "hourly_scan": {
                    "enabled": False,
                    "interval_hours": 1,
                    "start_time": "09:30",
                    "end_time": "16:00",
                    "days": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                    "symbols": [],
                    "timeframe": "1hour",
                    "lookback_days": 5
                },
                "weekly_scan": {
                    "enabled": True,
                    "day": "Friday",
                    "time": "18:00",
                    "symbols": [],
                    "timeframe": "1week",
                    "lookback_days": 90
                }
            }
        
        # Daily scan settings
        st.subheader("Daily Scan")
        daily_enabled = st.checkbox("Enable Daily Scan", value=schedule_config["daily_scan"]["enabled"])
        daily_time = st.text_input("Time (HH:MM)", value=schedule_config["daily_scan"]["time"])
        daily_days = st.multiselect("Days", 
                                   ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                                   default=schedule_config["daily_scan"]["days"])
        daily_timeframe = st.selectbox("Timeframe", ["1day", "1hour", "1week", "1month"], 
                                      index=["1day", "1hour", "1week", "1month"].index(schedule_config["daily_scan"]["timeframe"]))
        daily_lookback = st.number_input("Lookback Days", value=schedule_config["daily_scan"]["lookback_days"], min_value=1, max_value=365)
        
        # Hourly scan settings
        st.subheader("Hourly Scan")
        hourly_enabled = st.checkbox("Enable Hourly Scan", value=schedule_config["hourly_scan"]["enabled"])
        hourly_interval = st.number_input("Interval (hours)", value=schedule_config["hourly_scan"]["interval_hours"], min_value=1, max_value=12)
        hourly_start = st.text_input("Start Time (HH:MM)", value=schedule_config["hourly_scan"]["start_time"])
        hourly_end = st.text_input("End Time (HH:MM)", value=schedule_config["hourly_scan"]["end_time"])
        hourly_days = st.multiselect("Days", 
                                    ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                                    default=schedule_config["hourly_scan"]["days"],
                                    key="hourly_days")
        hourly_timeframe = st.selectbox("Timeframe", ["1day", "1hour", "1week", "1month"], 
                                       index=["1day", "1hour", "1week", "1month"].index(schedule_config["hourly_scan"]["timeframe"]),
                                       key="hourly_timeframe")
        hourly_lookback = st.number_input("Lookback Days", value=schedule_config["hourly_scan"]["lookback_days"], min_value=1, max_value=365, key="hourly_lookback")
        
        # Weekly scan settings
        st.subheader("Weekly Scan")
        weekly_enabled = st.checkbox("Enable Weekly Scan", value=schedule_config["weekly_scan"]["enabled"])
        weekly_day = st.selectbox("Day", ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                                 index=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].index(schedule_config["weekly_scan"]["day"]))
        weekly_time = st.text_input("Time (HH:MM)", value=schedule_config["weekly_scan"]["time"], key="weekly_time")
        weekly_timeframe = st.selectbox("Timeframe", ["1day", "1hour", "1week", "1month"], 
                                       index=["1day", "1hour", "1week", "1month"].index(schedule_config["weekly_scan"]["timeframe"]),
                                       key="weekly_timeframe")
        weekly_lookback = st.number_input("Lookback Days", value=schedule_config["weekly_scan"]["lookback_days"], min_value=1, max_value=365, key="weekly_lookback")
        
        # Save schedule configuration
        if st.button("Save Schedule"):
            schedule_config["daily_scan"]["enabled"] = daily_enabled
            schedule_config["daily_scan"]["time"] = daily_time
            schedule_config["daily_scan"]["days"] = daily_days
            schedule_config["daily_scan"]["timeframe"] = daily_timeframe
            schedule_config["daily_scan"]["lookback_days"] = daily_lookback
            
            schedule_config["hourly_scan"]["enabled"] = hourly_enabled
            schedule_config["hourly_scan"]["interval_hours"] = hourly_interval
            schedule_config["hourly_scan"]["start_time"] = hourly_start
            schedule_config["hourly_scan"]["end_time"] = hourly_end
            schedule_config["hourly_scan"]["days"] = hourly_days
            schedule_config["hourly_scan"]["timeframe"] = hourly_timeframe
            schedule_config["hourly_scan"]["lookback_days"] = hourly_lookback
            
            schedule_config["weekly_scan"]["enabled"] = weekly_enabled
            schedule_config["weekly_scan"]["day"] = weekly_day
            schedule_config["weekly_scan"]["time"] = weekly_time
            schedule_config["weekly_scan"]["timeframe"] = weekly_timeframe
            schedule_config["weekly_scan"]["lookback_days"] = weekly_lookback
            
            os.makedirs(os.path.dirname(schedule_file), exist_ok=True)
            with open(schedule_file, 'w') as f:
                json.dump(schedule_config, f, indent=4)
            
            st.success("Schedule configuration saved")
        
        # Start/stop continuous operation
        st.subheader("Continuous Operation Control")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Start Continuous Operation"):
                continuous_operation.start()
                st.success("Continuous operation started")
        
        with col2:
            if st.button("Stop Continuous Operation"):
                continuous_operation.stop()
                st.success("Continuous operation stopped")
    
    with tab3:
        st.header("System Settings")
        
        # API Keys
        st.subheader("API Keys")
        
        alpha_vantage_key = st.text_input("Alpha Vantage API Key", value=config.get("alpha_vantage_api_key", ""))
        
        if st.button("Save API Keys"):
            config["alpha_vantage_api_key"] = alpha_vantage_key
            
            # Save config
            config_file = "config/enhanced_config.py"
            with open(config_file, 'w') as f:
                f.write(f"def get_config():\n")
                f.write(f"    return {config}\n")
            
            st.success("API keys saved")
        
        # Cache Settings
        st.subheader("Cache Settings")
        
        cache_enabled = st.checkbox("Enable Cache", value=config.get("cache_enabled", True))
        cache_expiry = st.number_input("Cache Expiry (hours)", value=config.get("cache_expiry_hours", 24), min_value=1, max_value=168)
        
        if st.button("Save Cache Settings"):
            config["cache_enabled"] = cache_enabled
            config["cache_expiry_hours"] = cache_expiry
            
            # Save config
            config_file = "config/enhanced_config.py"
            with open(config_file, 'w') as f:
                f.write(f"def get_config():\n")
                f.write(f"    return {config}\n")
            
            st.success("Cache settings saved")
        
        # Clear Cache
        if st.button("Clear Cache"):
            cache_dir = "cache"
            if os.path.exists(cache_dir):
                for file in os.listdir(cache_dir):
                    os.remove(os.path.join(cache_dir, file))
            st.success("Cache cleared")
    
    with tab4:
        st.header("Manual Scan")
        
        # Symbol selection
        symbols_input = st.text_area("Symbols (comma-separated)", "AAPL,MSFT,GOOGL")
        symbols = symbols_input.replace(" ", "").split(",") if symbols_input else []
        
        # Timeframe selection
        timeframe = st.selectbox("Timeframe", ["1day", "1hour", "1week", "1month"], key="manual_timeframe")
        
        # Lookback days
        lookback_days = st.number_input("Lookback Days", value=30, min_value=1, max_value=365, key="manual_lookback")
        
        # Run scan button
        if st.button("Run Manual Scan"):
            if symbols:
                with st.spinner("Running manual scan..."):
                    try:
                        start_date = datetime.datetime.now() - datetime.timedelta(days=lookback_days)
                        end_date = datetime.datetime.now()
                        
                        continuous_operation.run_manual_scan(symbols, timeframe, lookback_days)
                        
                        st.success("Manual scan completed")
                        
                        # Show latest results
                        results_dir = "data/results"
                        if os.path.exists(results_dir):
                            result_files = [f for f in os.listdir(results_dir) if f.endswith('.json')]
                            result_files.sort(reverse=True)
                            
                            if result_files:
                                latest_file = result_files[0]
                                file_path = os.path.join(results_dir, latest_file)
                                with open(file_path, 'r') as f:
                                    results = json.load(f)
                                
                                results_df = pd.DataFrame(results)
                                st.dataframe(results_df)
                    
                    except Exception as e:
                        st.error(f"Error during manual scan: {str(e)}")
            else:
                st.error("Please enter at least one symbol")

# Main app
def main():
    # Check if user is logged in
    if not st.session_state.logged_in:
        login_user()
    else:
        # Navigation and page display
        offline_mode = navigation()
        
        if st.session_state.current_page == "Scanner":
            scanner_page(offline_mode)
        elif st.session_state.current_page == "Watchlist":
            watchlist_page()
        elif st.session_state.current_page == "Results History":
            results_history_page()
        elif st.session_state.current_page == "Admin Panel" and st.session_state.is_admin:
            admin_panel_page()

if __name__ == "__main__":
    main()
