"""
data_acquisition.py - Enhanced Data Acquisition module for the Advanced Stock Scanner
"""

import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import time
from concurrent.futures import ThreadPoolExecutor
import json
import pickle

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('data_acquisition')

class DataAcquisition:
    """
    Data acquisition class for fetching stock data from various sources
    """
    
    def __init__(self, config):
        """
        Initialize the data acquisition module
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        self.data_config = config['data']
        self.primary_source = self.data_config['primary_source']
        self.backup_source = self.data_config['backup_source']
        self.api_keys = self.data_config['api_keys']
        self.default_symbols = self.data_config['default_symbols']
        self.timeframes = self.data_config['timeframes']
        self.history_period = self.data_config['history_period']
        
        # Setup cache directory
        self.cache_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'cache')
        os.makedirs(self.cache_dir, exist_ok=True)
        
        # Initialize data sources
        self._init_data_sources()
        
    def _init_data_sources(self):
        """Initialize data source clients based on configuration"""
        self.sources = {}
        
        # Initialize Alpaca if configured
        if self.primary_source == 'alpaca' or self.backup_source == 'alpaca':
            try:
                from alpaca.data.historical import StockHistoricalDataClient
                from alpaca.trading.client import TradingClient
                
                api_key = self.api_keys['alpaca']['api_key']
                api_secret = self.api_keys['alpaca']['api_secret']
                
                if api_key and api_secret:
                    self.sources['alpaca'] = {
                        'data_client': StockHistoricalDataClient(api_key, api_secret),
                        'trading_client': TradingClient(api_key, api_secret, paper=True)
                    }
                    logger.info("Alpaca client initialized successfully")
                else:
                    logger.warning("Alpaca API keys not provided")
            except Exception as e:
                logger.error(f"Failed to initialize Alpaca client: {e}")
        
        # Initialize yfinance if configured
        if self.primary_source == 'yfinance' or self.backup_source == 'yfinance':
            try:
                import yfinance as yf
                self.sources['yfinance'] = {'client': yf}
                logger.info("yfinance initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize yfinance: {e}")
                # Raise exception to ensure the error is visible to the user
                raise RuntimeError(f"Failed to initialize yfinance: {e}")
        
        # Initialize Alpha Vantage if configured
        if self.primary_source == 'alpha_vantage' or self.backup_source == 'alpha_vantage':
            try:
                import requests
                
                api_key = self.api_keys['alpha_vantage']['api_key']
                
                if api_key:
                    self.sources['alpha_vantage'] = {
                        'client': requests,
                        'api_key': api_key,
                        'base_url': 'https://www.alphavantage.co/query'
                    }
                    logger.info("Alpha Vantage client initialized successfully")
                else:
                    logger.warning("Alpha Vantage API key not provided")
            except Exception as e:
                logger.error(f"Failed to initialize Alpha Vantage client: {e}")
    
    def _map_timeframe(self, timeframe, source):
        """
        Map internal timeframe to source-specific timeframe
        
        Args:
            timeframe (str): Internal timeframe representation
            source (str): Data source name
            
        Returns:
            str: Source-specific timeframe
        """
        # Alpaca timeframe mapping
        alpaca_mapping = {
            '1min': '1Min',
            '5min': '5Min',
            '15min': '15Min',
            '30min': '30Min',
            '1hour': '1Hour',
            '1day': '1Day',
            '1week': '1Week'
        }
        
        # yfinance timeframe mapping
        yfinance_mapping = {
            '1min': '1m',
            '5min': '5m',
            '15min': '15m',
            '30min': '30m',
            '1hour': '1h',
            '1day': '1d',
            '1week': '1wk',
            '1month': '1mo'
        }
        
        # Alpha Vantage timeframe mapping
        alpha_vantage_mapping = {
            '1min': '1min',
            '5min': '5min',
            '15min': '15min',
            '30min': '30min',
            '1hour': '60min',
            '1day': 'daily',
            '1week': 'weekly',
            '1month': 'monthly'
        }
        
        if source == 'alpaca':
            return alpaca_mapping.get(timeframe, '1Day')
        elif source == 'yfinance':
            return yfinance_mapping.get(timeframe, '1d')
        elif source == 'alpha_vantage':
            return alpha_vantage_mapping.get(timeframe, 'daily')
        else:
            return timeframe
    
    def _map_period(self, period, source):
        """
        Map internal period to source-specific period
        
        Args:
            period (str): Internal period representation
            source (str): Data source name
            
        Returns:
            tuple: (start_date, end_date) or period string depending on source
        """
        end_date = datetime.now()
        
        if period == '1day':
            start_date = end_date - timedelta(days=1)
        elif period == '1week':
            start_date = end_date - timedelta(weeks=1)
        elif period == '1month':
            start_date = end_date - timedelta(days=30)
        elif period == '3month':
            start_date = end_date - timedelta(days=90)
        elif period == '6month':
            start_date = end_date - timedelta(days=180)
        elif period == '1year':
            start_date = end_date - timedelta(days=365)
        elif period == '2year':
            start_date = end_date - timedelta(days=730)
        elif period == '5year':
            start_date = end_date - timedelta(days=1825)
        else:
            # Default to 3 months
            start_date = end_date - timedelta(days=90)
        
        if source == 'alpaca':
            return start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')
        elif source == 'yfinance':
            # yfinance uses period strings
            yf_periods = {
                '1day': '1d',
                '1week': '1wk',
                '1month': '1mo',
                '3month': '3mo',
                '6month': '6mo',
                '1year': '1y',
                '2year': '2y',
                '5year': '5y'
            }
            return yf_periods.get(period, '3mo')
        else:
            return start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')
    
    def _get_cache_path(self, symbol, timeframe, start_date=None, end_date=None):
        """
        Get cache file path for a specific symbol and timeframe
        
        Args:
            symbol (str): Stock symbol
            timeframe (str): Timeframe
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            
        Returns:
            str: Cache file path
        """
        if start_date and end_date:
            cache_file = f"{symbol}_{timeframe}_{start_date}_{end_date}.pkl"
        else:
            cache_file = f"{symbol}_{timeframe}.pkl"
        
        return os.path.join(self.cache_dir, cache_file)
    
    def _save_to_cache(self, data, symbol, timeframe, start_date=None, end_date=None):
        """
        Save data to cache
        
        Args:
            data (pandas.DataFrame): Data to save
            symbol (str): Stock symbol
            timeframe (str): Timeframe
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
        """
        cache_path = self._get_cache_path(symbol, timeframe, start_date, end_date)
        
        try:
            with open(cache_path, 'wb') as f:
                pickle.dump({
                    'data': data,
                    'timestamp': datetime.now().timestamp(),
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'start_date': start_date,
                    'end_date': end_date
                }, f)
            logger.info(f"Saved data to cache: {cache_path}")
        except Exception as e:
            logger.error(f"Error saving data to cache: {e}")
    
    def _load_from_cache(self, symbol, timeframe, start_date=None, end_date=None, max_age_hours=24):
        """
        Load data from cache if available and not expired
        
        Args:
            symbol (str): Stock symbol
            timeframe (str): Timeframe
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            max_age_hours (int, optional): Maximum age of cache in hours
            
        Returns:
            pandas.DataFrame or None: Cached data if available and not expired, None otherwise
        """
        cache_path = self._get_cache_path(symbol, timeframe, start_date, end_date)
        
        if not os.path.exists(cache_path):
            return None
        
        try:
            with open(cache_path, 'rb') as f:
                cache_data = pickle.load(f)
            
            # Check if cache is expired
            cache_timestamp = cache_data.get('timestamp', 0)
            cache_age_hours = (datetime.now().timestamp() - cache_timestamp) / 3600
            
            if cache_age_hours > max_age_hours:
                logger.info(f"Cache expired for {symbol} {timeframe}: {cache_age_hours:.2f} hours old")
                return None
            
            logger.info(f"Loaded data from cache: {cache_path}")
            return cache_data.get('data')
        except Exception as e:
            logger.error(f"Error loading data from cache: {e}")
            return None
    
    def get_historical_data(self, symbols=None, timeframe=None, period=None):
        """
        Get historical data for specified symbols
        
        Args:
            symbols (list, optional): List of symbols to fetch data for
            timeframe (str, optional): Timeframe to fetch data for
            period (str, optional): Period to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        symbols = symbols or self.default_symbols
        timeframe = timeframe or self.timeframes['primary']
        period = period or self.history_period
        
        # Handle 15-minute data specially due to Yahoo Finance limitations
        if timeframe == '15min':
            return self._get_15min_data(symbols, period)
        
        # Try primary source first
        data = self._fetch_from_source(self.primary_source, symbols, timeframe, period)
        
        # If primary source fails, try backup source
        if not data and self.backup_source:
            logger.warning(f"Primary source {self.primary_source} failed, trying backup source {self.backup_source}")
            data = self._fetch_from_source(self.backup_source, symbols, timeframe, period)
        
        # If both sources fail, raise an exception
        if not data:
            error_msg = f"Failed to fetch data for {symbols} with timeframe {timeframe} from both primary and backup sources"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
            
        return data
    
    def _get_15min_data(self, symbols, period):
        """
        Get 15-minute data with special handling for Yahoo Finance limitations
        
        Args:
            symbols (list): List of symbols to fetch data for
            period (str): Period to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        # For 15-minute data, Yahoo Finance only provides data for the last 60 days
        # We'll handle this by:
        # 1. Checking if we need data beyond 60 days
        # 2. If yes, we'll use cached data if available
        # 3. If no cached data, we'll fetch what we can and provide a warning
        
        end_date = datetime.now()
        
        # Determine if we need data beyond 60 days
        if period in ['1day', '1week', '1month']:
            # These periods are within the 60-day limit
            return self._fetch_recent_15min_data(symbols)
        
        # For longer periods, we need special handling
        data = {}
        errors = []
        
        for symbol in symbols:
            # Check cache first
            cached_data = self._load_from_cache(symbol, '15min')
            
            if cached_data is not None and not cached_data.empty:
                # We have cached data, use it
                data[symbol] = cached_data
                logger.info(f"Using cached 15-minute data for {symbol}")
            else:
                # No cached data, fetch what we can
                try:
                    recent_data = self._fetch_recent_15min_data([symbol])
                    
                    if symbol in recent_data and not recent_data[symbol].empty:
                        data[symbol] = recent_data[symbol]
                        # Save to cache for future use
                        self._save_to_cache(recent_data[symbol], symbol, '15min')
                        logger.info(f"Fetched and cached recent 15-minute data for {symbol}")
                    else:
                        # If we can't get 15-minute data, try to get daily data and resample
                        logger.warning(f"Could not fetch 15-minute data for {symbol}, trying daily data")
                        daily_data = self._fetch_from_source(self.primary_source, [symbol], '1day', period)
                        
                        if symbol in daily_data and not daily_data[symbol].empty:
                            # We have daily data, provide a warning
                            logger.warning(f"Using daily data for {symbol} instead of 15-minute data")
                            data[symbol] = daily_data[symbol]
                        else:
                            error_msg = f"Could not fetch any data for {symbol}"
                            logger.error(error_msg)
                            errors.append(error_msg)
                except Exception as e:
                    error_msg = f"Error fetching data for {symbol}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)
        
        # If we couldn't fetch data for any symbols, raise an exception
        if not data and errors:
            raise RuntimeError(f"Failed to fetch 15-minute data: {'; '.join(errors)}")
            
        return data
    
    def _fetch_recent_15min_data(self, symbols):
        """
        Fetch recent 15-minute data (last 60 days) from Yahoo Finance
        
        Args:
            symbols (list): List of symbols to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        # Calculate dates for the last 60 days
        end_date = datetime.now()
        start_date = end_date - timedelta(days=59)  # 60 days including today
        
        start_str = start_date.strftime('%Y-%m-%d')
        end_str = end_date.strftime('%Y-%m-%d')
        
        try:
            # Try to fetch from yfinance
            if 'yfinance' in self.sources:
                data = self._fetch_from_yfinance_with_dates(symbols, '15min', start_str, end_str)
                
                if data:
                    return data
            
            # If yfinance fails, try alpaca
            if 'alpaca' in self.sources:
                return self._fetch_from_alpaca_with_dates(symbols, '15min', start_str, end_str)
            
            # If all sources fail, return empty dict and log error
            error_msg = f"Failed to fetch recent 15-minute data for {symbols} from any source"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
        except Exception as e:
            error_msg = f"Error fetching recent 15-minute data: {e}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
    
    def get_multi_symbol_data(self, symbols=None, timeframe=None, start_date=None, end_date=None):
        """
        Get data for multiple symbols with optional date range
        
        Args:
            symbols (list, optional): List of symbols to fetch data for
            timeframe (str, optional): Timeframe to fetch data for
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        symbols = symbols or self.default_symbols
        timeframe = timeframe or self.timeframes['primary']
        
        # If dates are not provided, use the default period
        if not start_date or not end_date:
            return self.get_historical_data(symbols, timeframe, self.history_period)
        
        # Handle 15-minute data specially due to Yahoo Finance limitations
        if timeframe == '15min':
            try:
                return self._get_15min_data_with_dates(symbols, start_date, end_date)
            except Exception as e:
                error_msg = f"Error fetching 15-minute data: {str(e)}"
                logger.error(error_msg)
                raise RuntimeError(error_msg)
        
        # Try primary source first
        data = self._fetch_from_source_with_dates(self.primary_source, symbols, timeframe, start_date, end_date)
        
        # If primary source fails, try backup source
        if not data and self.backup_source:
            logger.warning(f"Primary source {self.primary_source} failed, trying backup source {self.backup_source}")
            data = self._fetch_from_source_with_dates(self.backup_source, symbols, timeframe, start_date, end_date)
        
        # If both sources fail, raise an exception
        if not data:
            error_msg = f"Failed to fetch data for {symbols} with timeframe {timeframe} from both primary and backup sources"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
            
        return data
    
    def _get_15min_data_with_dates(self, symbols, start_date, end_date):
        """
        Get 15-minute data with date range, handling Yahoo Finance limitations
        
        Args:
            symbols (list): List of symbols to fetch data for
            start_date (str): Start date in YYYY-MM-DD format
            end_date (str): End date in YYYY-MM-DD format
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        # Convert dates to datetime objects
        start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')
        
        # Calculate date range in days
        date_range_days = (end_dt - start_dt).days
        
        # Check if the date range is within Yahoo Finance's 60-day limit
        if date_range_days <= 60 and (datetime.now() - end_dt).days <= 1:
            # Date range is within limits, fetch directly
            try:
                if 'yfinance' in self.sources:
                    data = self._fetch_from_yfinance_with_dates(symbols, '15min', start_date, end_date)
                    if data:
                        return data
                
                if 'alpaca' in self.sources:
                    return self._fetch_from_alpaca_with_dates(symbols, '15min', start_date, end_date)
                
                error_msg = f"Failed to fetch 15-minute data for {symbols} from any source"
                logger.error(error_msg)
                raise RuntimeError(error_msg)
            except Exception as e:
                error_msg = f"Error fetching 15-minute data with dates: {e}"
                logger.error(error_msg)
                raise RuntimeError(error_msg)
        else:
            # Date range exceeds limits, use cached data or provide warning
            warning_msg = f"Requested date range {start_date} to {end_date} exceeds Yahoo Finance's 60-day limit for 15-minute data"
            logger.warning(warning_msg)
            
            data = {}
            errors = []
            
            for symbol in symbols:
                # Check cache first
                cached_data = self._load_from_cache(symbol, '15min', start_date, end_date)
                
                if cached_data is not None and not cached_data.empty:
                    # We have cached data, use it
                    data[symbol] = cached_data
                    logger.info(f"Using cached 15-minute data for {symbol} from {start_date} to {end_date}")
                else:
                    # No cached data, fetch what we can and provide warning
                    logger.warning(f"No cached 15-minute data for {symbol} from {start_date} to {end_date}")
                    logger.warning(f"Fetching recent 15-minute data for {symbol} (last 60 days only)")
                    
                    # Fetch recent data
                    recent_end = datetime.now()
                    recent_start = recent_end - timedelta(days=59)
                    
                    try:
                        recent_data = self._fetch_from_yfinance_with_dates(
                            [symbol], 
                            '15min', 
                            recent_start.strftime('%Y-%m-%d'), 
                            recent_end.strftime('%Y-%m-%d')
                        )
                        
                        if symbol in recent_data and not recent_data[symbol].empty:
                            data[symbol] = recent_data[symbol]
                            logger.warning(f"Only returning recent 15-minute data for {symbol} (not full requested range)")
                        else:
                            # If we can't get 15-minute data, try to get daily data
                            logger.warning(f"Could not fetch 15-minute data for {symbol}, trying daily data")
                            daily_data = self._fetch_from_source_with_dates(
                                self.primary_source, 
                                [symbol], 
                                '1day', 
                                start_date, 
                                end_date
                            )
                            
                            if symbol in daily_data and not daily_data[symbol].empty:
                                data[symbol] = daily_data[symbol]
                                logger.warning(f"Using daily data for {symbol} instead of 15-minute data")
                            else:
                                error_msg = f"Could not fetch any data for {symbol}"
                                logger.error(error_msg)
                                errors.append(error_msg)
                    except Exception as e:
                        error_msg = f"Error fetching data for {symbol}: {str(e)}"
                        logger.error(error_msg)
                        errors.append(error_msg)
            
            # If we couldn't fetch data for any symbols, raise an exception
            if not data and errors:
                raise RuntimeError(f"Failed to fetch 15-minute data: {'; '.join(errors)}")
                
            return data
    
    def _fetch_from_source_with_dates(self, source, symbols, timeframe, start_date, end_date):
        """
        Fetch data from specified source with explicit date range
        
        Args:
            source (str): Data source name
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            start_date (str): Start date in YYYY-MM-DD format
            end_date (str): End date in YYYY-MM-DD format
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        if source not in self.sources:
            error_msg = f"Data source {source} not initialized"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
        
        try:
            if source == 'alpaca':
                return self._fetch_from_alpaca_with_dates(symbols, timeframe, start_date, end_date)
            elif source == 'yfinance':
                return self._fetch_from_yfinance_with_dates(symbols, timeframe, start_date, end_date)
            elif source == 'alpha_vantage':
                # Alpha Vantage doesn't support explicit date ranges in the API
                # We'll fetch all data and filter it afterwards
                data = self._fetch_from_alpha_vantage(symbols, timeframe, '5year')
                return self._filter_data_by_date(data, start_date, end_date)
            else:
                error_msg = f"Unknown data source: {source}"
                logger.error(error_msg)
                raise RuntimeError(error_msg)
        except Exception as e:
            error_msg = f"Error fetching data from {source} with dates: {e}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
    
    def _fetch_from_source(self, source, symbols, timeframe, period):
        """
        Fetch data from specified source
        
        Args:
            source (str): Data source name
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            period (str): Period to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        if source not in self.sources:
            error_msg = f"Data source {source} not initialized"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
        
        try:
            if source == 'alpaca':
                return self._fetch_from_alpaca(symbols, timeframe, period)
            elif source == 'yfinance':
                return self._fetch_from_yfinance(symbols, timeframe, period)
            elif source == 'alpha_vantage':
                return self._fetch_from_alpha_vantage(symbols, timeframe, period)
            else:
                error_msg = f"Unknown data source: {source}"
                logger.error(error_msg)
                raise RuntimeError(error_msg)
        except Exception as e:
            error_msg = f"Error fetching data from {source}: {e}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
    
    def _fetch_from_alpaca_with_dates(self, symbols, timeframe, start_date, end_date):
        """
        Fetch data from Alpaca with explicit date range
        
        Args:
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            start_date (str): Start date in YYYY-MM-DD format
            end_date (str): End date in YYYY-MM-DD format
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        if 'alpaca' not in self.sources:
            error_msg = "Alpaca data source not initialized"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
            
        from alpaca.data.requests import StockBarsRequest
        from alpaca.data.timeframe import TimeFrame
        
        alpaca_client = self.sources['alpaca']['data_client']
        
        # Map timeframe to Alpaca timeframe
        alpaca_timeframe = self._map_timeframe(timeframe, 'alpaca')
        
        # Create request parameters
        request_params = StockBarsRequest(
            symbol_or_symbols=symbols,
            timeframe=getattr(TimeFrame, alpaca_timeframe),
            start=start_date,
            end=end_date
        )
        
        # Fetch data
        try:
            bars = alpaca_client.get_stock_bars(request_params)
            
            # Convert to dictionary of DataFrames
            data = {}
            for symbol in symbols:
                if symbol in bars:
                    df = bars[symbol].df
                    # Rename columns to match our standard format
                    df = df.rename(columns={
                        'open': 'open',
                        'high': 'high',
                        'low': 'low',
                        'close': 'close',
                        'volume': 'volume',
                        'trade_count': 'trade_count',
                        'vwap': 'vwap'
                    })
                    data[symbol] = df
                    
                    # Cache the data
                    self._save_to_cache(df, symbol, timeframe, start_date, end_date)
            
            return data
        except Exception as e:
            error_msg = f"Error fetching data from Alpaca with dates: {e}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
    
    def _fetch_from_yfinance_with_dates(self, symbols, timeframe, start_date, end_date):
        """
        Fetch data from yfinance with explicit date range
        
        Args:
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            start_date (str): Start date in YYYY-MM-DD format
            end_date (str): End date in YYYY-MM-DD format
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        if 'yfinance' not in self.sources:
            error_msg = "yfinance data source not initialized"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
            
        yf = self.sources['yfinance']['client']
        
        # Map timeframe to yfinance interval
        yf_interval = self._map_timeframe(timeframe, 'yfinance')
        
        data = {}
        errors = []
        
        # Special handling for 15-minute data
        if timeframe == '15min':
            # Check if date range exceeds Yahoo Finance's 60-day limit
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')
            date_range_days = (end_dt - start_dt).days
            
            if date_range_days > 60:
                warning_msg = f"Date range exceeds Yahoo Finance's 60-day limit for 15-minute data. Limiting to last 60 days."
                logger.warning(warning_msg)
                start_dt = end_dt - timedelta(days=59)  # 60 days including end date
                start_date = start_dt.strftime('%Y-%m-%d')
        
        # Fetch data for each symbol
        with ThreadPoolExecutor(max_workers=min(10, len(symbols))) as executor:
            def fetch_symbol(symbol):
                try:
                    # Check cache first
                    cached_data = self._load_from_cache(symbol, timeframe, start_date, end_date)
                    
                    if cached_data is not None and not cached_data.empty:
                        return symbol, cached_data
                    
                    # Fetch from yfinance
                    ticker = yf.Ticker(symbol)
                    df = ticker.history(interval=yf_interval, start=start_date, end=end_date)
                    
                    # Rename columns to match our standard format
                    df = df.rename(columns={
                        'Open': 'open',
                        'High': 'high',
                        'Low': 'low',
                        'Close': 'close',
                        'Volume': 'volume'
                    })
                    
                    # Cache the data
                    if not df.empty:
                        self._save_to_cache(df, symbol, timeframe, start_date, end_date)
                    
                    return symbol, df
                except Exception as e:
                    error_msg = f"Error fetching data for {symbol} from yfinance with dates: {e}"
                    logger.error(error_msg)
                    errors.append(error_msg)
                    return symbol, None
            
            # Execute fetches in parallel
            results = executor.map(fetch_symbol, symbols)
            
            # Process results
            for symbol, df in results:
                if df is not None and not df.empty:
                    data[symbol] = df
        
        # If we couldn't fetch data for any symbols, raise an exception
        if not data and errors:
            raise RuntimeError(f"Failed to fetch data from yfinance: {'; '.join(errors)}")
            
        return data
    
    def _fetch_from_alpaca(self, symbols, timeframe, period):
        """
        Fetch data from Alpaca
        
        Args:
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            period (str): Period to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        # Map period to start and end dates
        start_date, end_date = self._map_period(period, 'alpaca')
        
        return self._fetch_from_alpaca_with_dates(symbols, timeframe, start_date, end_date)
    
    def _fetch_from_yfinance(self, symbols, timeframe, period):
        """
        Fetch data from yfinance
        
        Args:
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            period (str): Period to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        if 'yfinance' not in self.sources:
            error_msg = "yfinance data source not initialized"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
            
        yf = self.sources['yfinance']['client']
        
        # Map timeframe to yfinance interval
        yf_interval = self._map_timeframe(timeframe, 'yfinance')
        
        # Map period to yfinance period
        yf_period = self._map_period(period, 'yfinance')
        
        data = {}
        errors = []
        
        # Special handling for 15-minute data
        if timeframe == '15min':
            # For 15-minute data, Yahoo Finance only provides data for the last 60 days
            # We'll use date-based fetching instead of period-based
            end_date = datetime.now()
            start_date = end_date - timedelta(days=59)  # 60 days including today
            
            return self._fetch_from_yfinance_with_dates(
                symbols, 
                timeframe, 
                start_date.strftime('%Y-%m-%d'), 
                end_date.strftime('%Y-%m-%d')
            )
        
        # Fetch data for each symbol
        with ThreadPoolExecutor(max_workers=min(10, len(symbols))) as executor:
            def fetch_symbol(symbol):
                try:
                    # Check cache first
                    cached_data = self._load_from_cache(symbol, timeframe)
                    
                    if cached_data is not None and not cached_data.empty:
                        return symbol, cached_data
                    
                    # Fetch from yfinance
                    ticker = yf.Ticker(symbol)
                    df = ticker.history(period=yf_period, interval=yf_interval)
                    
                    # Rename columns to match our standard format
                    df = df.rename(columns={
                        'Open': 'open',
                        'High': 'high',
                        'Low': 'low',
                        'Close': 'close',
                        'Volume': 'volume'
                    })
                    
                    # Cache the data
                    if not df.empty:
                        self._save_to_cache(df, symbol, timeframe)
                    
                    return symbol, df
                except Exception as e:
                    error_msg = f"Error fetching data for {symbol} from yfinance: {e}"
                    logger.error(error_msg)
                    errors.append(error_msg)
                    return symbol, None
            
            # Execute fetches in parallel
            results = executor.map(fetch_symbol, symbols)
            
            # Process results
            for symbol, df in results:
                if df is not None and not df.empty:
                    data[symbol] = df
        
        # If we couldn't fetch data for any symbols, raise an exception
        if not data and errors:
            raise RuntimeError(f"Failed to fetch data from yfinance: {'; '.join(errors)}")
            
        return data
    
    def _fetch_from_alpha_vantage(self, symbols, timeframe, period):
        """
        Fetch data from Alpha Vantage
        
        Args:
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            period (str): Period to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        if 'alpha_vantage' not in self.sources:
            error_msg = "Alpha Vantage data source not initialized"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
            
        client = self.sources['alpha_vantage']['client']
        api_key = self.sources['alpha_vantage']['api_key']
        base_url = self.sources['alpha_vantage']['base_url']
        
        # Map timeframe to Alpha Vantage function and interval
        av_interval = self._map_timeframe(timeframe, 'alpha_vantage')
        
        if av_interval in ['daily', 'weekly', 'monthly']:
            function = f"TIME_SERIES_{av_interval.upper()}"
            params = {
                'function': function,
                'symbol': '',
                'apikey': api_key,
                'outputsize': 'full'
            }
        else:
            function = "TIME_SERIES_INTRADAY"
            params = {
                'function': function,
                'symbol': '',
                'interval': av_interval,
                'apikey': api_key,
                'outputsize': 'full'
            }
        
        data = {}
        errors = []
        
        for symbol in symbols:
            try:
                # Check cache first
                cached_data = self._load_from_cache(symbol, timeframe)
                
                if cached_data is not None and not cached_data.empty:
                    data[symbol] = cached_data
                    continue
                
                # Update symbol in params
                params['symbol'] = symbol
                
                # Fetch data
                response = client.get(base_url, params=params)
                response.raise_for_status()
                
                # Parse response
                json_data = response.json()
                
                # Check for error
                if 'Error Message' in json_data:
                    error_msg = f"Alpha Vantage error for {symbol}: {json_data['Error Message']}"
                    logger.error(error_msg)
                    errors.append(error_msg)
                    continue
                
                # Extract time series data
                if function == "TIME_SERIES_INTRADAY":
                    time_series_key = f"Time Series ({av_interval})"
                elif function == "TIME_SERIES_DAILY":
                    time_series_key = "Time Series (Daily)"
                elif function == "TIME_SERIES_WEEKLY":
                    time_series_key = "Weekly Time Series"
                elif function == "TIME_SERIES_MONTHLY":
                    time_series_key = "Monthly Time Series"
                else:
                    error_msg = f"Unknown Alpha Vantage function: {function}"
                    logger.error(error_msg)
                    errors.append(error_msg)
                    continue
                
                if time_series_key not in json_data:
                    error_msg = f"No time series data found for {symbol} with key {time_series_key}"
                    logger.error(error_msg)
                    errors.append(error_msg)
                    continue
                
                time_series = json_data[time_series_key]
                
                # Convert to DataFrame
                df = pd.DataFrame.from_dict(time_series, orient='index')
                
                # Rename columns
                df = df.rename(columns={
                    '1. open': 'open',
                    '2. high': 'high',
                    '3. low': 'low',
                    '4. close': 'close',
                    '5. volume': 'volume'
                })
                
                # Convert types
                for col in ['open', 'high', 'low', 'close']:
                    df[col] = pd.to_numeric(df[col])
                df['volume'] = pd.to_numeric(df['volume'])
                
                # Sort by date
                df.index = pd.to_datetime(df.index)
                df = df.sort_index()
                
                # Filter by period
                if period:
                    end_date = datetime.now()
                    
                    if period == '1day':
                        start_date = end_date - timedelta(days=1)
                    elif period == '1week':
                        start_date = end_date - timedelta(weeks=1)
                    elif period == '1month':
                        start_date = end_date - timedelta(days=30)
                    elif period == '3month':
                        start_date = end_date - timedelta(days=90)
                    elif period == '6month':
                        start_date = end_date - timedelta(days=180)
                    elif period == '1year':
                        start_date = end_date - timedelta(days=365)
                    elif period == '2year':
                        start_date = end_date - timedelta(days=730)
                    elif period == '5year':
                        start_date = end_date - timedelta(days=1825)
                    else:
                        # Default to 3 months
                        start_date = end_date - timedelta(days=90)
                    
                    df = df[df.index >= start_date]
                
                # Cache the data
                if not df.empty:
                    self._save_to_cache(df, symbol, timeframe)
                    data[symbol] = df
                
                # Rate limiting
                time.sleep(0.2)  # Alpha Vantage has a rate limit of 5 requests per minute for free tier
            except Exception as e:
                error_msg = f"Error fetching data for {symbol} from Alpha Vantage: {e}"
                logger.error(error_msg)
                errors.append(error_msg)
        
        # If we couldn't fetch data for any symbols, raise an exception
        if not data and errors:
            raise RuntimeError(f"Failed to fetch data from Alpha Vantage: {'; '.join(errors)}")
            
        return data
    
    def _filter_data_by_date(self, data, start_date, end_date):
        """
        Filter data by date range
        
        Args:
            data (dict): Dictionary of DataFrames with symbol as key
            start_date (str): Start date in YYYY-MM-DD format
            end_date (str): End date in YYYY-MM-DD format
            
        Returns:
            dict: Filtered dictionary of DataFrames with symbol as key
        """
        start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')
        
        filtered_data = {}
        
        for symbol, df in data.items():
            filtered_df = df[(df.index >= start_dt) & (df.index <= end_dt)]
            
            if not filtered_df.empty:
                filtered_data[symbol] = filtered_df
        
        return filtered_data
    
    def get_data(self, symbol, timeframe=None, start_date=None, end_date=None):
        """
        Get data for a single symbol
        
        Args:
            symbol (str): Stock symbol
            timeframe (str, optional): Timeframe to fetch data for
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            
        Returns:
            pandas.DataFrame: Data for the symbol
        """
        if start_date and end_date:
            data = self.get_multi_symbol_data([symbol], timeframe, start_date, end_date)
        else:
            data = self.get_historical_data([symbol], timeframe, self.history_period)
        
        if symbol in data:
            return data[symbol]
        else:
            error_msg = f"No data found for symbol {symbol}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
