"""
data_acquisition_enhanced.py - Enhanced Data Acquisition module for the Advanced Stock Scanner
"""

import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import time
from concurrent.futures import ThreadPoolExecutor
import json
import pickle
import sys
import requests
import traceback

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('data_acquisition')

class EnhancedDataAcquisition:
    """
    Enhanced data acquisition class for fetching stock data from various sources with improved reliability
    """
    
    def __init__(self, config):
        """
        Initialize the data acquisition module
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        self.data_config = config['data']
        self.primary_source = self.data_config['primary_source']
        self.backup_source = self.data_config['backup_source']
        self.api_keys = self.data_config['api_keys']
        self.default_symbols = self.data_config['default_symbols']
        self.timeframes = self.data_config['timeframes']
        self.history_period = self.data_config['history_period']
        
        # New configuration parameters
        self.cache_expiry_hours = self.data_config.get('cache_expiry_hours', 24)
        self.max_retries = self.data_config.get('max_retries', 3)
        self.retry_delay_seconds = self.data_config.get('retry_delay_seconds', 2)
        self.use_datasource_api = self.data_config.get('use_datasource_api', False)
        
        # Setup cache directory
        self.cache_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'cache')
        os.makedirs(self.cache_dir, exist_ok=True)
        
        # Initialize sources dictionary
        self.sources = {}
        
        # Track data source health - Initialize before calling _init_data_sources
        self.source_health = {
            'yfinance': {'status': 'unknown', 'last_check': None, 'failures': 0},
            'alpha_vantage': {'status': 'unknown', 'last_check': None, 'failures': 0},
            'alpaca': {'status': 'unknown', 'last_check': None, 'failures': 0},
            'datasource_api': {'status': 'unknown', 'last_check': None, 'failures': 0}
        }
        
        # Initialize data sources
        self._init_data_sources()
        
    def _init_data_sources(self):
        """Initialize data source clients based on configuration"""
        # Initialize Alpaca if configured
        if self.primary_source == 'alpaca' or self.backup_source == 'alpaca':
            try:
                from alpaca.data.historical import StockHistoricalDataClient
                from alpaca.trading.client import TradingClient
                
                api_key = self.api_keys['alpaca']['api_key']
                api_secret = self.api_keys['alpaca']['api_secret']
                
                if api_key and api_secret:
                    self.sources['alpaca'] = {
                        'data_client': StockHistoricalDataClient(api_key, api_secret),
                        'trading_client': TradingClient(api_key, api_secret, paper=True)
                    }
                    logger.info("Alpaca client initialized successfully")
                    self.source_health['alpaca']['status'] = 'available'
                else:
                    logger.warning("Alpaca API keys not provided")
                    self.source_health['alpaca']['status'] = 'unavailable'
            except Exception as e:
                logger.error(f"Failed to initialize Alpaca client: {e}")
                self.source_health['alpaca']['status'] = 'error'
        
        # Initialize yfinance if configured
        if self.primary_source == 'yfinance' or self.backup_source == 'yfinance':
            try:
                import yfinance as yf
                self.sources['yfinance'] = {'client': yf}
                logger.info("yfinance initialized successfully")
                self.source_health['yfinance']['status'] = 'available'
            except Exception as e:
                logger.error(f"Failed to initialize yfinance: {e}")
                self.source_health['yfinance']['status'] = 'error'
        
        # Initialize Alpha Vantage if configured
        if self.primary_source == 'alpha_vantage' or self.backup_source == 'alpha_vantage':
            try:
                from alpha_vantage.timeseries import TimeSeries
                
                api_key = self.api_keys['alpha_vantage']['api_key']
                
                if api_key:
                    self.sources['alpha_vantage'] = {
                        'client': TimeSeries(key=api_key, output_format='pandas'),
                        'api_key': api_key
                    }
                    logger.info("Alpha Vantage client initialized successfully")
                    self.source_health['alpha_vantage']['status'] = 'available'
                else:
                    logger.warning("Alpha Vantage API key not provided")
                    self.source_health['alpha_vantage']['status'] = 'unavailable'
            except Exception as e:
                logger.error(f"Failed to initialize Alpha Vantage client: {e}")
                self.source_health['alpha_vantage']['status'] = 'error'
        
        # Initialize datasource API if configured
        if self.use_datasource_api:
            try:
                sys.path.append('/opt/.manus/.sandbox-runtime')
                from data_api import ApiClient
                self.sources['datasource_api'] = {
                    'client': ApiClient()
                }
                logger.info("Datasource API client initialized successfully")
                self.source_health['datasource_api']['status'] = 'available'
            except Exception as e:
                logger.error(f"Failed to initialize Datasource API client: {e}")
                self.source_health['datasource_api']['status'] = 'error'
    
    def _map_timeframe(self, timeframe, source):
        """
        Map internal timeframe to source-specific timeframe
        
        Args:
            timeframe (str): Internal timeframe representation
            source (str): Data source name
            
        Returns:
            str: Source-specific timeframe
        """
        # Alpaca timeframe mapping
        alpaca_mapping = {
            '1min': '1Min',
            '5min': '5Min',
            '15min': '15Min',
            '30min': '30Min',
            '1hour': '1Hour',
            '1day': '1Day',
            '1week': '1Week'
        }
        
        # yfinance timeframe mapping
        yfinance_mapping = {
            '1min': '1m',
            '5min': '5m',
            '15min': '15m',
            '30min': '30m',
            '1hour': '1h',
            '1day': '1d',
            '1week': '1wk',
            '1month': '1mo'
        }
        
        # Alpha Vantage timeframe mapping
        alpha_vantage_mapping = {
            '1min': '1min',
            '5min': '5min',
            '15min': '15min',
            '30min': '30min',
            '1hour': '60min',
            '1day': 'daily',
            '1week': 'weekly',
            '1month': 'monthly'
        }
        
        # Datasource API timeframe mapping
        datasource_api_mapping = {
            '1min': '1m',
            '5min': '5m',
            '15min': '15m',
            '30min': '30m',
            '1hour': '60m',
            '1day': '1d',
            '1week': '1wk',
            '1month': '1mo'
        }
        
        if source == 'alpaca':
            return alpaca_mapping.get(timeframe, '1Day')
        elif source == 'yfinance':
            return yfinance_mapping.get(timeframe, '1d')
        elif source == 'alpha_vantage':
            return alpha_vantage_mapping.get(timeframe, 'daily')
        elif source == 'datasource_api':
            return datasource_api_mapping.get(timeframe, '1d')
        else:
            return timeframe
    
    def _map_period(self, period, source):
        """
        Map internal period to source-specific period
        
        Args:
            period (str): Internal period representation
            source (str): Data source name
            
        Returns:
            tuple: (start_date, end_date) or period string depending on source
        """
        end_date = datetime.now()
        
        if period == '1day':
            start_date = end_date - timedelta(days=1)
        elif period == '1week':
            start_date = end_date - timedelta(weeks=1)
        elif period == '1month':
            start_date = end_date - timedelta(days=30)
        elif period == '3month':
            start_date = end_date - timedelta(days=90)
        elif period == '6month':
            start_date = end_date - timedelta(days=180)
        elif period == '1year':
            start_date = end_date - timedelta(days=365)
        elif period == '2year':
            start_date = end_date - timedelta(days=730)
        elif period == '5year':
            start_date = end_date - timedelta(days=1825)
        else:
            # Default to 3 months
            start_date = end_date - timedelta(days=90)
        
        if source == 'alpaca':
            return start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')
        elif source == 'yfinance':
            # yfinance uses period strings
            yf_periods = {
                '1day': '1d',
                '1week': '1wk',
                '1month': '1mo',
                '3month': '3mo',
                '6month': '6mo',
                '1year': '1y',
                '2year': '2y',
                '5year': '5y'
            }
            return yf_periods.get(period, '3mo')
        elif source == 'datasource_api':
            # Datasource API uses range parameter
            datasource_api_periods = {
                '1day': '1d',
                '1week': '5d',
                '1month': '1mo',
                '3month': '3mo',
                '6month': '6mo',
                '1year': '1y',
                '2year': '2y',
                '5year': '5y'
            }
            return datasource_api_periods.get(period, '3mo')
        else:
            return start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')
    
    def _get_cache_path(self, symbol, timeframe, start_date=None, end_date=None):
        """
        Get cache file path for a specific symbol and timeframe
        
        Args:
            symbol (str): Stock symbol
            timeframe (str): Timeframe
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            
        Returns:
            str: Cache file path
        """
        if start_date and end_date:
            cache_file = f"{symbol}_{timeframe}_{start_date}_{end_date}.pkl"
        else:
            cache_file = f"{symbol}_{timeframe}.pkl"
        
        return os.path.join(self.cache_dir, cache_file)
    
    def _save_to_cache(self, data, symbol, timeframe, start_date=None, end_date=None):
        """
        Save data to cache
        
        Args:
            data (pandas.DataFrame): Data to save
            symbol (str): Stock symbol
            timeframe (str): Timeframe
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
        """
        cache_path = self._get_cache_path(symbol, timeframe, start_date, end_date)
        
        try:
            with open(cache_path, 'wb') as f:
                pickle.dump({
                    'data': data,
                    'timestamp': datetime.now().timestamp(),
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'start_date': start_date,
                    'end_date': end_date
                }, f)
            logger.info(f"Saved data to cache: {cache_path}")
        except Exception as e:
            logger.error(f"Error saving data to cache: {e}")
    
    def _load_from_cache(self, symbol, timeframe, start_date=None, end_date=None, max_age_hours=None):
        """
        Load data from cache if available and not expired
        
        Args:
            symbol (str): Stock symbol
            timeframe (str): Timeframe
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            max_age_hours (int, optional): Maximum age of cache in hours
            
        Returns:
            pandas.DataFrame or None: Cached data if available and not expired, None otherwise
        """
        if max_age_hours is None:
            max_age_hours = self.cache_expiry_hours
            
        cache_path = self._get_cache_path(symbol, timeframe, start_date, end_date)
        
        if not os.path.exists(cache_path):
            return None
        
        try:
            with open(cache_path, 'rb') as f:
                cache_data = pickle.load(f)
            
            # Check if cache is expired
            cache_timestamp = cache_data.get('timestamp', 0)
            cache_age_hours = (datetime.now().timestamp() - cache_timestamp) / 3600
            
            if cache_age_hours > max_age_hours:
                logger.info(f"Cache expired for {symbol} {timeframe}: {cache_age_hours:.2f} hours old")
                return None
            
            logger.info(f"Loaded data from cache: {cache_path}")
            return cache_data.get('data')
        except Exception as e:
            logger.error(f"Error loading data from cache: {e}")
            return None
    
    def _update_source_health(self, source, success):
        """
        Update health status of a data source
        
        Args:
            source (str): Data source name
            success (bool): Whether the last operation was successful
        """
        if source not in self.source_health:
            return
            
        self.source_health[source]['last_check'] = datetime.now()
        
        if success:
            self.source_health[source]['status'] = 'available'
            self.source_health[source]['failures'] = 0
        else:
            self.source_health[source]['failures'] += 1
            if self.source_health[source]['failures'] >= 3:
                self.source_health[source]['status'] = 'unavailable'
            else:
                self.source_health[source]['status'] = 'degraded'
    
    def _get_best_available_source(self):
        """
        Get the best available data source based on health status
        
        Returns:
            str: Best available data source name
        """
        # First check if primary source is available
        if self.source_health[self.primary_source]['status'] in ['available', 'unknown']:
            return self.primary_source
            
        # If primary source is unavailable, check backup source
        if self.backup_source and self.source_health[self.backup_source]['status'] in ['available', 'unknown']:
            return self.backup_source
            
        # If both primary and backup sources are unavailable, check other sources
        for source in self.source_health:
            if source not in [self.primary_source, self.backup_source] and self.source_health[source]['status'] in ['available', 'unknown']:
                return source
                
        # If all sources are unavailable, return primary source as a last resort
        return self.primary_source
    
    def _fetch_from_yfinance(self, symbols, timeframe, period):
        """
        Fetch data from Yahoo Finance
        
        Args:
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            period (str): Period to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbols as keys
        """
        try:
            if 'yfinance' not in self.sources:
                logger.error("yfinance not initialized")
                self._update_source_health('yfinance', False)
                return None
                
            yf_timeframe = self._map_timeframe(timeframe, 'yfinance')
            yf_period = self._map_period(period, 'yfinance')
            
            logger.info(f"Fetching data from yfinance for {len(symbols)} symbols with timeframe {yf_timeframe} and period {yf_period}")
            
            yf = self.sources['yfinance']['client']
            
            # Fetch data for all symbols at once
            data = yf.download(
                tickers=symbols,
                period=yf_period,
                interval=yf_timeframe,
                group_by='ticker',
                auto_adjust=True,
                prepost=False,
                threads=True
            )
            
            # Process data
            results = {}
            
            # If only one symbol, data is a DataFrame
            if len(symbols) == 1:
                symbol = symbols[0]
                if not data.empty:
                    # Standardize column names
                    data.columns = [col.lower() for col in data.columns]
                    results[symbol] = data
            else:
                # If multiple symbols, data is a multi-level DataFrame
                for symbol in symbols:
                    if symbol in data.columns.levels[0]:
                        symbol_data = data[symbol].copy()
                        if not symbol_data.empty:
                            # Standardize column names
                            symbol_data.columns = [col.lower() for col in symbol_data.columns]
                            results[symbol] = symbol_data
            
            self._update_source_health('yfinance', len(results) > 0)
            return results
        except Exception as e:
            logger.error(f"Error fetching data from yfinance: {e}")
            self._update_source_health('yfinance', False)
            return None
    
    def _fetch_from_alpha_vantage(self, symbols, timeframe, period):
        """
        Fetch data from Alpha Vantage
        
        Args:
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            period (str): Period to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbols as keys
        """
        try:
            if 'alpha_vantage' not in self.sources:
                logger.error("Alpha Vantage not initialized")
                self._update_source_health('alpha_vantage', False)
                return None
                
            av_timeframe = self._map_timeframe(timeframe, 'alpha_vantage')
            start_date, end_date = self._map_period(period, 'alpha_vantage')
            
            logger.info(f"Fetching data from Alpha Vantage for {len(symbols)} symbols with timeframe {av_timeframe}")
            
            # Alpha Vantage has strict rate limits, so we need to be careful
            results = {}
            
            for symbol in symbols:
                try:
                    data = self._fetch_single_symbol_alpha_vantage(symbol, av_timeframe)
                    
                    if data is not None and not data.empty:
                        # Fix for non-monotonic DatetimeIndex issue
                        # Ensure index is sorted and unique
                        data = data.sort_index()
                        
                        # Filter by date range - using string dates to avoid DatetimeIndex issues
                        if start_date and end_date:
                            try:
                                # Convert string dates to datetime for comparison
                                start_dt = pd.to_datetime(start_date)
                                end_dt = pd.to_datetime(end_date)
                                
                                # Filter using datetime comparison instead of label-based slicing
                                mask = (data.index >= start_dt) & (data.index <= end_dt)
                                data = data.loc[mask]
                            except Exception as e:
                                logger.warning(f"Error filtering data by date range: {e}")
                        
                        # Standardize column names
                        data.columns = [col.lower() for col in data.columns]
                        
                        # Rename columns to match yfinance format
                        column_mapping = {
                            '1. open': 'open',
                            '2. high': 'high',
                            '3. low': 'low',
                            '4. close': 'close',
                            '5. volume': 'volume'
                        }
                        
                        data = data.rename(columns=column_mapping)
                        
                        results[symbol] = data
                    
                    # Alpha Vantage has a rate limit of 5 calls per minute for free API keys
                    # Wait to avoid hitting rate limits
                    time.sleep(12)  # 12 seconds between calls = 5 calls per minute
                except Exception as e:
                    logger.error(f"Error fetching data for {symbol} from Alpha Vantage: {e}")
            
            self._update_source_health('alpha_vantage', len(results) > 0)
            return results
        except Exception as e:
            logger.error(f"Error fetching data from Alpha Vantage: {e}")
            self._update_source_health('alpha_vantage', False)
            return None
    
    def _fetch_single_symbol_alpha_vantage(self, symbol, timeframe):
        """
        Fetch data for a single symbol from Alpha Vantage with retries
        
        Args:
            symbol (str): Symbol to fetch data for
            timeframe (str): Timeframe to fetch data for
            
        Returns:
            pandas.DataFrame: Data for the symbol
        """
        alpha_vantage_client = self.sources['alpha_vantage']['client']
        
        for attempt in range(self.max_retries):
            try:
                # Different function calls based on timeframe
                if timeframe in ['1min', '5min', '15min', '30min', '60min']:
                    data, meta_data = alpha_vantage_client.get_intraday(
                        symbol=symbol,
                        interval=timeframe,
                        outputsize='full'
                    )
                elif timeframe == 'daily':
                    data, meta_data = alpha_vantage_client.get_daily(
                        symbol=symbol,
                        outputsize='full'
                    )
                elif timeframe == 'weekly':
                    data, meta_data = alpha_vantage_client.get_weekly(symbol=symbol)
                elif timeframe == 'monthly':
                    data, meta_data = alpha_vantage_client.get_monthly(symbol=symbol)
                else:
                    # Default to daily
                    data, meta_data = alpha_vantage_client.get_daily(
                        symbol=symbol,
                        outputsize='full'
                    )
                
                if data is not None and not data.empty:
                    # Ensure index is sorted
                    data = data.sort_index()
                    return data
                
                logger.warning(f"Empty data returned for {symbol} from Alpha Vantage, attempt {attempt + 1}/{self.max_retries}")
                time.sleep(self.retry_delay_seconds)
            except Exception as e:
                logger.warning(f"Error fetching data for {symbol} from Alpha Vantage, attempt {attempt + 1}/{self.max_retries}: {e}")
                time.sleep(self.retry_delay_seconds)
        
        logger.error(f"Failed to fetch data for {symbol} from Alpha Vantage after {self.max_retries} attempts")
        return None
    
    def _fetch_from_alpaca(self, symbols, timeframe, period):
        """
        Fetch data from Alpaca
        
        Args:
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            period (str): Period to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbols as keys
        """
        try:
            if 'alpaca' not in self.sources:
                logger.error("Alpaca not initialized")
                self._update_source_health('alpaca', False)
                return None
                
            from alpaca.data.requests import StockBarsRequest
            from alpaca.data.timeframe import TimeFrame
            
            alpaca_timeframe = self._map_timeframe(timeframe, 'alpaca')
            start_date, end_date = self._map_period(period, 'alpaca')
            
            logger.info(f"Fetching data from Alpaca for {len(symbols)} symbols with timeframe {alpaca_timeframe}")
            
            # Map timeframe string to TimeFrame object
            timeframe_mapping = {
                '1Min': TimeFrame.Minute,
                '5Min': TimeFrame.Minute,
                '15Min': TimeFrame.Minute,
                '30Min': TimeFrame.Minute,
                '1Hour': TimeFrame.Hour,
                '1Day': TimeFrame.Day,
                '1Week': TimeFrame.Week
            }
            
            # Map multiplier
            multiplier_mapping = {
                '1Min': 1,
                '5Min': 5,
                '15Min': 15,
                '30Min': 30,
                '1Hour': 1,
                '1Day': 1,
                '1Week': 1
            }
            
            timeframe_obj = timeframe_mapping.get(alpaca_timeframe, TimeFrame.Day)
            multiplier = multiplier_mapping.get(alpaca_timeframe, 1)
            
            # Convert string dates to datetime
            start_dt = pd.to_datetime(start_date)
            end_dt = pd.to_datetime(end_date)
            
            # Create request
            request_params = StockBarsRequest(
                symbol_or_symbols=symbols,
                timeframe=timeframe_obj,
                multiplier=multiplier,
                start=start_dt,
                end=end_dt,
                adjustment='all'
            )
            
            # Get data
            bars = self.sources['alpaca']['data_client'].get_stock_bars(request_params)
            
            # Process data
            results = {}
            
            if bars:
                # Convert to DataFrame
                df = bars.df
                
                # If only one symbol, data is a DataFrame
                if len(symbols) == 1:
                    symbol = symbols[0]
                    symbol_data = df.copy()
                    if not symbol_data.empty:
                        # Standardize column names
                        symbol_data.columns = [col.lower() for col in symbol_data.columns]
                        results[symbol] = symbol_data
                else:
                    # If multiple symbols, data is a multi-level DataFrame
                    for symbol in symbols:
                        try:
                            symbol_data = df.loc[symbol].copy()
                            if not symbol_data.empty:
                                # Standardize column names
                                symbol_data.columns = [col.lower() for col in symbol_data.columns]
                                results[symbol] = symbol_data
                        except Exception as e:
                            logger.warning(f"Error processing data for {symbol} from Alpaca: {e}")
            
            self._update_source_health('alpaca', len(results) > 0)
            return results
        except Exception as e:
            logger.error(f"Error fetching data from Alpaca: {e}")
            self._update_source_health('alpaca', False)
            return None
    
    def _fetch_from_datasource_api(self, symbols, timeframe, period):
        """
        Fetch data from Datasource API
        
        Args:
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            period (str): Period to fetch data for
            
        Returns:
            dict: Dictionary of DataFrames with symbols as keys
        """
        try:
            if 'datasource_api' not in self.sources:
                logger.error("Datasource API not initialized")
                self._update_source_health('datasource_api', False)
                return None
                
            ds_timeframe = self._map_timeframe(timeframe, 'datasource_api')
            ds_period = self._map_period(period, 'datasource_api')
            
            logger.info(f"Fetching data from Datasource API for {len(symbols)} symbols with timeframe {ds_timeframe} and period {ds_period}")
            
            client = self.sources['datasource_api']['client']
            results = {}
            
            for symbol in symbols:
                try:
                    # Call the API
                    response = client.call_api('YahooFinance/get_stock_chart', query={
                        'symbol': symbol,
                        'interval': ds_timeframe,
                        'range': ds_period,
                        'includeAdjustedClose': True
                    })
                    
                    if response and 'chart' in response and 'result' in response['chart'] and response['chart']['result']:
                        result = response['chart']['result'][0]
                        
                        # Extract timestamp and indicators
                        timestamps = result.get('timestamp', [])
                        quote = result.get('indicators', {}).get('quote', [{}])[0]
                        adjclose = result.get('indicators', {}).get('adjclose', [{}])[0]
                        
                        # Create DataFrame
                        data = {
                            'open': quote.get('open', []),
                            'high': quote.get('high', []),
                            'low': quote.get('low', []),
                            'close': quote.get('close', []),
                            'volume': quote.get('volume', []),
                            'adjclose': adjclose.get('adjclose', [])
                        }
                        
                        df = pd.DataFrame(data)
                        
                        # Convert timestamp to datetime index
                        if timestamps:
                            df.index = pd.to_datetime(timestamps, unit='s')
                            df.index.name = 'date'
                            
                            # Sort index to ensure it's monotonic
                            df = df.sort_index()
                            
                            results[symbol] = df
                    
                    # Add delay to avoid rate limits
                    time.sleep(1)
                except Exception as e:
                    logger.error(f"Error fetching data for {symbol} from Datasource API: {e}")
            
            self._update_source_health('datasource_api', len(results) > 0)
            return results
        except Exception as e:
            logger.error(f"Error fetching data from Datasource API: {e}")
            self._update_source_health('datasource_api', False)
            return None
    
    def get_historical_data(self, symbols, timeframe=None, period=None, use_cache=True):
        """
        Get historical data for multiple symbols
        
        Args:
            symbols (list): List of symbols to get data for
            timeframe (str, optional): Timeframe to get data for
            period (str, optional): Period to get data for
            use_cache (bool, optional): Whether to use cache
            
        Returns:
            dict: Dictionary of DataFrames with symbols as keys
        """
        if timeframe is None:
            timeframe = self.timeframes['primary']
            
        if period is None:
            period = self.history_period
            
        logger.info(f"Getting historical data for {len(symbols)} symbols with timeframe {timeframe} and period {period}")
        
        # Check cache first if enabled
        if use_cache:
            cached_results = {}
            for symbol in symbols:
                cached_data = self._load_from_cache(symbol, timeframe)
                if cached_data is not None:
                    cached_results[symbol] = cached_data
            
            if len(cached_results) == len(symbols):
                logger.info(f"All data loaded from cache for {len(symbols)} symbols")
                return cached_results
            
            # Remove symbols that were loaded from cache
            symbols = [s for s in symbols if s not in cached_results]
            logger.info(f"Loaded {len(cached_results)} symbols from cache, fetching {len(symbols)} remaining symbols")
        else:
            cached_results = {}
        
        # Get best available source
        source = self._get_best_available_source()
        logger.info(f"Using {source} as data source")
        
        # Fetch data from source
        results = None
        
        if source == 'yfinance':
            results = self._fetch_from_yfinance(symbols, timeframe, period)
        elif source == 'alpha_vantage':
            results = self._fetch_from_alpha_vantage(symbols, timeframe, period)
        elif source == 'alpaca':
            results = self._fetch_from_alpaca(symbols, timeframe, period)
        elif source == 'datasource_api':
            results = self._fetch_from_datasource_api(symbols, timeframe, period)
        
        # If primary source failed, try backup source
        if results is None or len(results) < len(symbols):
            missing_symbols = [s for s in symbols if s not in (results or {})]
            logger.warning(f"Primary source {source} failed for {len(missing_symbols)} symbols, trying backup source")
            
            if self.backup_source and self.backup_source != source:
                backup_results = None
                
                if self.backup_source == 'yfinance':
                    backup_results = self._fetch_from_yfinance(missing_symbols, timeframe, period)
                elif self.backup_source == 'alpha_vantage':
                    backup_results = self._fetch_from_alpha_vantage(missing_symbols, timeframe, period)
                elif self.backup_source == 'alpaca':
                    backup_results = self._fetch_from_alpaca(missing_symbols, timeframe, period)
                elif self.backup_source == 'datasource_api':
                    backup_results = self._fetch_from_datasource_api(missing_symbols, timeframe, period)
                
                # Merge results
                if backup_results:
                    if results is None:
                        results = backup_results
                    else:
                        results.update(backup_results)
        
        # If both primary and backup sources failed, try other sources
        if results is None or len(results) < len(symbols):
            missing_symbols = [s for s in symbols if s not in (results or {})]
            logger.warning(f"Both primary and backup sources failed for {len(missing_symbols)} symbols, trying other sources")
            
            for other_source in self.source_health:
                if other_source not in [source, self.backup_source] and self.source_health[other_source]['status'] in ['available', 'unknown']:
                    other_results = None
                    
                    if other_source == 'yfinance':
                        other_results = self._fetch_from_yfinance(missing_symbols, timeframe, period)
                    elif other_source == 'alpha_vantage':
                        other_results = self._fetch_from_alpha_vantage(missing_symbols, timeframe, period)
                    elif other_source == 'alpaca':
                        other_results = self._fetch_from_alpaca(missing_symbols, timeframe, period)
                    elif other_source == 'datasource_api':
                        other_results = self._fetch_from_datasource_api(missing_symbols, timeframe, period)
                    
                    # Merge results
                    if other_results:
                        if results is None:
                            results = other_results
                        else:
                            results.update(other_results)
                        
                        # Update missing symbols
                        missing_symbols = [s for s in missing_symbols if s not in other_results]
                        
                        if len(missing_symbols) == 0:
                            break
        
        # Save to cache
        if results:
            for symbol, data in results.items():
                if use_cache and not data.empty:
                    self._save_to_cache(data, symbol, timeframe)
        
        # Merge with cached results
        if cached_results:
            if results is None:
                results = cached_results
            else:
                results.update(cached_results)
        
        return results
    
    def get_symbol_data(self, symbol, timeframe=None, start_date=None, end_date=None, use_cache=True):
        """
        Get data for a single symbol
        
        Args:
            symbol (str): Symbol to get data for
            timeframe (str, optional): Timeframe to get data for
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            use_cache (bool, optional): Whether to use cache
            
        Returns:
            pandas.DataFrame: Data for the symbol
        """
        if timeframe is None:
            timeframe = self.timeframes['primary']
            
        logger.info(f"Getting data for {symbol} with timeframe {timeframe}")
        
        # Check cache first if enabled
        if use_cache and start_date and end_date:
            cached_data = self._load_from_cache(symbol, timeframe, start_date, end_date)
            if cached_data is not None:
                logger.info(f"Data loaded from cache for {symbol}")
                return cached_data
        elif use_cache:
            cached_data = self._load_from_cache(symbol, timeframe)
            if cached_data is not None:
                logger.info(f"Data loaded from cache for {symbol}")
                return cached_data
        
        # Get best available source
        source = self._get_best_available_source()
        logger.info(f"Using {source} as data source")
        
        # Fetch data from source
        results = None
        
        if start_date and end_date:
            # Calculate period based on start and end dates
            start_dt = pd.to_datetime(start_date)
            end_dt = pd.to_datetime(end_date)
            days_diff = (end_dt - start_dt).days
            
            if days_diff <= 7:
                period = '1week'
            elif days_diff <= 30:
                period = '1month'
            elif days_diff <= 90:
                period = '3month'
            elif days_diff <= 180:
                period = '6month'
            elif days_diff <= 365:
                period = '1year'
            elif days_diff <= 730:
                period = '2year'
            else:
                period = '5year'
        else:
            period = self.history_period
            start_date = None
            end_date = None
        
        if source == 'yfinance':
            results = self._fetch_from_yfinance([symbol], timeframe, period)
        elif source == 'alpha_vantage':
            results = self._fetch_from_alpha_vantage([symbol], timeframe, period)
        elif source == 'alpaca':
            results = self._fetch_from_alpaca([symbol], timeframe, period)
        elif source == 'datasource_api':
            results = self._fetch_from_datasource_api([symbol], timeframe, period)
        
        # If primary source failed, try backup source
        if results is None or symbol not in results:
            logger.warning(f"Primary source {source} failed for {symbol}, trying backup source")
            
            if self.backup_source and self.backup_source != source:
                if self.backup_source == 'yfinance':
                    results = self._fetch_from_yfinance([symbol], timeframe, period)
                elif self.backup_source == 'alpha_vantage':
                    results = self._fetch_from_alpha_vantage([symbol], timeframe, period)
                elif self.backup_source == 'alpaca':
                    results = self._fetch_from_alpaca([symbol], timeframe, period)
                elif self.backup_source == 'datasource_api':
                    results = self._fetch_from_datasource_api([symbol], timeframe, period)
        
        # If both primary and backup sources failed, try other sources
        if results is None or symbol not in results:
            logger.warning(f"Both primary and backup sources failed for {symbol}, trying other sources")
            
            for other_source in self.source_health:
                if other_source not in [source, self.backup_source] and self.source_health[other_source]['status'] in ['available', 'unknown']:
                    if other_source == 'yfinance':
                        results = self._fetch_from_yfinance([symbol], timeframe, period)
                    elif other_source == 'alpha_vantage':
                        results = self._fetch_from_alpha_vantage([symbol], timeframe, period)
                    elif other_source == 'alpaca':
                        results = self._fetch_from_alpaca([symbol], timeframe, period)
                    elif other_source == 'datasource_api':
                        results = self._fetch_from_datasource_api([symbol], timeframe, period)
                    
                    if results and symbol in results:
                        break
        
        # Extract data for symbol
        data = None
        if results and symbol in results:
            data = results[symbol]
            
            # Save to cache
            if use_cache and data is not None and not data.empty:
                if start_date and end_date:
                    self._save_to_cache(data, symbol, timeframe, start_date, end_date)
                else:
                    self._save_to_cache(data, symbol, timeframe)
        
        return data
    
    def get_multi_symbol_data(self, symbols, timeframe=None, start_date=None, end_date=None, use_cache=True):
        """
        Get data for multiple symbols with date range
        
        Args:
            symbols (list): List of symbols to get data for
            timeframe (str, optional): Timeframe to get data for
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            use_cache (bool, optional): Whether to use cache
            
        Returns:
            dict: Dictionary of DataFrames with symbols as keys
        """
        if timeframe is None:
            timeframe = self.timeframes['primary']
            
        logger.info(f"Getting data for {len(symbols)} symbols with timeframe {timeframe} and date range {start_date} to {end_date}")
        
        # Check cache first if enabled
        if use_cache and start_date and end_date:
            cached_results = {}
            for symbol in symbols:
                cached_data = self._load_from_cache(symbol, timeframe, start_date, end_date)
                if cached_data is not None:
                    cached_results[symbol] = cached_data
            
            if len(cached_results) == len(symbols):
                logger.info(f"All data loaded from cache for {len(symbols)} symbols")
                return cached_results
            
            # Remove symbols that were loaded from cache
            symbols = [s for s in symbols if s not in cached_results]
            logger.info(f"Loaded {len(cached_results)} symbols from cache, fetching {len(symbols)} remaining symbols")
        else:
            cached_results = {}
        
        # Calculate period based on start and end dates
        if start_date and end_date:
            start_dt = pd.to_datetime(start_date)
            end_dt = pd.to_datetime(end_date)
            days_diff = (end_dt - start_dt).days
            
            if days_diff <= 7:
                period = '1week'
            elif days_diff <= 30:
                period = '1month'
            elif days_diff <= 90:
                period = '3month'
            elif days_diff <= 180:
                period = '6month'
            elif days_diff <= 365:
                period = '1year'
            elif days_diff <= 730:
                period = '2year'
            else:
                period = '5year'
        else:
            period = self.history_period
            start_date = None
            end_date = None
        
        # Get best available source
        source = self._get_best_available_source()
        logger.info(f"Using {source} as data source")
        
        # Fetch data from source
        results = None
        
        if source == 'yfinance':
            results = self._fetch_from_yfinance(symbols, timeframe, period)
        elif source == 'alpha_vantage':
            results = self._fetch_from_alpha_vantage(symbols, timeframe, period)
        elif source == 'alpaca':
            results = self._fetch_from_alpaca(symbols, timeframe, period)
        elif source == 'datasource_api':
            results = self._fetch_from_datasource_api(symbols, timeframe, period)
        
        # If primary source failed, try backup source
        if results is None or len(results) < len(symbols):
            missing_symbols = [s for s in symbols if s not in (results or {})]
            logger.warning(f"Primary source {source} failed for {len(missing_symbols)} symbols, trying backup source")
            
            if self.backup_source and self.backup_source != source:
                backup_results = None
                
                if self.backup_source == 'yfinance':
                    backup_results = self._fetch_from_yfinance(missing_symbols, timeframe, period)
                elif self.backup_source == 'alpha_vantage':
                    backup_results = self._fetch_from_alpha_vantage(missing_symbols, timeframe, period)
                elif self.backup_source == 'alpaca':
                    backup_results = self._fetch_from_alpaca(missing_symbols, timeframe, period)
                elif self.backup_source == 'datasource_api':
                    backup_results = self._fetch_from_datasource_api(missing_symbols, timeframe, period)
                
                # Merge results
                if backup_results:
                    if results is None:
                        results = backup_results
                    else:
                        results.update(backup_results)
        
        # If both primary and backup sources failed, try other sources
        if results is None or len(results) < len(symbols):
            missing_symbols = [s for s in symbols if s not in (results or {})]
            logger.warning(f"Both primary and backup sources failed for {len(missing_symbols)} symbols, trying other sources")
            
            for other_source in self.source_health:
                if other_source not in [source, self.backup_source] and self.source_health[other_source]['status'] in ['available', 'unknown']:
                    other_results = None
                    
                    if other_source == 'yfinance':
                        other_results = self._fetch_from_yfinance(missing_symbols, timeframe, period)
                    elif other_source == 'alpha_vantage':
                        other_results = self._fetch_from_alpha_vantage(missing_symbols, timeframe, period)
                    elif other_source == 'alpaca':
                        other_results = self._fetch_from_alpaca(missing_symbols, timeframe, period)
                    elif other_source == 'datasource_api':
                        other_results = self._fetch_from_datasource_api(missing_symbols, timeframe, period)
                    
                    # Merge results
                    if other_results:
                        if results is None:
                            results = other_results
                        else:
                            results.update(other_results)
                        
                        # Update missing symbols
                        missing_symbols = [s for s in missing_symbols if s not in other_results]
                        
                        if len(missing_symbols) == 0:
                            break
        
        # Save to cache
        if results:
            for symbol, data in results.items():
                if use_cache and not data.empty:
                    if start_date and end_date:
                        self._save_to_cache(data, symbol, timeframe, start_date, end_date)
                    else:
                        self._save_to_cache(data, symbol, timeframe)
        
        # Merge with cached results
        if cached_results:
            if results is None:
                results = cached_results
            else:
                results.update(cached_results)
        
        return results
    
    def get_source_health(self):
        """
        Get health status of all data sources
        
        Returns:
            dict: Dictionary of health status for each data source
        """
        return self.source_health
    
    def clear_cache(self, older_than_hours=None):
        """
        Clear cache
        
        Args:
            older_than_hours (int, optional): Only clear cache older than this many hours
        """
        if not os.path.exists(self.cache_dir):
            return
            
        files = os.listdir(self.cache_dir)
        
        for file in files:
            if file.endswith('.pkl'):
                file_path = os.path.join(self.cache_dir, file)
                
                if older_than_hours is not None:
                    # Check file age
                    file_age_hours = (datetime.now().timestamp() - os.path.getmtime(file_path)) / 3600
                    
                    if file_age_hours <= older_than_hours:
                        continue
                
                try:
                    os.remove(file_path)
                    logger.info(f"Removed cache file: {file}")
                except Exception as e:
                    logger.error(f"Error removing cache file {file}: {e}")
