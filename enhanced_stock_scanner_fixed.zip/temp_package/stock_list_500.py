"""
stock_list_500.py - List of 500 stocks for the Advanced Stock Scanner
"""

# List of 500 stocks including major indices and popular stocks
STOCK_LIST_500 = [
    # S&P 500 Top Components
    "AAPL", "MSFT", "AMZN", "GOOGL", "META", "TSLA", "NVDA", "JPM", "V", "JNJ",
    "WMT", "PG", "MA", "UNH", "HD", "BAC", "XOM", "DIS", "ADBE", "CRM",
    "NFLX", "INTC", "VZ", "CSCO", "PFE", "ABT", "KO", "PEP", "T", "MRK",
    "CMCSA", "NKE", "TMO", "ABBV", "AVGO", "ACN", "COST", "MCD", "DHR", "LLY",
    "MDT", "TXN", "NEE", "BMY", "UNP", "PM", "QCOM", "ORCL", "HON", "LIN",
    
    # More S&P 500 Components
    "AMT", "CVX", "AMGN", "PYPL", "SBUX", "IBM", "MMM", "CHTR", "CAT", "GS",
    "LMT", "SPGI", "BLK", "GILD", "MDLZ", "AXP", "TGT", "BKNG", "USB", "CI",
    "ANTM", "TJX", "FIS", "ADP", "CME", "CCI", "ICE", "EQIX", "DUK", "SO",
    "MS", "ISRG", "VRTX", "ZTS", "PLD", "REGN", "ATVI", "SYK", "CL", "CB",
    "GE", "BSX", "ILMN", "FISV", "INTU", "MO", "CSX", "SCHW", "PNC", "D",
    "APD", "ECL", "EW", "HUM", "DG", "SHW", "ITW", "KMB", "WM", "ADI",
    "BIIB", "AEP", "EL", "AMAT", "ADSK", "ROST", "GPN", "EA", "ALL", "PSA",
    "TMUS", "MNST", "ORLY", "CTSH", "EBAY", "IDXX", "WLTW", "YUM", "TWTR", "ALGN",
    "CTAS", "KLAC", "SNPS", "CDNS", "DXCM", "MCHP", "XLNX", "ANSS", "FAST", "CPRT",
    "DLTR", "PCAR", "PAYX", "VRSK", "NXPI", "ALXN", "MXIM", "SWKS", "CERN", "SIRI",
    
    # NASDAQ Components
    "GOOG", "AMZN", "FB", "TSLA", "NVDA", "PYPL", "ADBE", "CMCSA", "NFLX", "PEP",
    "CSCO", "AVGO", "COST", "TMUS", "CHTR", "INTC", "QCOM", "GILD", "MDLZ", "BKNG",
    "SBUX", "AMAT", "AMD", "MU", "LRCX", "ATVI", "CSX", "FISV", "BIDU", "JD",
    "MELI", "ILMN", "VRTX", "ADI", "REGN", "ADSK", "BIIB", "MNST", "KHC", "LULU",
    "EA", "EBAY", "CTSH", "XEL", "ORLY", "WDAY", "PCAR", "ROST", "VRSK", "NTES",
    "SGEN", "SPLK", "CTAS", "KLAC", "VRSN", "ANSS", "CDNS", "FAST", "CPRT", "INCY",
    "SIRI", "SWKS", "MXIM", "CERN", "TCOM", "BMRN", "ULTA", "NTAP", "FOXA", "FOX",
    
    # Dow Jones Components
    "MMM", "AXP", "AMGN", "AAPL", "BA", "CAT", "CVX", "CSCO", "KO", "DIS",
    "DOW", "GS", "HD", "HON", "IBM", "INTC", "JNJ", "JPM", "MCD", "MRK",
    "MSFT", "NKE", "PG", "CRM", "TRV", "UNH", "VZ", "V", "WBA", "WMT",
    
    # Russell 2000 Components (Small Cap)
    "PLUG", "RIOT", "MARA", "FCEL", "BLNK", "WKHS", "RIDE", "GEVO", "SOLO", "CLNE",
    "SNDL", "CLOV", "WISH", "SKLZ", "PLTR", "SPCE", "OPEN", "DKNG", "FUBO", "BNGO",
    "MVIS", "SENS", "EXPR", "BBBY", "AMC", "GME", "BB", "NOK", "KOSS", "NAKD",
    
    # International Stocks (ADRs)
    "BABA", "TSM", "NVO", "ASML", "TM", "SAP", "BP", "PBR", "RIO", "BHP",
    "HSBC", "AZN", "NVS", "UL", "DEO", "BTI", "RY", "TD", "BCS", "CS",
    "DB", "UBS", "EQNR", "SAN", "BBVA", "IBN", "HDB", "ITUB", "BBD", "CIG",
    
    # ETFs
    "SPY", "QQQ", "IWM", "DIA", "VTI", "VOO", "VEA", "VWO", "BND", "AGG",
    "GLD", "SLV", "USO", "UNG", "TLT", "IEF", "SHY", "HYG", "LQD", "VCIT",
    "VNQ", "XLF", "XLE", "XLK", "XLV", "XLI", "XLY", "XLP", "XLU", "XLB",
    "ARKK", "ARKW", "ARKG", "ARKF", "ARKQ", "ICLN", "TAN", "FAN", "PBW", "QCLN",
    
    # Growth Stocks
    "SQ", "SHOP", "ZM", "DOCU", "ROKU", "CRWD", "NET", "DDOG", "SNOW", "OKTA",
    "ZS", "FSLY", "TWLO", "TTD", "PINS", "SNAP", "ETSY", "W", "PTON", "TDOC",
    "CRSP", "EDIT", "NTLA", "BEAM", "PACB", "EXAS", "NVTA", "TWST", "FATE", "TXG",
    
    # Value Stocks
    "BRK.B", "JNJ", "PG", "KO", "PEP", "MO", "PM", "MRK", "PFE", "ABT",
    "BMY", "LLY", "ABBV", "AMGN", "GILD", "CVS", "WBA", "CI", "HUM", "UNH",
    
    # Dividend Stocks
    "T", "VZ", "MO", "PM", "XOM", "CVX", "BP", "RDS.A", "TOT", "ENB",
    "KMI", "EPD", "MMP", "ET", "OKE", "WMB", "D", "SO", "DUK", "NEE",
    
    # Tech Stocks
    "AAPL", "MSFT", "GOOGL", "AMZN", "FB", "TSLA", "NVDA", "PYPL", "ADBE", "CRM",
    "NFLX", "INTC", "CSCO", "ORCL", "IBM", "AMD", "MU", "TSM", "AVGO", "TXN",
    
    # Healthcare Stocks
    "JNJ", "PFE", "MRK", "ABBV", "ABT", "LLY", "AMGN", "BMY", "GILD", "TMO",
    "DHR", "ISRG", "MDT", "SYK", "ZTS", "REGN", "VRTX", "BIIB", "ILMN", "IDXX",
    
    # Financial Stocks
    "JPM", "BAC", "WFC", "C", "GS", "MS", "BLK", "SCHW", "AXP", "V",
    "MA", "PYPL", "SQ", "COF", "USB", "PNC", "TFC", "FITB", "RF", "CFG",
    
    # Energy Stocks
    "XOM", "CVX", "COP", "EOG", "PXD", "OXY", "MPC", "PSX", "VLO", "KMI",
    "WMB", "ET", "EPD", "MMP", "OKE", "ENB", "TRP", "BP", "TOT", "RDS.A"
]

def get_stock_list():
    """
    Get the list of 500 stocks
    
    Returns:
        list: List of 500 stock symbols
    """
    return STOCK_LIST_500

def get_default_symbols():
    """
    Get the default list of stock symbols for scanning
    
    Returns:
        list: List of stock symbols for scanning
    """
    return STOCK_LIST_500
