import os
import json

def update_config_with_alpha_vantage_key(api_key):
    """
    Update the user_config.json file with the provided Alpha Vantage API key
    and set Alpha Vantage as the primary data source
    
    Args:
        api_key (str): Alpha Vantage API key
    """
    config_dir = os.path.dirname(os.path.abspath(__file__))
    user_config_path = os.path.join(config_dir, 'config', 'user_config.json')
    
    # Create default config if it doesn't exist
    if not os.path.exists(user_config_path):
        os.makedirs(os.path.dirname(user_config_path), exist_ok=True)
        user_config = {}
    else:
        # Load existing config
        with open(user_config_path, 'r') as f:
            user_config = json.load(f)
    
    # Ensure data section exists
    if 'data' not in user_config:
        user_config['data'] = {}
    
    # Set Alpha Vantage as primary source and yfinance as backup
    user_config['data']['primary_source'] = 'alpha_vantage'
    user_config['data']['backup_source'] = 'yfinance'
    
    # Ensure api_keys section exists
    if 'api_keys' not in user_config['data']:
        user_config['data']['api_keys'] = {}
    
    # Ensure alpha_vantage section exists
    if 'alpha_vantage' not in user_config['data']['api_keys']:
        user_config['data']['api_keys']['alpha_vantage'] = {}
    
    # Set API key
    user_config['data']['api_keys']['alpha_vantage']['api_key'] = api_key
    
    # Save updated config
    with open(user_config_path, 'w') as f:
        json.dump(user_config, f, indent=4)
    
    print(f"Updated configuration with Alpha Vantage API key and set as primary data source")

if __name__ == "__main__":
    # Get API key from user
    api_key = input("Enter your Alpha Vantage API key: ")
    update_config_with_alpha_vantage_key(api_key)
    print("Configuration updated successfully. You can now run the scanner with Alpha Vantage as the primary data source.")
