"""
app.py - Streamlit interface for the Advanced Stock Scanner
"""

import streamlit as st
import pandas as pd
import numpy as np
import os
import datetime
import time
import json
import traceback
from datetime import datetime, timedelta

# Import modules
from data.data_acquisition import DataAcquisition
from utils.accuracy_optimizer import AccuracyOptimizer
from utils.technical_analysis_enhanced import EnhancedTechnicalAnalysis
from utils.machine_learning_enhanced import EnhancedMachineLearningEngine
from utils.performance_optimizer import PerformanceOptimizer
from scanner_enhanced import EnhancedStockScanner
from config.enhanced_config import get_config

# Set page config
st.set_page_config(
    page_title="Advanced Stock Scanner",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
    
if 'username' not in st.session_state:
    st.session_state.username = None
    
if 'scanner_results' not in st.session_state:
    st.session_state.scanner_results = None
    
if 'selected_symbol' not in st.session_state:
    st.session_state.selected_symbol = None
    
if 'detailed_analysis' not in st.session_state:
    st.session_state.detailed_analysis = None
    
if 'portfolio' not in st.session_state:
    st.session_state.portfolio = []
    
if 'watchlist' not in st.session_state:
    st.session_state.watchlist = []
    
if 'alerts' not in st.session_state:
    st.session_state.alerts = []
    
if 'scan_error' not in st.session_state:
    st.session_state.scan_error = None

# Load configuration
config = get_config()

# Define user credentials (in a real app, this would be in a database)
users = {
    'admin': {
        'password': 'admin',
        'role': 'admin'
    },
    'user': {
        'password': 'user',
        'role': 'user'
    }
}

# Login page
def login_page():
    st.title("Login to Advanced Stock Scanner")
    
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")
        
        if submit:
            if username in users and users[username]['password'] == password:
                st.session_state.logged_in = True
                st.session_state.username = username
                st.success(f"Welcome, {username}!")
                st.rerun()
            else:
                st.error("Invalid username or password")

# Main app
def main_app():
    # Sidebar
    with st.sidebar:
        st.title("Navigation")
        
        # Page selection
        page = st.selectbox(
            "Select Page",
            options=["Scanner", "Portfolio", "Watchlist", "Alerts", "Settings"]
        )
        
        # Display logged in user
        st.write(f"Logged in as: {st.session_state.username} ({users[st.session_state.username]['role']})")
        
        # Logout button
        if st.button("Logout"):
            st.session_state.logged_in = False
            st.session_state.username = None
            st.rerun()
    
    # Display selected page
    if page == "Scanner":
        scanner_page()
    elif page == "Portfolio":
        portfolio_page()
    elif page == "Watchlist":
        watchlist_page()
    elif page == "Alerts":
        alerts_page()
    elif page == "Settings":
        settings_page()

# Scanner page
def scanner_page():
    st.title("Advanced Stock Scanner")
    
    # Clear any previous scan errors
    if st.session_state.scan_error:
        st.session_state.scan_error = None
    
    # Scanner form
    with st.form("scanner_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            # Date range
            start_date = st.date_input(
                "Start Date",
                value=datetime.now() - timedelta(days=30)
            )
            
            # Symbol input
            symbols_input = st.text_area(
                "Symbols (comma-separated, leave empty for default list)",
                value="",
                help="Enter stock symbols separated by commas, or leave empty to use the default list"
            )
        
        with col2:
            # End date
            end_date = st.date_input(
                "End Date",
                value=datetime.now()
            )
            
            # Timeframe selection
            timeframe = st.selectbox(
                "Timeframe",
                options=["1min", "5min", "15min", "30min", "1hour", "1day", "1week"],
                index=2,  # Default to 15min
                help="Select the timeframe for analysis"
            )
        
        # Advanced settings
        with st.expander("Advanced Settings"):
            # Performance optimization
            use_optimization = st.checkbox(
                "Use Performance Optimization",
                value=True,
                help="Enable performance optimization for faster scanning"
            )
            
            # Technical indicators
            st.subheader("Technical Indicators")
            
            # SMA parameters
            col1, col2 = st.columns(2)
            with col1:
                sma_fast = st.number_input(
                    "Fast SMA Period",
                    min_value=1,
                    max_value=50,
                    value=14,
                    help="Fast Simple Moving Average period"
                )
            
            with col2:
                sma_slow = st.number_input(
                    "Slow SMA Period",
                    min_value=1,
                    max_value=200,
                    value=40,
                    help="Slow Simple Moving Average period"
                )
            
            # RSI parameters
            col1, col2 = st.columns(2)
            with col1:
                rsi_period = st.number_input(
                    "RSI Period",
                    min_value=1,
                    max_value=30,
                    value=14,
                    help="Relative Strength Index period"
                )
            
            with col2:
                rsi_overbought = st.number_input(
                    "RSI Overbought Level",
                    min_value=50,
                    max_value=100,
                    value=70,
                    help="RSI level considered overbought"
                )
                
                rsi_oversold = st.number_input(
                    "RSI Oversold Level",
                    min_value=0,
                    max_value=50,
                    value=30,
                    help="RSI level considered oversold"
                )
            
            # MACD parameters
            col1, col2, col3 = st.columns(3)
            with col1:
                macd_fast = st.number_input(
                    "MACD Fast Period",
                    min_value=1,
                    max_value=50,
                    value=12,
                    help="MACD fast EMA period"
                )
            
            with col2:
                macd_slow = st.number_input(
                    "MACD Slow Period",
                    min_value=1,
                    max_value=100,
                    value=26,
                    help="MACD slow EMA period"
                )
            
            with col3:
                macd_signal = st.number_input(
                    "MACD Signal Period",
                    min_value=1,
                    max_value=50,
                    value=9,
                    help="MACD signal period"
                )
            
            # Bollinger Bands parameters
            col1, col2 = st.columns(2)
            with col1:
                bb_period = st.number_input(
                    "Bollinger Bands Period",
                    min_value=1,
                    max_value=50,
                    value=20,
                    help="Bollinger Bands period"
                )
            
            with col2:
                bb_std = st.number_input(
                    "Bollinger Bands Standard Deviation",
                    min_value=0.1,
                    max_value=5.0,
                    value=2.0,
                    step=0.1,
                    help="Bollinger Bands standard deviation multiplier"
                )
            
            # Confidence threshold
            confidence_threshold = st.slider(
                "Minimum Confidence Score",
                min_value=0,
                max_value=100,
                value=50,
                help="Minimum confidence score for signals (0-100)"
            )
        
        # Submit button
        submit = st.form_submit_button("Run Scan")
    
    # Process form submission
    if submit:
        # Parse symbols
        if symbols_input.strip():
            symbols = [s.strip().upper() for s in symbols_input.split(',')]
        else:
            symbols = config['data']['default_symbols']
        
        # Update config with form values
        config['technical_analysis']['sma_periods'] = [sma_fast, sma_slow]
        config['technical_analysis']['rsi_period'] = rsi_period
        config['technical_analysis']['rsi_overbought'] = rsi_overbought
        config['technical_analysis']['rsi_oversold'] = rsi_oversold
        config['technical_analysis']['macd_periods'] = [macd_fast, macd_slow, macd_signal]
        config['technical_analysis']['bollinger_periods'] = bb_period
        config['technical_analysis']['bollinger_std'] = bb_std
        config['scanner']['confidence_threshold'] = confidence_threshold
        
        try:
            with st.spinner("Running scan..."):
                # Initialize modules
                data_acquisition = DataAcquisition(config)
                technical_analysis = EnhancedTechnicalAnalysis(config)
                machine_learning = EnhancedMachineLearningEngine(config)
                
                # Apply performance optimization if enabled
                if use_optimization:
                    optimizer = PerformanceOptimizer(config)
                    data_acquisition = optimizer.optimize_data_acquisition(data_acquisition)
                    technical_analysis = optimizer.optimize_technical_analysis(technical_analysis)
                    machine_learning = optimizer.optimize_machine_learning(machine_learning)
                
                # Initialize scanner
                scanner = EnhancedStockScanner(config, data_acquisition, technical_analysis, machine_learning)
                
                # Apply accuracy optimizations
                accuracy_optimizer = AccuracyOptimizer(config)
                scanner, data_acquisition, technical_analysis, machine_learning = accuracy_optimizer.apply_accuracy_enhancements(
                    scanner, data_acquisition, technical_analysis, machine_learning
                )
                
                # Run scan
                results = scanner.scan(
                    symbols=symbols,
                    timeframes=[timeframe],
                    start_date=start_date.strftime("%Y-%m-%d"),
                    end_date=end_date.strftime("%Y-%m-%d")
                )
                
                # Store results in session state
                st.session_state.scanner_results = results
                
                # If we have results, set the first symbol as selected for detailed analysis
                if not results.empty:
                    st.session_state.selected_symbol = results.iloc[0]["symbol"]
                    
                    # Get detailed analysis for the selected symbol
                    detailed_analysis = scanner.get_detailed_analysis(
                        symbol=st.session_state.selected_symbol,
                        timeframes=[timeframe]
                    )
                    
                    st.session_state.detailed_analysis = detailed_analysis
        except Exception as e:
            # Store error in session state
            st.session_state.scan_error = str(e)
            st.error(f"Error running scan: {str(e)}")
            st.error("Please check your inputs and try again.")
            
            # Show detailed error for debugging
            if users[st.session_state.username]['role'] == 'admin':
                st.expander("Detailed Error Information (Admin Only)").code(traceback.format_exc())
                
                # Provide specific guidance for common errors
                if "15-minute data" in str(e) and "60-day limit" in str(e):
                    st.warning("""
                    **Yahoo Finance Limitation**: 15-minute data is only available for the last 60 days.
                    
                    Please adjust your date range to be within the last 60 days, or switch to a different timeframe.
                    """)
    
    # Display scan error if exists
    if st.session_state.scan_error:
        st.error(f"Error from previous scan: {st.session_state.scan_error}")
        
        # Provide specific guidance for common errors
        if "15-minute data" in st.session_state.scan_error and "60-day limit" in st.session_state.scan_error:
            st.warning("""
            **Yahoo Finance Limitation**: 15-minute data is only available for the last 60 days.
            
            Please adjust your date range to be within the last 60 days, or switch to a different timeframe.
            """)
    
    # Display scan results
    if st.session_state.scanner_results is not None and not st.session_state.scanner_results.empty:
        st.success("Scan completed successfully!")
        
        # Display results table
        st.header("Scan Results")
        
        # Format the results for display
        display_results = st.session_state.scanner_results.copy()
        
        # Add color coding for signal type
        def color_signal(val):
            if 'strong_bullish' in str(val).lower():
                return 'background-color: darkgreen; color: white'
            elif 'bullish' in str(val).lower():
                return 'background-color: green; color: white'
            elif 'strong_bearish' in str(val).lower():
                return 'background-color: darkred; color: white'
            elif 'bearish' in str(val).lower():
                return 'background-color: red; color: white'
            return ''
        
        # Format price targets to show percentage change
        for col in ['price_target_1d', 'price_target_1w', 'price_target_1m']:
            if col in display_results.columns:
                display_results[f'{col}_pct'] = ((display_results[col] / display_results['close']) - 1) * 100
                display_results[f'{col}_pct'] = display_results[f'{col}_pct'].round(2).astype(str) + '%'
        
        # Format stop loss if available
        if 'stop_loss' in display_results.columns:
            display_results['stop_loss_pct'] = ((display_results['stop_loss'] / display_results['close']) - 1) * 100
            display_results['stop_loss_pct'] = display_results['stop_loss_pct'].round(2).astype(str) + '%'
            
        # Format risk-reward ratio if available
        if 'risk_reward_ratio' in display_results.columns:
            display_results['risk_reward_ratio'] = display_results['risk_reward_ratio'].round(2).astype(str) + ':1'
        
        # Select columns to display
        display_cols = [
            'symbol', 'timeframe', 'close', 'signal_type', 'confidence_score',
            'stop_loss', 'stop_loss_pct', 'price_target_1w', 'price_target_1w_pct',
            'risk_reward_ratio', 'entry_quality', 'trend_direction', 'volume_analysis'
        ]
        
        # Filter to only columns that exist
        display_cols = [col for col in display_cols if col in display_results.columns]
        
        # Display the styled table
        st.dataframe(
            display_results[display_cols].style.applymap(color_signal, subset=['signal_type']),
            height=300
        )
        
        # Add a bullish scan button
        if st.button("Show Only Bullish Stocks with Stop Loss"):
            with st.spinner("Running bullish scan..."):
                try:
                    # Initialize scanner
                    data_acquisition = DataAcquisition(config)
                    technical_analysis = EnhancedTechnicalAnalysis(config)
                    machine_learning = EnhancedMachineLearningEngine(config)
                    scanner = EnhancedStockScanner(config, data_acquisition, technical_analysis, machine_learning)
                    
                    # Run bullish scan
                    bullish_results = scanner.scan_for_bullish_stocks(
                        symbols=symbols,
                        timeframe=timeframe,
                        min_confidence=confidence_threshold
                    )
                    
                    if not bullish_results.empty:
                        st.success(f"Found {len(bullish_results)} bullish stocks!")
                        
                        # Format for display
                        display_bullish = bullish_results.copy()
                        
                        # Format percentages
                        display_bullish['stop_loss_pct'] = display_bullish['stop_loss_pct'].round(2).astype(str) + '%'
                        display_bullish['profit_potential_pct'] = display_bullish['profit_potential_pct'].round(2).astype(str) + '%'
                        display_bullish['risk_reward_ratio'] = display_bullish['risk_reward_ratio'].round(2).astype(str) + ':1'
                        
                        # Select columns for bullish display
                        bullish_cols = [
                            'symbol', 'close', 'signal_type', 'confidence_score',
                            'stop_loss', 'stop_loss_pct', 'price_target_1w', 'profit_potential_pct',
                            'risk_reward_ratio', 'entry_quality'
                        ]
                        
                        # Filter columns that exist
                        bullish_cols = [col for col in bullish_cols if col in display_bullish.columns]
                        
                        # Create styled dataframe
                        styled_bullish = display_bullish[bullish_cols].style.applymap(
                            color_signal, subset=['signal_type']
                        )
                        
                        # Display the styled dataframe
                        st.subheader("Bullish Stocks with Stop Loss Levels")
                        st.dataframe(styled_bullish)
                        
                        # Add explanation of columns
                        with st.expander("Column Explanations"):
                            st.markdown("""
                            - **symbol**: Stock symbol
                            - **close**: Latest closing price
                            - **signal_type**: Type of trading signal detected
                            - **confidence_score**: Confidence level of the prediction (0-100)
                            - **stop_loss**: Recommended stop loss price level
                            - **stop_loss_pct**: Stop loss as percentage from current price
                            - **price_target_1w**: Price target for 1 week
                            - **profit_potential_pct**: Potential profit percentage
                            - **risk_reward_ratio**: Ratio of potential reward to risk
                            - **entry_quality**: Overall quality score for the trade setup
                            """)
                    else:
                        st.warning("No bullish stocks found matching the criteria.")
                except Exception as e:
                    st.error(f"Error running bullish scan: {str(e)}")
                    if users[st.session_state.username]['role'] == 'admin':
                        st.expander("Detailed Error Information (Admin Only)").code(traceback.format_exc())
        
        # Symbol selection for detailed analysis
        st.header("Detailed Analysis")
        selected_symbol = st.selectbox(
            "Select Symbol for Detailed Analysis",
            options=display_results['symbol'].unique(),
            index=list(display_results['symbol'].unique()).index(st.session_state.selected_symbol) 
                if st.session_state.selected_symbol in display_results['symbol'].unique() else 0
        )
        
        # Update selected symbol if changed
        if selected_symbol != st.session_state.selected_symbol:
            st.session_state.selected_symbol = selected_symbol
            
            # Initialize modules
            data_acquisition = DataAcquisition(config)
            technical_analysis = EnhancedTechnicalAnalysis(config)
            machine_learning = EnhancedMachineLearningEngine(config)
            
            # Initialize scanner
            scanner = EnhancedStockScanner(config, data_acquisition, technical_analysis, machine_learning)
            
            # Get detailed analysis for the selected symbol
            try:
                detailed_analysis = scanner.get_detailed_analysis(
                    symbol=selected_symbol,
                    timeframes=[timeframe]
                )
                
                st.session_state.detailed_analysis = detailed_analysis
            except Exception as e:
                st.error(f"Error getting detailed analysis: {str(e)}")
                st.session_state.detailed_analysis = None
        
        # Display detailed analysis
        if st.session_state.detailed_analysis is not None:
            display_detailed_analysis(st.session_state.detailed_analysis, timeframe)
        
        # Add to portfolio/watchlist buttons
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Add to Portfolio"):
                if selected_symbol not in [item['symbol'] for item in st.session_state.portfolio]:
                    st.session_state.portfolio.append({
                        'symbol': selected_symbol,
                        'entry_price': display_results[display_results['symbol'] == selected_symbol]['close'].values[0],
                        'entry_date': datetime.now().strftime("%Y-%m-%d"),
                        'quantity': 0,
                        'notes': ''
                    })
                    st.success(f"Added {selected_symbol} to portfolio!")
                else:
                    st.warning(f"{selected_symbol} is already in your portfolio.")
        
        with col2:
            if st.button("Add to Watchlist"):
                if selected_symbol not in [item['symbol'] for item in st.session_state.watchlist]:
                    st.session_state.watchlist.append({
                        'symbol': selected_symbol,
                        'added_date': datetime.now().strftime("%Y-%m-%d"),
                        'notes': ''
                    })
                    st.success(f"Added {selected_symbol} to watchlist!")
                else:
                    st.warning(f"{selected_symbol} is already in your watchlist.")

# Display detailed analysis
def display_detailed_analysis(detailed_analysis, timeframe):
    if timeframe not in detailed_analysis:
        st.warning(f"No detailed analysis available for {timeframe} timeframe.")
        return
    
    data = detailed_analysis[timeframe]
    
    # Get the latest data point
    latest = data.iloc[-1]
    
    # Display key metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Close", f"${latest['close']:.2f}")
    
    with col2:
        if 'signal_type' in latest:
            st.metric("Signal", latest['signal_type'])
    
    with col3:
        if 'confidence_score' in latest:
            st.metric("Confidence", f"{latest['confidence_score']:.0f}%")
    
    with col4:
        if 'trend_direction' in latest:
            st.metric("Trend", latest['trend_direction'])
    
    # Display price targets
    st.subheader("Price Targets")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if 'price_target_1d' in latest and not pd.isna(latest['price_target_1d']):
            pct_change = ((latest['price_target_1d'] / latest['close']) - 1) * 100
            st.metric(
                "1-Day Target", 
                f"${latest['price_target_1d']:.2f}",
                f"{pct_change:.2f}%"
            )
    
    with col2:
        if 'price_target_1w' in latest and not pd.isna(latest['price_target_1w']):
            pct_change = ((latest['price_target_1w'] / latest['close']) - 1) * 100
            st.metric(
                "1-Week Target", 
                f"${latest['price_target_1w']:.2f}",
                f"{pct_change:.2f}%"
            )
    
    with col3:
        if 'price_target_1m' in latest and not pd.isna(latest['price_target_1m']):
            pct_change = ((latest['price_target_1m'] / latest['close']) - 1) * 100
            st.metric(
                "1-Month Target", 
                f"${latest['price_target_1m']:.2f}",
                f"{pct_change:.2f}%"
            )
    
    # Display technical indicators
    st.subheader("Technical Indicators")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if 'rsi' in latest:
            st.metric("RSI", f"{latest['rsi']:.2f}")
    
    with col2:
        if 'macd' in latest:
            st.metric("MACD", f"{latest['macd']:.4f}")
    
    with col3:
        if 'macd_signal' in latest:
            st.metric("MACD Signal", f"{latest['macd_signal']:.4f}")
    
    with col4:
        if 'macd_hist' in latest:
            st.metric("MACD Histogram", f"{latest['macd_hist']:.4f}")
    
    # Display support and resistance
    col1, col2 = st.columns(2)
    
    with col1:
        if 'support' in latest:
            st.metric("Support", f"${latest['support']:.2f}")
    
    with col2:
        if 'resistance' in latest:
            st.metric("Resistance", f"${latest['resistance']:.2f}")
    
    # Display chart
    st.subheader("Price Chart")
    
    # Create a chart using Streamlit's built-in chart functions
    chart_data = data[['open', 'high', 'low', 'close']].copy()
    
    # Add moving averages if available
    if 'sma_fast' in data.columns:
        chart_data['SMA (Fast)'] = data['sma_fast']
    
    if 'sma_slow' in data.columns:
        chart_data['SMA (Slow)'] = data['sma_slow']
    
    # Display the chart
    st.line_chart(chart_data)
    
    # Display volume chart
    st.subheader("Volume")
    st.bar_chart(data['volume'])
    
    # Display pattern signals if available
    if 'pattern_signals' in latest and latest['pattern_signals']:
        st.subheader("Chart Patterns")
        patterns = latest['pattern_signals']
        
        if isinstance(patterns, list):
            for pattern in patterns:
                st.write(f"- {pattern}")
        else:
            st.write("No patterns detected")
    
    # Display additional analysis
    st.subheader("Analysis Summary")
    
    analysis_text = ""
    
    if 'signal_type' in latest:
        signal = latest['signal_type']
        confidence = latest.get('confidence_score', 0)
        
        if 'strong_bullish' in signal:
            analysis_text += f"**Strong Bullish Signal** with {confidence:.0f}% confidence. "
            analysis_text += "Multiple indicators suggest a strong upward trend. Consider buying or adding to position."
        elif 'bullish' in signal:
            analysis_text += f"**Bullish Signal** with {confidence:.0f}% confidence. "
            analysis_text += "Indicators are positive but watch for confirmation before entering."
        elif 'moderately_bullish' in signal:
            analysis_text += f"**Moderately Bullish Signal** with {confidence:.0f}% confidence. "
            analysis_text += "Some positive indicators but mixed signals present."
        elif 'strong_bearish' in signal:
            analysis_text += f"**Strong Bearish Signal** with {confidence:.0f}% confidence. "
            analysis_text += "Multiple indicators suggest a strong downward trend. Consider selling or shorting."
        elif 'bearish' in signal:
            analysis_text += f"**Bearish Signal** with {confidence:.0f}% confidence. "
            analysis_text += "Indicators are negative but watch for confirmation before selling."
        elif 'moderately_bearish' in signal:
            analysis_text += f"**Moderately Bearish Signal** with {confidence:.0f}% confidence. "
            analysis_text += "Some negative indicators but mixed signals present."
        else:
            analysis_text += f"**Neutral Signal** with {confidence:.0f}% confidence. "
            analysis_text += "No clear trend direction at this time."
    
    if 'trend_strength' in latest:
        analysis_text += f"\n\nTrend strength is {latest['trend_strength']:.0f}/100. "
        
        if latest['trend_strength'] > 80:
            analysis_text += "This is a very strong trend that is likely to continue."
        elif latest['trend_strength'] > 60:
            analysis_text += "This is a strong trend with good momentum."
        elif latest['trend_strength'] > 40:
            analysis_text += "This is a moderate trend that may continue."
        else:
            analysis_text += "This is a weak trend that may reverse."
    
    if 'volume_analysis' in latest:
        analysis_text += f"\n\nVolume analysis: {latest['volume_analysis']}. "
    
    if 'support' in latest and 'resistance' in latest:
        analysis_text += f"\n\nCurrent price (${latest['close']:.2f}) is "
        
        # Calculate where price is in the support/resistance range
        range_size = latest['resistance'] - latest['support']
        if range_size > 0:
            position = (latest['close'] - latest['support']) / range_size
            
            if position < 0.2:
                analysis_text += "near support level, which may provide a good entry point if bullish."
            elif position > 0.8:
                analysis_text += "near resistance level, which may be a good exit point or present reversal risk."
            else:
                analysis_text += f"approximately {(position * 100):.0f}% between support and resistance levels."
    
    st.write(analysis_text)

# Portfolio page
def portfolio_page():
    st.title("Portfolio")
    
    if not st.session_state.portfolio:
        st.info("Your portfolio is empty. Add stocks from the Scanner page.")
    else:
        # Display portfolio table
        portfolio_df = pd.DataFrame(st.session_state.portfolio)
        
        # Add edit functionality
        edited_df = st.data_editor(
            portfolio_df,
            column_config={
                "symbol": st.column_config.TextColumn("Symbol", disabled=True),
                "entry_price": st.column_config.NumberColumn("Entry Price ($)", min_value=0, format="%.2f"),
                "entry_date": st.column_config.DateColumn("Entry Date"),
                "quantity": st.column_config.NumberColumn("Quantity", min_value=0, step=1),
                "notes": st.column_config.TextColumn("Notes")
            },
            hide_index=True,
            num_rows="dynamic"
        )
        
        # Update portfolio with edited values
        st.session_state.portfolio = edited_df.to_dict('records')
        
        # Get current prices for portfolio stocks
        if st.button("Update Prices"):
            with st.spinner("Fetching current prices..."):
                try:
                    # Initialize data acquisition
                    data_acquisition = DataAcquisition(config)
                    
                    # Get symbols from portfolio
                    symbols = [item['symbol'] for item in st.session_state.portfolio]
                    
                    # Fetch current data
                    data = data_acquisition.get_multi_symbol_data(symbols=symbols, timeframe='1day')
                    
                    # Update portfolio with current prices
                    for i, item in enumerate(st.session_state.portfolio):
                        symbol = item['symbol']
                        if symbol in data and not data[symbol].empty:
                            current_price = data[symbol].iloc[-1]['close']
                            entry_price = item['entry_price']
                            quantity = item['quantity']
                            
                            # Calculate profit/loss
                            if entry_price > 0:
                                pct_change = ((current_price / entry_price) - 1) * 100
                                pl_value = (current_price - entry_price) * quantity
                                
                                # Update portfolio item
                                st.session_state.portfolio[i]['current_price'] = current_price
                                st.session_state.portfolio[i]['pct_change'] = pct_change
                                st.session_state.portfolio[i]['pl_value'] = pl_value
                    
                    # Display updated portfolio
                    updated_df = pd.DataFrame(st.session_state.portfolio)
                    
                    # Format for display
                    display_df = updated_df.copy()
                    if 'current_price' in display_df.columns:
                        display_df['current_price'] = display_df['current_price'].apply(lambda x: f"${x:.2f}" if pd.notnull(x) else "N/A")
                    
                    if 'pct_change' in display_df.columns:
                        display_df['pct_change'] = display_df['pct_change'].apply(lambda x: f"{x:.2f}%" if pd.notnull(x) else "N/A")
                    
                    if 'pl_value' in display_df.columns:
                        display_df['pl_value'] = display_df['pl_value'].apply(lambda x: f"${x:.2f}" if pd.notnull(x) else "N/A")
                    
                    # Display the updated table
                    st.subheader("Updated Portfolio")
                    st.dataframe(display_df, hide_index=True)
                    
                    # Calculate total portfolio value and P/L
                    if 'current_price' in updated_df.columns and 'quantity' in updated_df.columns:
                        total_value = (updated_df['current_price'] * updated_df['quantity']).sum()
                        total_cost = (updated_df['entry_price'] * updated_df['quantity']).sum()
                        total_pl = total_value - total_cost
                        total_pl_pct = (total_pl / total_cost * 100) if total_cost > 0 else 0
                        
                        # Display summary metrics
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.metric("Total Portfolio Value", f"${total_value:.2f}")
                        
                        with col2:
                            st.metric("Total P/L", f"${total_pl:.2f}", f"{total_pl_pct:.2f}%")
                        
                        with col3:
                            st.metric("Number of Positions", len(updated_df))
                except Exception as e:
                    st.error(f"Error updating prices: {str(e)}")

# Watchlist page
def watchlist_page():
    st.title("Watchlist")
    
    if not st.session_state.watchlist:
        st.info("Your watchlist is empty. Add stocks from the Scanner page.")
    else:
        # Display watchlist table
        watchlist_df = pd.DataFrame(st.session_state.watchlist)
        
        # Add edit functionality
        edited_df = st.data_editor(
            watchlist_df,
            column_config={
                "symbol": st.column_config.TextColumn("Symbol", disabled=True),
                "added_date": st.column_config.DateColumn("Added Date", disabled=True),
                "notes": st.column_config.TextColumn("Notes")
            },
            hide_index=True,
            num_rows="dynamic"
        )
        
        # Update watchlist with edited values
        st.session_state.watchlist = edited_df.to_dict('records')
        
        # Get current prices for watchlist stocks
        if st.button("Update Prices"):
            with st.spinner("Fetching current prices..."):
                try:
                    # Initialize data acquisition
                    data_acquisition = DataAcquisition(config)
                    
                    # Get symbols from watchlist
                    symbols = [item['symbol'] for item in st.session_state.watchlist]
                    
                    # Fetch current data
                    data = data_acquisition.get_multi_symbol_data(symbols=symbols, timeframe='1day')
                    
                    # Create a new dataframe with current prices
                    current_prices = []
                    
                    for symbol in symbols:
                        if symbol in data and not data[symbol].empty:
                            latest = data[symbol].iloc[-1]
                            current_prices.append({
                                'symbol': symbol,
                                'price': latest['close'],
                                'change_pct': ((latest['close'] / data[symbol].iloc[-2]['close']) - 1) * 100 if len(data[symbol]) > 1 else 0,
                                'volume': latest['volume']
                            })
                    
                    if current_prices:
                        prices_df = pd.DataFrame(current_prices)
                        
                        # Format for display
                        prices_df['price'] = prices_df['price'].apply(lambda x: f"${x:.2f}")
                        prices_df['change_pct'] = prices_df['change_pct'].apply(lambda x: f"{x:.2f}%")
                        prices_df['volume'] = prices_df['volume'].apply(lambda x: f"{x:,.0f}")
                        
                        # Display the prices table
                        st.subheader("Current Prices")
                        st.dataframe(prices_df, hide_index=True)
                    else:
                        st.warning("Could not fetch current prices for any symbols.")
                except Exception as e:
                    st.error(f"Error updating prices: {str(e)}")
        
        # Scan watchlist button
        if st.button("Scan Watchlist"):
            with st.spinner("Scanning watchlist..."):
                try:
                    # Get symbols from watchlist
                    symbols = [item['symbol'] for item in st.session_state.watchlist]
                    
                    # Set date range (last 30 days)
                    end_date = datetime.now()
                    start_date = end_date - timedelta(days=30)
                    
                    # Initialize modules
                    data_acquisition = DataAcquisition(config)
                    technical_analysis = EnhancedTechnicalAnalysis(config)
                    machine_learning = EnhancedMachineLearningEngine(config)
                    
                    # Initialize scanner
                    scanner = EnhancedStockScanner(config, data_acquisition, technical_analysis, machine_learning)
                    
                    # Run scan
                    results = scanner.scan(
                        symbols=symbols,
                        timeframes=['1day'],
                        start_date=start_date.strftime("%Y-%m-%d"),
                        end_date=end_date.strftime("%Y-%m-%d")
                    )
                    
                    # Store results in session state
                    st.session_state.scanner_results = results
                    
                    # Redirect to scanner page
                    st.success("Watchlist scan complete! View results in the Scanner page.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error scanning watchlist: {str(e)}")

# Alerts page
def alerts_page():
    st.title("Alerts")
    
    # Create a new alert
    with st.expander("Create New Alert"):
        with st.form("alert_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                symbol = st.text_input("Symbol")
                alert_type = st.selectbox(
                    "Alert Type",
                    options=["Price Above", "Price Below", "RSI Above", "RSI Below", "MACD Crossover", "MACD Crossunder"]
                )
            
            with col2:
                value = st.number_input("Value", min_value=0.0, step=0.01)
                expiration = st.date_input("Expiration Date", value=datetime.now() + timedelta(days=30))
            
            submit = st.form_submit_button("Create Alert")
            
            if submit:
                if not symbol:
                    st.error("Symbol is required.")
                else:
                    st.session_state.alerts.append({
                        'symbol': symbol.upper(),
                        'alert_type': alert_type,
                        'value': value,
                        'expiration': expiration.strftime("%Y-%m-%d"),
                        'created': datetime.now().strftime("%Y-%m-%d"),
                        'triggered': False
                    })
                    st.success(f"Alert created for {symbol.upper()}!")
    
    # Display alerts
    if not st.session_state.alerts:
        st.info("You have no alerts set up.")
    else:
        # Display alerts table
        alerts_df = pd.DataFrame(st.session_state.alerts)
        
        # Add edit functionality
        edited_df = st.data_editor(
            alerts_df,
            column_config={
                "symbol": st.column_config.TextColumn("Symbol", disabled=True),
                "alert_type": st.column_config.SelectboxColumn(
                    "Alert Type",
                    options=["Price Above", "Price Below", "RSI Above", "RSI Below", "MACD Crossover", "MACD Crossunder"]
                ),
                "value": st.column_config.NumberColumn("Value", min_value=0, format="%.2f"),
                "expiration": st.column_config.DateColumn("Expiration Date"),
                "created": st.column_config.DateColumn("Created Date", disabled=True),
                "triggered": st.column_config.CheckboxColumn("Triggered")
            },
            hide_index=True,
            num_rows="dynamic"
        )
        
        # Update alerts with edited values
        st.session_state.alerts = edited_df.to_dict('records')
        
        # Check alerts button
        if st.button("Check Alerts"):
            with st.spinner("Checking alerts..."):
                try:
                    # Initialize data acquisition
                    data_acquisition = DataAcquisition(config)
                    
                    # Get symbols from alerts
                    symbols = list(set([alert['symbol'] for alert in st.session_state.alerts if not alert['triggered']]))
                    
                    if symbols:
                        # Fetch current data
                        data = data_acquisition.get_multi_symbol_data(symbols=symbols, timeframe='1day')
                        
                        # Initialize technical analysis
                        technical_analysis = EnhancedTechnicalAnalysis(config)
                        
                        # Check each alert
                        triggered_alerts = []
                        
                        for i, alert in enumerate(st.session_state.alerts):
                            if alert['triggered']:
                                continue
                                
                            symbol = alert['symbol']
                            
                            if symbol in data and not data[symbol].empty:
                                df = data[symbol]
                                
                                # Calculate indicators if needed
                                if alert['alert_type'] in ['RSI Above', 'RSI Below', 'MACD Crossover', 'MACD Crossunder']:
                                    df = technical_analysis.calculate_indicators(df)
                                
                                latest = df.iloc[-1]
                                
                                # Check alert conditions
                                triggered = False
                                
                                if alert['alert_type'] == 'Price Above' and latest['close'] > alert['value']:
                                    triggered = True
                                elif alert['alert_type'] == 'Price Below' and latest['close'] < alert['value']:
                                    triggered = True
                                elif alert['alert_type'] == 'RSI Above' and 'rsi' in latest and latest['rsi'] > alert['value']:
                                    triggered = True
                                elif alert['alert_type'] == 'RSI Below' and 'rsi' in latest and latest['rsi'] < alert['value']:
                                    triggered = True
                                elif alert['alert_type'] == 'MACD Crossover' and 'macd' in latest and 'macd_signal' in latest:
                                    # Check if MACD crossed above signal line
                                    if len(df) > 1:
                                        prev = df.iloc[-2]
                                        if 'macd' in prev and 'macd_signal' in prev:
                                            if prev['macd'] < prev['macd_signal'] and latest['macd'] > latest['macd_signal']:
                                                triggered = True
                                elif alert['alert_type'] == 'MACD Crossunder' and 'macd' in latest and 'macd_signal' in latest:
                                    # Check if MACD crossed below signal line
                                    if len(df) > 1:
                                        prev = df.iloc[-2]
                                        if 'macd' in prev and 'macd_signal' in prev:
                                            if prev['macd'] > prev['macd_signal'] and latest['macd'] < latest['macd_signal']:
                                                triggered = True
                                
                                # Update alert if triggered
                                if triggered:
                                    st.session_state.alerts[i]['triggered'] = True
                                    triggered_alerts.append({
                                        'symbol': symbol,
                                        'alert_type': alert['alert_type'],
                                        'value': alert['value'],
                                        'current_value': latest['close'] if alert['alert_type'] in ['Price Above', 'Price Below'] else 
                                                        latest['rsi'] if alert['alert_type'] in ['RSI Above', 'RSI Below'] else
                                                        latest['macd'] - latest['macd_signal']
                                    })
                        
                        # Display triggered alerts
                        if triggered_alerts:
                            st.subheader("Triggered Alerts")
                            triggered_df = pd.DataFrame(triggered_alerts)
                            st.dataframe(triggered_df, hide_index=True)
                        else:
                            st.info("No alerts were triggered.")
                    else:
                        st.info("No active alerts to check.")
                except Exception as e:
                    st.error(f"Error checking alerts: {str(e)}")

# Settings page
def settings_page():
    st.title("Settings")
    
    # App settings
    st.header("Application Settings")
    
    # Theme selection
    theme = st.selectbox(
        "Theme",
        options=["Light", "Dark"],
        index=1
    )
    
    # Default timeframe
    default_timeframe = st.selectbox(
        "Default Timeframe",
        options=["1min", "5min", "15min", "30min", "1hour", "1day", "1week"],
        index=2  # Default to 15min
    )
    
    # Default symbols
    default_symbols = st.text_area(
        "Default Symbols",
        value=", ".join(config['data']['default_symbols']),
        help="Enter default symbols separated by commas"
    )
    
    # Save settings button
    if st.button("Save Settings"):
        # Update config
        config['data']['timeframes']['primary'] = default_timeframe
        config['data']['default_symbols'] = [s.strip().upper() for s in default_symbols.split(',')]
        
        # Save config to file
        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config', 'user_config.json')
        
        try:
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=4)
            
            st.success("Settings saved successfully!")
        except Exception as e:
            st.error(f"Error saving settings: {str(e)}")
    
    # Data sources
    st.header("Data Sources")
    
    # Primary data source
    primary_source = st.selectbox(
        "Primary Data Source",
        options=["yfinance", "alpaca", "alpha_vantage"],
        index=0 if config['data']['primary_source'] == 'yfinance' else 
              1 if config['data']['primary_source'] == 'alpaca' else 2
    )
    
    # Backup data source
    backup_source = st.selectbox(
        "Backup Data Source",
        options=["None", "yfinance", "alpaca", "alpha_vantage"],
        index=0 if not config['data']['backup_source'] else
              1 if config['data']['backup_source'] == 'yfinance' else
              2 if config['data']['backup_source'] == 'alpaca' else 3
    )
    
    # API keys
    st.subheader("API Keys")
    
    # Alpaca API keys
    with st.expander("Alpaca API Keys"):
        alpaca_key = st.text_input(
            "Alpaca API Key",
            value=config['data']['api_keys']['alpaca']['api_key'],
            type="password"
        )
        
        alpaca_secret = st.text_input(
            "Alpaca API Secret",
            value=config['data']['api_keys']['alpaca']['api_secret'],
            type="password"
        )
    
    # Alpha Vantage API key
    with st.expander("Alpha Vantage API Key"):
        alpha_vantage_key = st.text_input(
            "Alpha Vantage API Key",
            value=config['data']['api_keys']['alpha_vantage']['api_key'],
            type="password"
        )
    
    # Save API keys button
    if st.button("Save API Keys"):
        # Update config
        config['data']['primary_source'] = primary_source
        config['data']['backup_source'] = None if backup_source == "None" else backup_source
        config['data']['api_keys']['alpaca']['api_key'] = alpaca_key
        config['data']['api_keys']['alpaca']['api_secret'] = alpaca_secret
        config['data']['api_keys']['alpha_vantage']['api_key'] = alpha_vantage_key
        
        # Save config to file
        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config', 'user_config.json')
        
        try:
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=4)
            
            st.success("API keys saved successfully!")
        except Exception as e:
            st.error(f"Error saving API keys: {str(e)}")
    
    # Clear cache button
    if st.button("Clear Cache"):
        cache_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cache')
        
        try:
            # Delete all files in cache directory
            for file in os.listdir(cache_dir):
                file_path = os.path.join(cache_dir, file)
                if os.path.isfile(file_path):
                    os.remove(file_path)
            
            st.success("Cache cleared successfully!")
        except Exception as e:
            st.error(f"Error clearing cache: {str(e)}")
    
    # About section
    st.header("About")
    st.write("Advanced Stock Scanner v2.0")
    st.write("© 2024 Stock Scanner Team")

# Main function
def main():
    if not st.session_state.logged_in:
        login_page()
    else:
        main_app()

if __name__ == "__main__":
    main()
