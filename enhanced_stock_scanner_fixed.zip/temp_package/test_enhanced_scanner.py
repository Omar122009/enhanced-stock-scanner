"""
test_enhanced_scanner.py - Test script for the enhanced stock scanner
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import json

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('test_scanner')

# Import modules directly from current directory
from data_acquisition_enhanced import EnhancedDataAcquisition
from utils.technical_analysis_enhanced import EnhancedTechnicalAnalysis
from utils.machine_learning_enhanced import EnhancedMachineLearningEngine
from utils.performance_optimizer import PerformanceOptimizer
from scanner_enhanced import EnhancedStockScanner
from config.enhanced_config import get_config
from utils.integration_manager import IntegrationManager

def test_data_acquisition():
    """Test the enhanced data acquisition module"""
    logger.info("Testing enhanced data acquisition...")
    
    # Get configuration
    config = get_config()
    
    # Initialize data acquisition
    data_acquisition = EnhancedDataAcquisition(config)
    
    # Test data source health
    health = data_acquisition.get_source_health()
    logger.info(f"Data source health: {json.dumps(health, indent=2)}")
    
    # Test getting historical data
    symbols = ["AAPL", "MSFT", "GOOGL"]
    timeframe = "1day"
    period = "1month"
    
    try:
        logger.info(f"Getting historical data for {symbols} with timeframe {timeframe} and period {period}...")
        data = data_acquisition.get_historical_data(symbols, timeframe, period)
        
        if data:
            logger.info(f"Successfully retrieved data for {len(data)} symbols")
            for symbol, df in data.items():
                logger.info(f"{symbol}: {len(df)} rows, columns: {df.columns.tolist()}")
                
                # Check if data has expected columns
                expected_columns = ['open', 'high', 'low', 'close', 'volume']
                for col in expected_columns:
                    if col not in df.columns:
                        logger.error(f"Missing expected column {col} in data for {symbol}")
            
            return True
        else:
            logger.error("No data retrieved")
            return False
    except Exception as e:
        logger.error(f"Error testing data acquisition: {e}")
        return False

def test_technical_analysis():
    """Test the technical analysis module"""
    logger.info("Testing technical analysis...")
    
    # Get configuration
    config = get_config()
    
    # Initialize data acquisition and technical analysis
    data_acquisition = EnhancedDataAcquisition(config)
    technical_analysis = EnhancedTechnicalAnalysis(config)
    
    # Get data for a single symbol
    symbol = "AAPL"
    timeframe = "1day"
    period = "1month"
    
    try:
        logger.info(f"Getting data for {symbol}...")
        data = data_acquisition.get_historical_data([symbol], timeframe, period)
        
        if symbol in data and not data[symbol].empty:
            logger.info(f"Successfully retrieved data for {symbol}: {len(data[symbol])} rows")
            
            # Calculate indicators
            logger.info("Calculating technical indicators...")
            data_with_indicators = technical_analysis.calculate_indicators(data[symbol])
            
            # Check if indicators were calculated
            indicator_columns = ['sma_14', 'sma_40', 'rsi', 'macd', 'macd_signal', 'macd_hist']
            for col in indicator_columns:
                if col not in data_with_indicators.columns:
                    logger.error(f"Missing indicator column {col}")
                else:
                    logger.info(f"Successfully calculated {col}")
            
            return True
        else:
            logger.error(f"No data retrieved for {symbol}")
            return False
    except Exception as e:
        logger.error(f"Error testing technical analysis: {e}")
        return False

def test_machine_learning():
    """Test the machine learning module"""
    logger.info("Testing machine learning...")
    
    # Get configuration
    config = get_config()
    
    # Initialize components
    data_acquisition = EnhancedDataAcquisition(config)
    technical_analysis = EnhancedTechnicalAnalysis(config)
    machine_learning = EnhancedMachineLearningEngine(config)
    
    # Get data for a single symbol
    symbol = "AAPL"
    timeframe = "1day"
    period = "1month"
    
    try:
        logger.info(f"Getting data for {symbol}...")
        data = data_acquisition.get_historical_data([symbol], timeframe, period)
        
        if symbol in data and not data[symbol].empty:
            logger.info(f"Successfully retrieved data for {symbol}: {len(data[symbol])} rows")
            
            # Calculate indicators
            logger.info("Calculating technical indicators...")
            data_with_indicators = technical_analysis.calculate_indicators(data[symbol])
            
            # Run machine learning predictions
            logger.info("Running machine learning predictions...")
            data_with_predictions = machine_learning.predict(data_with_indicators)
            
            # Check if predictions were made
            prediction_columns = ['ml_signal', 'ml_confidence']
            for col in prediction_columns:
                if col not in data_with_predictions.columns:
                    logger.warning(f"Missing prediction column {col}")
                else:
                    logger.info(f"Successfully calculated {col}")
            
            return True
        else:
            logger.error(f"No data retrieved for {symbol}")
            return False
    except Exception as e:
        logger.error(f"Error testing machine learning: {e}")
        return False

def test_scanner():
    """Test the enhanced scanner"""
    logger.info("Testing enhanced scanner...")
    
    # Get configuration
    config = get_config()
    
    # Initialize components
    data_acquisition = EnhancedDataAcquisition(config)
    technical_analysis = EnhancedTechnicalAnalysis(config)
    machine_learning = EnhancedMachineLearningEngine(config)
    scanner = EnhancedStockScanner(config, data_acquisition, technical_analysis, machine_learning)
    
    # Test scanning a small list of symbols
    symbols = ["AAPL", "MSFT", "GOOGL"]
    timeframe = "1day"
    
    # Get date range
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    
    try:
        logger.info(f"Scanning {symbols} with timeframe {timeframe}...")
        results = scanner.scan(symbols, [timeframe], start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
        
        if results is not None and not results.empty:
            logger.info(f"Successfully scanned {len(results)} symbols")
            logger.info(f"Results columns: {results.columns.tolist()}")
            
            # Check if results have expected columns
            expected_columns = ['symbol', 'timeframe', 'close', 'signal_type', 'confidence_score']
            for col in expected_columns:
                if col not in results.columns:
                    logger.warning(f"Missing expected column {col} in results")
            
            return True
        else:
            logger.error("No results from scanner")
            return False
    except Exception as e:
        logger.error(f"Error testing scanner: {e}")
        return False

def test_integration_manager():
    """Test the integration manager"""
    logger.info("Testing integration manager...")
    
    # Get configuration
    config = get_config()
    
    # Initialize components
    data_acquisition = EnhancedDataAcquisition(config)
    technical_analysis = EnhancedTechnicalAnalysis(config)
    machine_learning = EnhancedMachineLearningEngine(config)
    scanner = EnhancedStockScanner(config, data_acquisition, technical_analysis, machine_learning)
    integration_manager = IntegrationManager(config, data_acquisition, technical_analysis, machine_learning, scanner)
    
    # Test getting component status
    try:
        logger.info("Getting component status...")
        status = integration_manager.get_component_status()
        logger.info(f"Component status: {json.dumps(status, indent=2)}")
        
        # Test getting data with fallback
        symbols = ["AAPL", "MSFT", "GOOGL"]
        timeframe = "1day"
        period = "1month"
        
        logger.info(f"Getting data with fallback for {symbols}...")
        data = integration_manager.get_data_with_fallback(symbols, timeframe, period)
        
        if data:
            logger.info(f"Successfully retrieved data for {len(data)} symbols")
            
            # Test calculating indicators safely
            if "AAPL" in data and not data["AAPL"].empty:
                logger.info("Calculating indicators safely...")
                data_with_indicators = integration_manager.calculate_indicators_safely(data["AAPL"])
                
                # Check if indicators were calculated
                indicator_columns = ['sma_14', 'sma_40', 'rsi', 'macd']
                for col in indicator_columns:
                    if col not in data_with_indicators.columns:
                        logger.warning(f"Missing indicator column {col}")
                    else:
                        logger.info(f"Successfully calculated {col}")
                
                # Test predicting safely
                logger.info("Predicting safely...")
                data_with_predictions = integration_manager.predict_safely(data_with_indicators)
                
                # Log integration event
                logger.info("Logging integration event...")
                integration_manager.log_integration_event("test", {"status": "success"})
                
                return True
            else:
                logger.error("No data retrieved for AAPL")
                return False
        else:
            logger.error("No data retrieved")
            return False
    except Exception as e:
        logger.error(f"Error testing integration manager: {e}")
        return False

def run_all_tests():
    """Run all tests"""
    logger.info("Running all tests...")
    
    # Create results dictionary
    results = {}
    
    # Test data acquisition
    logger.info("=== Testing Data Acquisition ===")
    results['data_acquisition'] = test_data_acquisition()
    
    # Test technical analysis
    logger.info("\n=== Testing Technical Analysis ===")
    results['technical_analysis'] = test_technical_analysis()
    
    # Test machine learning
    logger.info("\n=== Testing Machine Learning ===")
    results['machine_learning'] = test_machine_learning()
    
    # Test scanner
    logger.info("\n=== Testing Scanner ===")
    results['scanner'] = test_scanner()
    
    # Test integration manager
    logger.info("\n=== Testing Integration Manager ===")
    results['integration_manager'] = test_integration_manager()
    
    # Print summary
    logger.info("\n=== Test Summary ===")
    for test, result in results.items():
        status = "PASSED" if result else "FAILED"
        logger.info(f"{test}: {status}")
    
    # Overall result
    overall = all(results.values())
    logger.info(f"Overall: {'PASSED' if overall else 'FAILED'}")
    
    return overall

if __name__ == "__main__":
    run_all_tests()
