"""
Config package initialization
"""
