"""
enhanced_config.py - Enhanced configuration module for the Advanced Stock Scanner
"""

import os
import json
import sys

# Add the parent directory to the path so we can import the stock_list_500 module
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from stock_list_500 import get_stock_list

def get_config():
    """
    Get configuration dictionary
    
    Returns:
        dict: Configuration dictionary
    """
    # Default configuration
    default_config = {
        'data': {
            'primary_source': 'yfinance',
            'backup_source': None,
            'api_keys': {
                'alpaca': {
                    'api_key': '',
                    'api_secret': ''
                },
                'alpha_vantage': {
                    'api_key': ''
                }
            },
            'default_symbols': get_stock_list(),
            'timeframes': {
                'primary': '15min',
                'secondary': ['1min', '5min', '30min', '1hour', '1day', '1week']
            },
            'history_period': '3month'
        },
        'technical_analysis': {
            'sma_periods': [14, 40],
            'rsi_period': 14,
            'rsi_overbought': 70,
            'rsi_oversold': 30,
            'macd_periods': [12, 26, 9],
            'bollinger_periods': 20,
            'bollinger_std': 2.0
        },
        'machine_learning': {
            'prediction_horizon': [1, 5, 20],
            'confidence_threshold': 60,
            'feature_columns': [
                'sma_14', 'sma_40', 'ema_9', 'ema_21', 'rsi', 'macd', 'macd_signal', 'macd_hist',
                'bollinger_upper', 'bollinger_middle', 'bollinger_lower', 'atr',
                'stoch_k', 'stoch_d', 'adx', 'trend_strength'
            ]
        },
        'scanner': {
            'confidence_threshold': 50,
            'max_workers': 4,
            'use_ml': True
        },
        'performance': {
            'use_multithreading': True,
            'use_multiprocessing': False,
            'max_workers': 4,
            'chunk_size': 10,
            'use_caching': True
        }
    }
    
    # Try to load user config
    try:
        config_dir = os.path.dirname(os.path.abspath(__file__))
        user_config_path = os.path.join(config_dir, 'user_config.json')
        
        if os.path.exists(user_config_path):
            with open(user_config_path, 'r') as f:
                user_config = json.load(f)
            
            # Merge user config with default config
            _merge_configs(default_config, user_config)
    except Exception as e:
        print(f"Error loading user config: {e}")
    
    return default_config

def _merge_configs(default_config, user_config):
    """
    Merge user config into default config
    
    Args:
        default_config (dict): Default configuration dictionary
        user_config (dict): User configuration dictionary
    """
    for key, value in user_config.items():
        if key in default_config and isinstance(default_config[key], dict) and isinstance(value, dict):
            _merge_configs(default_config[key], value)
        else:
            default_config[key] = value
