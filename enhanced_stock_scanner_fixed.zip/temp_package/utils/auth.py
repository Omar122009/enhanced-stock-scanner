"""
auth.py - Authentication module for the Advanced Stock Scanner
"""

import os
import json
import hashlib
import secrets
import logging
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('auth')

class AuthManager:
    """
    Authentication Manager for user login and registration
    """
    
    def __init__(self, config):
        """
        Initialize the authentication manager
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        self.auth_config = config.get('auth', {})
        
        # Setup users directory
        self.users_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'users')
        os.makedirs(self.users_dir, exist_ok=True)
        
        # User database file
        self.users_file = os.path.join(self.users_dir, 'users.json')
        
        # Session tokens
        self.sessions = {}
        
        # Load users
        self.users = self._load_users()
        
        # Create admin user if it doesn't exist
        self._create_default_admin()
        
        logger.info("Authentication Manager initialized")
    
    def _load_users(self):
        """Load users from the database file"""
        if os.path.exists(self.users_file):
            try:
                with open(self.users_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading users: {e}")
                return {}
        else:
            return {}
    
    def _save_users(self):
        """Save users to the database file"""
        try:
            with open(self.users_file, 'w') as f:
                json.dump(self.users, f, indent=4)
            logger.info("Users saved to database")
            return True
        except Exception as e:
            logger.error(f"Error saving users: {e}")
            return False
    
    def _create_default_admin(self):
        """Create default admin user if it doesn't exist"""
        if 'admin' not in self.users:
            self.register_user('admin', 'admin123', 'admin')
            logger.info("Created default admin user")
    
    def _hash_password(self, password, salt=None):
        """
        Hash password with salt
        
        Args:
            password (str): Password to hash
            salt (str, optional): Salt to use. If None, a new salt is generated.
            
        Returns:
            tuple: (hashed_password, salt)
        """
        if salt is None:
            salt = secrets.token_hex(16)
        
        # Hash password with salt
        hashed = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        ).hex()
        
        return hashed, salt
    
    def register_user(self, username, password, role='user'):
        """
        Register a new user
        
        Args:
            username (str): Username
            password (str): Password
            role (str, optional): User role. Defaults to 'user'.
            
        Returns:
            bool: Success status
        """
        if username in self.users:
            logger.warning(f"User {username} already exists")
            return False
        
        # Hash password
        hashed_password, salt = self._hash_password(password)
        
        # Create user
        self.users[username] = {
            'username': username,
            'password': hashed_password,
            'salt': salt,
            'role': role,
            'created_at': datetime.now().isoformat(),
            'last_login': None
        }
        
        # Save users
        return self._save_users()
    
    def login(self, username, password):
        """
        Login user
        
        Args:
            username (str): Username
            password (str): Password
            
        Returns:
            tuple: (success, token, role)
        """
        if username not in self.users:
            logger.warning(f"User {username} not found")
            return False, None, None
        
        # Get user
        user = self.users[username]
        
        # Hash password with user's salt
        hashed_password, _ = self._hash_password(password, user['salt'])
        
        # Check password
        if hashed_password != user['password']:
            logger.warning(f"Invalid password for user {username}")
            return False, None, None
        
        # Generate token
        token = secrets.token_hex(32)
        
        # Store session
        self.sessions[token] = {
            'username': username,
            'role': user['role'],
            'expires': (datetime.now() + timedelta(hours=24)).isoformat()
        }
        
        # Update last login
        user['last_login'] = datetime.now().isoformat()
        self._save_users()
        
        logger.info(f"User {username} logged in")
        return True, token, user['role']
    
    def logout(self, token):
        """
        Logout user
        
        Args:
            token (str): Session token
            
        Returns:
            bool: Success status
        """
        if token in self.sessions:
            del self.sessions[token]
            logger.info("User logged out")
            return True
        else:
            logger.warning("Invalid token for logout")
            return False
    
    def validate_token(self, token):
        """
        Validate session token
        
        Args:
            token (str): Session token
            
        Returns:
            tuple: (is_valid, username, role)
        """
        if token not in self.sessions:
            return False, None, None
        
        # Get session
        session = self.sessions[token]
        
        # Check if session is expired
        expires = datetime.fromisoformat(session['expires'])
        if expires < datetime.now():
            del self.sessions[token]
            return False, None, None
        
        return True, session['username'], session['role']
    
    def change_password(self, username, old_password, new_password):
        """
        Change user password
        
        Args:
            username (str): Username
            old_password (str): Old password
            new_password (str): New password
            
        Returns:
            bool: Success status
        """
        if username not in self.users:
            logger.warning(f"User {username} not found")
            return False
        
        # Get user
        user = self.users[username]
        
        # Hash old password with user's salt
        hashed_old_password, _ = self._hash_password(old_password, user['salt'])
        
        # Check old password
        if hashed_old_password != user['password']:
            logger.warning(f"Invalid old password for user {username}")
            return False
        
        # Hash new password
        hashed_new_password, salt = self._hash_password(new_password)
        
        # Update password
        user['password'] = hashed_new_password
        user['salt'] = salt
        
        # Save users
        return self._save_users()
    
    def delete_user(self, username, admin_username=None):
        """
        Delete user
        
        Args:
            username (str): Username to delete
            admin_username (str, optional): Admin username. If provided, checks if admin.
            
        Returns:
            bool: Success status
        """
        if username not in self.users:
            logger.warning(f"User {username} not found")
            return False
        
        # Check if admin is required
        if admin_username is not None:
            if admin_username not in self.users:
                logger.warning(f"Admin {admin_username} not found")
                return False
            
            # Check if admin
            if self.users[admin_username]['role'] != 'admin':
                logger.warning(f"User {admin_username} is not an admin")
                return False
        
        # Delete user
        del self.users[username]
        
        # Delete user's sessions
        for token, session in list(self.sessions.items()):
            if session['username'] == username:
                del self.sessions[token]
        
        # Save users
        return self._save_users()
    
    def get_user_info(self, username):
        """
        Get user information
        
        Args:
            username (str): Username
            
        Returns:
            dict: User information
        """
        if username not in self.users:
            logger.warning(f"User {username} not found")
            return None
        
        # Get user
        user = self.users[username]
        
        # Return user info without sensitive data
        return {
            'username': user['username'],
            'role': user['role'],
            'created_at': user['created_at'],
            'last_login': user['last_login']
        }
    
    def get_all_users(self, admin_username=None):
        """
        Get all users
        
        Args:
            admin_username (str, optional): Admin username. If provided, checks if admin.
            
        Returns:
            list: List of user information
        """
        # Check if admin is required
        if admin_username is not None:
            if admin_username not in self.users:
                logger.warning(f"Admin {admin_username} not found")
                return []
            
            # Check if admin
            if self.users[admin_username]['role'] != 'admin':
                logger.warning(f"User {admin_username} is not an admin")
                return []
        
        # Return all users without sensitive data
        return [
            {
                'username': user['username'],
                'role': user['role'],
                'created_at': user['created_at'],
                'last_login': user['last_login']
            }
            for user in self.users.values()
        ]
    
    def is_admin(self, username):
        """
        Check if user is admin
        
        Args:
            username (str): Username
            
        Returns:
            bool: True if admin, False otherwise
        """
        if username not in self.users:
            return False
        
        return self.users[username]['role'] == 'admin'
    
    def promote_to_admin(self, username, admin_username):
        """
        Promote user to admin
        
        Args:
            username (str): Username to promote
            admin_username (str): Admin username
            
        Returns:
            bool: Success status
        """
        if username not in self.users:
            logger.warning(f"User {username} not found")
            return False
        
        if admin_username not in self.users:
            logger.warning(f"Admin {admin_username} not found")
            return False
        
        # Check if admin
        if self.users[admin_username]['role'] != 'admin':
            logger.warning(f"User {admin_username} is not an admin")
            return False
        
        # Promote user
        self.users[username]['role'] = 'admin'
        
        # Save users
        return self._save_users()
    
    def demote_from_admin(self, username, admin_username):
        """
        Demote admin to user
        
        Args:
            username (str): Username to demote
            admin_username (str): Admin username
            
        Returns:
            bool: Success status
        """
        if username not in self.users:
            logger.warning(f"User {username} not found")
            return False
        
        if admin_username not in self.users:
            logger.warning(f"Admin {admin_username} not found")
            return False
        
        # Check if admin
        if self.users[admin_username]['role'] != 'admin':
            logger.warning(f"User {admin_username} is not an admin")
            return False
        
        # Prevent demoting self
        if username == admin_username:
            logger.warning(f"Admin {admin_username} cannot demote self")
            return False
        
        # Demote user
        self.users[username]['role'] = 'user'
        
        # Save users
        return self._save_users()
