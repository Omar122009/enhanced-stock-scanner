"""
accuracy_optimizer.py - Module for optimizing the accuracy of the stock scanner
"""

import pandas as pd
import numpy as np
import logging
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import joblib
import os
from datetime import datetime, timedelta

# Configure logging
logger = logging.getLogger(__name__)

class AccuracyOptimizer:
    """
    Class for optimizing the accuracy of the stock scanner
    """
    
    def __init__(self, config):
        """
        Initialize the AccuracyOptimizer
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        self.models_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'models')
        os.makedirs(self.models_dir, exist_ok=True)
        
        # Advanced parameters for accuracy optimization
        self.validation_window = 20  # Days to use for validation
        self.min_confidence_threshold = 65  # Minimum confidence threshold for signals
        self.min_risk_reward_ratio = 1.5  # Minimum risk-reward ratio for trade setups
        self.max_false_signal_rate = 0.3  # Maximum acceptable false signal rate
        self.consensus_threshold = 0.7  # Threshold for indicator consensus
        
        logger.info("AccuracyOptimizer initialized")
    
    def optimize_technical_indicators(self, data):
        """
        Optimize technical indicator parameters for maximum accuracy
        
        Args:
            data (pandas.DataFrame): Historical price data
            
        Returns:
            dict: Optimized technical indicator parameters
        """
        logger.info("Optimizing technical indicator parameters")
        
        # Default parameters
        default_params = self.config['technical_analysis']
        
        # Parameter ranges to test
        param_ranges = {
            'sma_periods': [[5, 20], [10, 30], [14, 40], [20, 50], [30, 100]],
            'rsi_period': [7, 9, 14, 21],
            'rsi_overbought': [65, 70, 75, 80],
            'rsi_oversold': [20, 25, 30, 35],
            'macd_periods': [[8, 17, 9], [12, 26, 9], [16, 32, 9]],
            'bollinger_periods': [10, 15, 20, 25],
            'bollinger_std': [1.5, 2.0, 2.5, 3.0]
        }
        
        # Prepare validation data
        validation_data = self._prepare_validation_data(data)
        if validation_data is None or validation_data.empty:
            logger.warning("Insufficient data for validation, using default parameters")
            return default_params
        
        # Test each parameter combination
        best_score = 0
        best_params = default_params.copy()
        
        # Test SMA periods
        for sma_periods in param_ranges['sma_periods']:
            score = self._evaluate_parameter(validation_data, 'sma_periods', sma_periods)
            if score > best_score:
                best_score = score
                best_params['sma_periods'] = sma_periods
        
        # Test RSI period
        for rsi_period in param_ranges['rsi_period']:
            score = self._evaluate_parameter(validation_data, 'rsi_period', rsi_period)
            if score > best_score:
                best_score = score
                best_params['rsi_period'] = rsi_period
        
        # Test RSI overbought level
        for rsi_overbought in param_ranges['rsi_overbought']:
            score = self._evaluate_parameter(validation_data, 'rsi_overbought', rsi_overbought)
            if score > best_score:
                best_score = score
                best_params['rsi_overbought'] = rsi_overbought
        
        # Test RSI oversold level
        for rsi_oversold in param_ranges['rsi_oversold']:
            score = self._evaluate_parameter(validation_data, 'rsi_oversold', rsi_oversold)
            if score > best_score:
                best_score = score
                best_params['rsi_oversold'] = rsi_oversold
        
        # Test MACD periods
        for macd_periods in param_ranges['macd_periods']:
            score = self._evaluate_parameter(validation_data, 'macd_periods', macd_periods)
            if score > best_score:
                best_score = score
                best_params['macd_periods'] = macd_periods
        
        # Test Bollinger Bands period
        for bollinger_periods in param_ranges['bollinger_periods']:
            score = self._evaluate_parameter(validation_data, 'bollinger_periods', bollinger_periods)
            if score > best_score:
                best_score = score
                best_params['bollinger_periods'] = bollinger_periods
        
        # Test Bollinger Bands standard deviation
        for bollinger_std in param_ranges['bollinger_std']:
            score = self._evaluate_parameter(validation_data, 'bollinger_std', bollinger_std)
            if score > best_score:
                best_score = score
                best_params['bollinger_std'] = bollinger_std
        
        logger.info(f"Optimized technical indicator parameters: {best_params}")
        return best_params
    
    def _prepare_validation_data(self, data):
        """
        Prepare validation data for parameter optimization
        
        Args:
            data (pandas.DataFrame): Historical price data
            
        Returns:
            pandas.DataFrame: Validation data
        """
        if data is None or data.empty:
            return None
        
        # Use the last validation_window days for validation
        if len(data) > self.validation_window:
            validation_data = data.tail(self.validation_window).copy()
        else:
            validation_data = data.copy()
        
        return validation_data
    
    def _evaluate_parameter(self, data, param_name, param_value):
        """
        Evaluate a parameter value using validation data
        
        Args:
            data (pandas.DataFrame): Validation data
            param_name (str): Parameter name
            param_value: Parameter value
            
        Returns:
            float: Evaluation score
        """
        # This is a simplified evaluation function
        # In a real implementation, this would calculate indicators with the given parameters
        # and evaluate how well they predict future price movements
        
        # For now, return a random score between 0 and 1
        return np.random.random()
    
    def train_enhanced_ml_model(self, data, symbol=None):
        """
        Train an enhanced machine learning model for improved prediction accuracy
        
        Args:
            data (pandas.DataFrame): Historical price data
            symbol (str, optional): Symbol for the data
            
        Returns:
            object: Trained model
        """
        logger.info(f"Training enhanced ML model for {symbol if symbol else 'general data'}")
        
        if data is None or data.empty or len(data) < 100:
            logger.warning("Insufficient data for ML model training")
            return None
        
        try:
            # Prepare features and target
            X, y = self._prepare_ml_features(data)
            if X is None or y is None:
                return None
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Train models
            models = {
                'random_forest': self._train_random_forest(X_train, y_train),
                'gradient_boosting': self._train_gradient_boosting(X_train, y_train)
            }
            
            # Evaluate models
            best_model_name = None
            best_score = 0
            
            for name, model in models.items():
                if model is None:
                    continue
                
                y_pred = model.predict(X_test)
                accuracy = accuracy_score(y_test, y_pred)
                precision = precision_score(y_test, y_pred, average='weighted')
                recall = recall_score(y_test, y_pred, average='weighted')
                f1 = f1_score(y_test, y_pred, average='weighted')
                
                logger.info(f"Model {name} - Accuracy: {accuracy:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1:.4f}")
                
                # Use F1 score as the primary metric
                if f1 > best_score:
                    best_score = f1
                    best_model_name = name
            
            if best_model_name:
                best_model = models[best_model_name]
                
                # Save model
                if symbol:
                    model_path = os.path.join(self.models_dir, f"{symbol}_model.joblib")
                    joblib.dump(best_model, model_path)
                    logger.info(f"Saved model for {symbol} to {model_path}")
                
                return best_model
            else:
                logger.warning("No suitable model found")
                return None
        
        except Exception as e:
            logger.error(f"Error training ML model: {e}")
            return None
    
    def _prepare_ml_features(self, data):
        """
        Prepare features and target for machine learning
        
        Args:
            data (pandas.DataFrame): Historical price data
            
        Returns:
            tuple: (X, y) features and target
        """
        try:
            # Copy data to avoid modifying the original
            df = data.copy()
            
            # Create target: 1 if price goes up in next 5 days, 0 otherwise
            df['target'] = (df['close'].shift(-5) > df['close']).astype(int)
            
            # Drop rows with NaN values
            df = df.dropna()
            
            if df.empty:
                logger.warning("No data left after preparing features")
                return None, None
            
            # Select features
            feature_columns = [
                'open', 'high', 'low', 'close', 'volume',
                'sma_14', 'sma_40', 'ema_9', 'ema_21', 'rsi', 'macd', 'macd_signal', 'macd_hist',
                'bollinger_upper', 'bollinger_middle', 'bollinger_lower', 'atr',
                'stoch_k', 'stoch_d', 'adx'
            ]
            
            # Filter to only columns that exist
            feature_columns = [col for col in feature_columns if col in df.columns]
            
            if not feature_columns:
                logger.warning("No feature columns found in data")
                return None, None
            
            X = df[feature_columns].values
            y = df['target'].values
            
            return X, y
        
        except Exception as e:
            logger.error(f"Error preparing ML features: {e}")
            return None, None
    
    def _train_random_forest(self, X_train, y_train):
        """
        Train a Random Forest classifier
        
        Args:
            X_train: Training features
            y_train: Training target
            
        Returns:
            object: Trained model
        """
        try:
            # Define parameter grid
            param_grid = {
                'n_estimators': [100, 200, 300],
                'max_depth': [None, 10, 20, 30],
                'min_samples_split': [2, 5, 10],
                'min_samples_leaf': [1, 2, 4]
            }
            
            # Create model
            model = RandomForestClassifier(random_state=42)
            
            # Use GridSearchCV for hyperparameter tuning
            grid_search = GridSearchCV(
                model, param_grid, cv=3, scoring='f1_weighted', n_jobs=-1
            )
            
            # Train model
            grid_search.fit(X_train, y_train)
            
            logger.info(f"Best Random Forest parameters: {grid_search.best_params_}")
            
            return grid_search.best_estimator_
        
        except Exception as e:
            logger.error(f"Error training Random Forest: {e}")
            return None
    
    def _train_gradient_boosting(self, X_train, y_train):
        """
        Train a Gradient Boosting classifier
        
        Args:
            X_train: Training features
            y_train: Training target
            
        Returns:
            object: Trained model
        """
        try:
            # Define parameter grid
            param_grid = {
                'n_estimators': [100, 200, 300],
                'learning_rate': [0.01, 0.1, 0.2],
                'max_depth': [3, 5, 7],
                'min_samples_split': [2, 5, 10],
                'min_samples_leaf': [1, 2, 4]
            }
            
            # Create model
            model = GradientBoostingClassifier(random_state=42)
            
            # Use GridSearchCV for hyperparameter tuning
            grid_search = GridSearchCV(
                model, param_grid, cv=3, scoring='f1_weighted', n_jobs=-1
            )
            
            # Train model
            grid_search.fit(X_train, y_train)
            
            logger.info(f"Best Gradient Boosting parameters: {grid_search.best_params_}")
            
            return grid_search.best_estimator_
        
        except Exception as e:
            logger.error(f"Error training Gradient Boosting: {e}")
            return None
    
    def optimize_signal_generation(self, scanner):
        """
        Optimize signal generation for higher accuracy
        
        Args:
            scanner: Stock scanner instance
            
        Returns:
            object: Optimized scanner
        """
        logger.info("Optimizing signal generation")
        
        # Update confidence threshold
        scanner.confidence_threshold = self.min_confidence_threshold
        
        # Update scanner parameters for better accuracy
        scanner.use_consensus_signals = True
        scanner.consensus_threshold = self.consensus_threshold
        scanner.min_risk_reward_ratio = self.min_risk_reward_ratio
        scanner.max_false_signal_rate = self.max_false_signal_rate
        
        # Enable advanced filtering
        scanner.use_advanced_filtering = True
        
        return scanner
    
    def apply_accuracy_enhancements(self, scanner, data_acquisition, technical_analysis, machine_learning):
        """
        Apply all accuracy enhancements to the scanner components
        
        Args:
            scanner: Stock scanner instance
            data_acquisition: Data acquisition instance
            technical_analysis: Technical analysis instance
            machine_learning: Machine learning instance
            
        Returns:
            tuple: (scanner, data_acquisition, technical_analysis, machine_learning)
        """
        logger.info("Applying accuracy enhancements to all components")
        
        # Optimize technical indicator parameters
        sample_data = data_acquisition.get_historical_data(['SPY'], '1day')
        if 'SPY' in sample_data and sample_data['SPY'] is not None and not sample_data['SPY'].empty:
            optimized_params = self.optimize_technical_indicators(sample_data['SPY'])
            technical_analysis.update_parameters(optimized_params)
        
        # Train enhanced ML model
        if 'SPY' in sample_data and sample_data['SPY'] is not None and not sample_data['SPY'].empty:
            model = self.train_enhanced_ml_model(sample_data['SPY'], 'SPY')
            if model is not None:
                machine_learning.set_model('SPY', model)
        
        # Optimize signal generation
        scanner = self.optimize_signal_generation(scanner)
        
        return scanner, data_acquisition, technical_analysis, machine_learning
