"""
performance_optimizer.py - Performance optimization module for the Advanced Stock Scanner
"""

import logging
import multiprocessing
import numpy as np
import pandas as pd
from functools import partial
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('performance_optimizer')

class PerformanceOptimizer:
    """
    Performance optimization class for improving scanner performance
    """
    
    def __init__(self, config):
        """
        Initialize the performance optimizer
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        self.optimizer_config = config.get('performance', {})
        
        # Performance settings
        self.use_multithreading = self.optimizer_config.get('use_multithreading', True)
        self.use_multiprocessing = self.optimizer_config.get('use_multiprocessing', True)
        self.max_workers = self.optimizer_config.get('max_workers', multiprocessing.cpu_count())
        self.chunk_size = self.optimizer_config.get('chunk_size', 10)
        self.use_caching = self.optimizer_config.get('use_caching', True)
        
        logger.info(f"Performance Optimizer initialized with {self.max_workers} workers")
    
    def optimize_data_acquisition(self, data_acquisition):
        """
        Optimize data acquisition module
        
        Args:
            data_acquisition: DataAcquisition instance
            
        Returns:
            DataAcquisition: Optimized data acquisition instance
        """
        # Create a wrapper for get_historical_data to use parallel processing
        original_get_historical_data = data_acquisition.get_historical_data
        
        def optimized_get_historical_data(symbols=None, timeframe=None, period=None):
            """Optimized version of get_historical_data using parallel processing"""
            symbols = symbols or data_acquisition.default_symbols
            timeframe = timeframe or data_acquisition.timeframes['primary']
            period = period or data_acquisition.history_period
            
            # If only a few symbols, use the original method
            if len(symbols) <= 5:
                return original_get_historical_data(symbols, timeframe, period)
            
            # For many symbols, use parallel processing
            if self.use_multithreading:
                return self._parallel_get_data(data_acquisition, symbols, timeframe, period)
            else:
                return original_get_historical_data(symbols, timeframe, period)
        
        # Replace the original method with the optimized one
        data_acquisition.get_historical_data = optimized_get_historical_data
        
        # Optimize get_multi_symbol_data if it exists
        if hasattr(data_acquisition, 'get_multi_symbol_data'):
            original_get_multi_symbol_data = data_acquisition.get_multi_symbol_data
            
            def optimized_get_multi_symbol_data(symbols=None, timeframe=None, start_date=None, end_date=None):
                """Optimized version of get_multi_symbol_data using parallel processing"""
                symbols = symbols or data_acquisition.default_symbols
                timeframe = timeframe or data_acquisition.timeframes['primary']
                
                # If only a few symbols, use the original method
                if len(symbols) <= 5:
                    return original_get_multi_symbol_data(symbols, timeframe, start_date, end_date)
                
                # For many symbols, use parallel processing
                if self.use_multithreading:
                    # Define a worker function for each symbol
                    def worker(symbol):
                        try:
                            if start_date and end_date:
                                return symbol, data_acquisition._fetch_from_yfinance_with_dates(symbol, timeframe, start_date, end_date)
                            else:
                                return symbol, data_acquisition._fetch_from_yfinance(symbol, timeframe)
                        except Exception as e:
                            logger.error(f"Error fetching data for {symbol}: {e}")
                            return symbol, None
                    
                    # Process symbols in parallel
                    results = {}
                    with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                        for symbol, data in executor.map(worker, symbols):
                            if data is not None and not data.empty:
                                results[symbol] = data
                    
                    return results
                else:
                    return original_get_multi_symbol_data(symbols, timeframe, start_date, end_date)
            
            # Replace the original method with the optimized one
            data_acquisition.get_multi_symbol_data = optimized_get_multi_symbol_data
        
        logger.info("Data acquisition module optimized")
        return data_acquisition
    
    def _parallel_get_data(self, data_acquisition, symbols, timeframe, period):
        """
        Get data for multiple symbols in parallel
        
        Args:
            data_acquisition: DataAcquisition instance
            symbols (list): List of symbols
            timeframe (str): Timeframe
            period (str): Period
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        # Define a worker function for each symbol
        def worker(symbol):
            try:
                # Try to get data from cache first
                cached_data = data_acquisition._load_from_cache(symbol, timeframe)
                if cached_data is not None and not cached_data.empty:
                    return symbol, cached_data
                
                # If not in cache, fetch from source
                if timeframe == '15min':
                    # Special handling for 15-minute data
                    data = data_acquisition._fetch_recent_15min_data([symbol])
                    return symbol, data.get(symbol)
                else:
                    # Normal handling for other timeframes
                    source = data_acquisition.primary_source
                    mapped_timeframe = data_acquisition._map_timeframe(timeframe, source)
                    
                    if source == 'yfinance':
                        # Use yfinance directly
                        import yfinance as yf
                        ticker = yf.Ticker(symbol)
                        mapped_period = data_acquisition._map_period(period, source)
                        data = ticker.history(period=mapped_period, interval=mapped_timeframe)
                        
                        # Save to cache if successful
                        if not data.empty and self.use_caching:
                            data_acquisition._save_to_cache(data, symbol, timeframe)
                        
                        return symbol, data
                    else:
                        # Use the normal method for other sources
                        data = data_acquisition._fetch_from_source(source, [symbol], timeframe, period)
                        return symbol, data.get(symbol)
            except Exception as e:
                logger.error(f"Error fetching data for {symbol}: {e}")
                return symbol, None
        
        # Process symbols in parallel
        results = {}
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            for symbol, data in executor.map(worker, symbols):
                if data is not None and not data.empty:
                    results[symbol] = data
        
        return results
    
    def optimize_technical_analysis(self, technical_analysis):
        """
        Optimize technical analysis module
        
        Args:
            technical_analysis: EnhancedTechnicalAnalysis instance
            
        Returns:
            EnhancedTechnicalAnalysis: Optimized technical analysis instance
        """
        # Create a wrapper for calculate_indicators to use parallel processing for large datasets
        original_calculate_indicators = technical_analysis.calculate_indicators
        
        def optimized_calculate_indicators(data):
            """Optimized version of calculate_indicators using parallel processing for large datasets"""
            if data is None or data.empty:
                logger.warning("No data provided for technical analysis")
                return data
            
            # For small datasets, use the original method
            if len(data) <= 1000:
                return original_calculate_indicators(data)
            
            # For large datasets, use parallel processing for independent indicators
            try:
                # Make a copy to avoid modifying the original data
                df = data.copy()
                
                # Calculate indicators that can be parallelized
                with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                    # Submit tasks for independent indicators
                    sma_future = executor.submit(self._calculate_smas, df, technical_analysis.sma_periods)
                    ema_future = executor.submit(self._calculate_emas, df)
                    rsi_future = executor.submit(technical_analysis._calculate_rsi, df, technical_analysis.rsi_period)
                    macd_future = executor.submit(technical_analysis._calculate_macd, df, 
                                                technical_analysis.macd_periods[0], 
                                                technical_analysis.macd_periods[1], 
                                                technical_analysis.macd_periods[2])
                    bb_future = executor.submit(technical_analysis._calculate_bollinger_bands, df, 
                                              technical_analysis.bollinger_periods, 
                                              technical_analysis.bollinger_std)
                    atr_future = executor.submit(technical_analysis._calculate_atr, df, 14)
                    stoch_future = executor.submit(technical_analysis._calculate_stochastic, df, 14, 3, 3)
                    
                    # Get results
                    sma_results = sma_future.result()
                    for period, sma in sma_results.items():
                        df[f'sma_{period}'] = sma
                    
                    ema_results = ema_future.result()
                    df['ema_9'] = ema_results['ema_9']
                    df['ema_21'] = ema_results['ema_21']
                    
                    df['rsi'] = rsi_future.result()
                    
                    macd_result = macd_future.result()
                    df['macd'] = macd_result['macd']
                    df['macd_signal'] = macd_result['signal']
                    df['macd_hist'] = macd_result['hist']
                    
                    bollinger_result = bb_future.result()
                    df['bollinger_upper'] = bollinger_result['upper']
                    df['bollinger_middle'] = bollinger_result['middle']
                    df['bollinger_lower'] = bollinger_result['lower']
                    
                    df['atr'] = atr_future.result()
                    
                    stoch_result = stoch_future.result()
                    df['stoch_k'] = stoch_result['k']
                    df['stoch_d'] = stoch_result['d']
                
                # Calculate dependent indicators sequentially
                df['adx'] = technical_analysis._calculate_adx(df, 14)
                
                support_resistance = technical_analysis._calculate_support_resistance(df)
                df['support'] = support_resistance['support']
                df['resistance'] = support_resistance['resistance']
                
                df['trend_direction'] = technical_analysis._calculate_trend_direction(df)
                df['trend_strength'] = technical_analysis._calculate_trend_strength(df)
                df['volume_analysis'] = technical_analysis._analyze_volume(df)
                df['pattern_signals'] = technical_analysis._detect_patterns(df)
                df['stop_loss'] = technical_analysis._calculate_stop_loss(df)
                
                price_targets = technical_analysis._calculate_price_targets(df)
                df['price_target_1d'] = price_targets['1d']
                df['price_target_1w'] = price_targets['1w']
                df['price_target_1m'] = price_targets['1m']
                
                signals = technical_analysis._generate_signals(df)
                df['signal_type'] = signals['signal_type']
                df['confidence_score'] = signals['confidence_score']
                
                logger.info("Technical indicators calculated successfully (optimized)")
                return df
            except Exception as e:
                logger.error(f"Error in optimized technical analysis: {e}")
                # Fall back to original method
                return original_calculate_indicators(data)
        
        # Replace the original method with the optimized one
        technical_analysis.calculate_indicators = optimized_calculate_indicators
        
        logger.info("Technical analysis module optimized")
        return technical_analysis
    
    def _calculate_smas(self, data, periods):
        """Calculate multiple SMAs in parallel"""
        results = {}
        for period in periods:
            results[period] = data['close'].rolling(window=period).mean()
        return results
    
    def _calculate_emas(self, data):
        """Calculate multiple EMAs in parallel"""
        return {
            'ema_9': data['close'].ewm(span=9, adjust=False).mean(),
            'ema_21': data['close'].ewm(span=21, adjust=False).mean()
        }
    
    def optimize_machine_learning(self, machine_learning):
        """
        Optimize machine learning module
        
        Args:
            machine_learning: EnhancedMachineLearningEngine instance
            
        Returns:
            EnhancedMachineLearningEngine: Optimized machine learning instance
        """
        # Create a wrapper for predict to use parallel processing for large datasets
        original_predict = machine_learning.predict
        
        def optimized_predict(data):
            """Optimized version of predict using parallel processing for large datasets"""
            if data is None or data.empty:
                logger.warning("No data provided for prediction")
                return data
            
            # For small datasets, use the original method
            if len(data) <= 1000:
                return original_predict(data)
            
            # For large datasets, use the original method but with optimized feature preparation
            try:
                # Make a copy to avoid modifying the original data
                df = data.copy()
                
                # Prepare features with optimized method
                features = self._optimized_prepare_features(df, machine_learning)
                
                if features is None or features.empty:
                    logger.warning("Failed to prepare features for prediction")
                    return df
                
                # Continue with the original prediction logic
                # Scale features
                features_scaled = machine_learning.scaler.transform(features)
                
                # Make predictions
                direction_pred = machine_learning.direction_model.predict(features_scaled)
                direction_prob = machine_learning.direction_model.predict_proba(features_scaled)[:, 1]
                price_change_pred = machine_learning.price_model.predict(features_scaled)
                
                # Add predictions to dataframe
                df.loc[features.index, 'pred_direction'] = direction_pred
                df.loc[features.index, 'pred_direction_prob'] = direction_prob
                df.loc[features.index, 'pred_price_change'] = price_change_pred
                
                # Calculate predicted prices
                for horizon in machine_learning.prediction_horizon:
                    df.loc[features.index, f'pred_price_{horizon}d'] = df.loc[features.index, 'close'] * (1 + df.loc[features.index, 'pred_price_change'])
                
                # Calculate confidence scores
                df.loc[features.index, 'ml_confidence'] = direction_prob * 100
                
                # Adjust confidence based on prediction probability
                df.loc[features.index, 'ml_confidence'] = df.loc[features.index, 'ml_confidence'].apply(
                    lambda x: max(min(x, 100), 0)  # Ensure confidence is between 0 and 100
                )
                
                # Generate signals based on confidence
                df.loc[features.index, 'ml_signal'] = 'Neutral'
                df.loc[(features.index) & (df['pred_direction'] == 1) & (df['ml_confidence'] >= 80), 'ml_signal'] = 'Strong Bullish'
                df.loc[(features.index) & (df['pred_direction'] == 1) & (df['ml_confidence'] >= 60) & (df['ml_confidence'] < 80), 'ml_signal'] = 'Bullish'
                df.loc[(features.index) & (df['pred_direction'] == 1) & (df['ml_confidence'] >= 50) & (df['ml_confidence'] < 60), 'ml_signal'] = 'Moderately Bullish'
                df.loc[(features.index) & (df['pred_direction'] == 0) & (df['ml_confidence'] >= 80), 'ml_signal'] = 'Strong Bearish'
                df.loc[(features.index) & (df['pred_direction'] == 0) & (df['ml_confidence'] >= 60) & (df['ml_confidence'] < 80), 'ml_signal'] = 'Bearish'
                df.loc[(features.index) & (df['pred_direction'] == 0) & (df['ml_confidence'] >= 50) & (df['ml_confidence'] < 60), 'ml_signal'] = 'Moderately Bearish'
                
                logger.info("Predictions generated successfully (optimized)")
                return df
            except Exception as e:
                logger.error(f"Error in optimized prediction: {e}")
                # Fall back to original method
                return original_predict(data)
        
        # Replace the original method with the optimized one
        machine_learning.predict = optimized_predict
        
        logger.info("Machine learning module optimized")
        return machine_learning
    
    def _optimized_prepare_features(self, data, machine_learning):
        """Optimized version of _prepare_features"""
        if data is None or data.empty:
            logger.warning("No data provided for feature preparation")
            return None
        
        # Make a copy to avoid modifying the original data
        df = data.copy()
        
        # Select feature columns that exist in the data
        available_features = [col for col in machine_learning.feature_columns if col in df.columns]
        
        if not available_features:
            logger.warning("No valid feature columns found in data")
            return None
        
        # Select features and drop NaN values
        features = df[available_features].copy()
        features.dropna(inplace=True)
        
        if features.empty:
            logger.warning("No valid data after dropping NaN values")
            return None
        
        # Add derived features in parallel
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit tasks for derived features
            futures = []
            
            if 'sma_14' in features.columns and 'sma_40' in features.columns:
                futures.append(executor.submit(lambda: features['sma_14'] / features['sma_40']))
            
            if 'macd' in features.columns and 'macd_signal' in features.columns:
                futures.append(executor.submit(lambda: features['macd'] - features['macd_signal']))
            
            if 'bollinger_upper' in features.columns and 'bollinger_lower' in features.columns and 'close' in df.columns:
                close = df.loc[features.index, 'close']
                futures.append(executor.submit(lambda: (close - features['bollinger_lower']) / (features['bollinger_upper'] - features['bollinger_lower'])))
            
            # Get results
            if len(futures) >= 1 and 'sma_14' in features.columns and 'sma_40' in features.columns:
                features['sma_ratio'] = futures[0].result()
            
            if len(futures) >= 2 and 'macd' in features.columns and 'macd_signal' in features.columns:
                features['macd_diff'] = futures[1].result()
            
            if len(futures) >= 3 and 'bollinger_upper' in features.columns and 'bollinger_lower' in features.columns and 'close' in df.columns:
                features['bb_position'] = futures[2].result()
        
        # Add lag features
        for col in available_features:
            if col in features.columns:
                features[f'{col}_lag1'] = features[col].shift(1)
                features[f'{col}_lag2'] = features[col].shift(2)
        
        # Drop NaN values again after adding derived and lag features
        features.dropna(inplace=True)
        
        return features
