"""
continuous_operation.py - Continuous Operation Module for the Advanced Stock Scanner
"""

import os
import time
import logging
import threading
import datetime
import schedule
import json
import signal
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("scanner_continuous.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('continuous_operation')

class ContinuousOperation:
    """
    Continuous Operation Module for the Advanced Stock Scanner
    """
    
    def __init__(self, config, data_acquisition, technical_analysis, sentiment_analysis, price_prediction):
        """
        Initialize the continuous operation module
        
        Args:
            config (dict): Configuration dictionary
            data_acquisition: Data acquisition module
            technical_analysis: Technical analysis module
            sentiment_analysis: Sentiment analysis module
            price_prediction: Price prediction module
        """
        self.config = config
        self.data_acquisition = data_acquisition
        self.technical_analysis = technical_analysis
        self.sentiment_analysis = sentiment_analysis
        self.price_prediction = price_prediction
        
        self.running = False
        self.thread = None
        self.results_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'results')
        
        # Create results directory if it doesn't exist
        os.makedirs(self.results_dir, exist_ok=True)
        
        # Load schedule configuration
        self.schedule_config = self._load_schedule_config()
        
        logger.info("Continuous Operation Module initialized")
    
    def _load_schedule_config(self):
        """
        Load schedule configuration
        
        Returns:
            dict: Schedule configuration
        """
        schedule_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'schedule.json')
        
        if os.path.exists(schedule_file):
            try:
                with open(schedule_file, 'r') as f:
                    schedule_config = json.load(f)
                logger.info(f"Loaded schedule configuration from {schedule_file}")
                return schedule_config
            except Exception as e:
                logger.error(f"Error loading schedule configuration from {schedule_file}: {e}")
                return self._create_default_schedule()
        else:
            return self._create_default_schedule()
    
    def _create_default_schedule(self):
        """
        Create default schedule configuration
        
        Returns:
            dict: Default schedule configuration
        """
        schedule_config = {
            "daily_scan": {
                "enabled": True,
                "time": "17:00",  # Market close
                "days": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                "symbols": [],  # Empty for default symbols
                "timeframe": "1day",
                "lookback_days": 30
            },
            "hourly_scan": {
                "enabled": False,
                "interval_hours": 1,
                "start_time": "09:30",  # Market open
                "end_time": "16:00",  # Before market close
                "days": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                "symbols": [],  # Empty for default symbols
                "timeframe": "1hour",
                "lookback_days": 5
            },
            "weekly_scan": {
                "enabled": True,
                "day": "Friday",
                "time": "18:00",  # After market close
                "symbols": [],  # Empty for default symbols
                "timeframe": "1week",
                "lookback_days": 90
            }
        }
        
        # Save the schedule configuration
        schedule_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'schedule.json')
        try:
            with open(schedule_file, 'w') as f:
                json.dump(schedule_config, f, indent=4)
            logger.info(f"Created default schedule configuration at {schedule_file}")
        except Exception as e:
            logger.error(f"Error saving default schedule configuration to {schedule_file}: {e}")
        
        return schedule_config
    
    def _save_schedule_config(self):
        """
        Save schedule configuration
        """
        schedule_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'schedule.json')
        try:
            with open(schedule_file, 'w') as f:
                json.dump(self.schedule_config, f, indent=4)
            logger.info(f"Saved schedule configuration to {schedule_file}")
        except Exception as e:
            logger.error(f"Error saving schedule configuration to {schedule_file}: {e}")
    
    def update_schedule(self, schedule_type, **kwargs):
        """
        Update schedule configuration
        
        Args:
            schedule_type (str): Type of schedule to update (daily_scan, hourly_scan, weekly_scan)
            **kwargs: Schedule parameters to update
            
        Returns:
            bool: Success
        """
        if schedule_type not in self.schedule_config:
            logger.error(f"Invalid schedule type: {schedule_type}")
            return False
        
        # Update schedule parameters
        for key, value in kwargs.items():
            if key in self.schedule_config[schedule_type]:
                self.schedule_config[schedule_type][key] = value
        
        # Save updated configuration
        self._save_schedule_config()
        
        # Reset schedule if running
        if self.running:
            self.stop()
            self.start()
        
        return True
    
    def _run_scan(self, symbols, timeframe, lookback_days):
        """
        Run a scan for the specified symbols and timeframe
        
        Args:
            symbols (list): List of symbols to scan
            timeframe (str): Timeframe to scan
            lookback_days (int): Number of days to look back
            
        Returns:
            dict: Scan results
        """
        try:
            # Calculate date range
            end_date = datetime.datetime.now().strftime('%Y-%m-%d')
            start_date = (datetime.datetime.now() - datetime.timedelta(days=lookback_days)).strftime('%Y-%m-%d')
            
            results = {}
            
            # Use default symbols if none provided
            if not symbols:
                from stock_list_500 import get_default_symbols
                symbols = get_default_symbols()
            
            # Process each symbol
            for symbol in symbols:
                try:
                    logger.info(f"Scanning {symbol} with timeframe {timeframe}...")
                    
                    # Get data
                    data = self.data_acquisition.get_symbol_data(symbol, timeframe, start_date, end_date)
                    
                    if data is None or data.empty:
                        logger.warning(f"No data returned for {symbol}")
                        continue
                    
                    # Calculate technical indicators
                    data = self.technical_analysis.calculate_indicators(data)
                    
                    # Perform sentiment analysis
                    data = self.sentiment_analysis.analyze_sentiment(data)
                    
                    # Calculate price predictions
                    data = self.price_prediction.predict_prices(data)
                    
                    # Store only the latest data point for summary
                    results[symbol] = data.iloc[-1].to_dict()
                    logger.info(f"Scan completed for {symbol}")
                except Exception as e:
                    logger.error(f"Error processing {symbol}: {e}")
            
            # Save results
            timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            results_file = os.path.join(self.results_dir, f"scan_{timeframe}_{timestamp}.json")
            
            try:
                with open(results_file, 'w') as f:
                    json.dump(results, f, indent=4)
                logger.info(f"Saved scan results to {results_file}")
            except Exception as e:
                logger.error(f"Error saving scan results to {results_file}: {e}")
            
            return results
        except Exception as e:
            logger.error(f"Error running scan: {e}")
            return {}
    
    def _run_daily_scan(self):
        """
        Run daily scan based on schedule configuration
        """
        config = self.schedule_config["daily_scan"]
        if not config["enabled"]:
            return
        
        # Check if today is a scheduled day
        today = datetime.datetime.now().strftime('%A')
        if today not in config["days"]:
            logger.info(f"Daily scan not scheduled for {today}")
            return
        
        logger.info("Running daily scan...")
        self._run_scan(config["symbols"], config["timeframe"], config["lookback_days"])
    
    def _run_hourly_scan(self):
        """
        Run hourly scan based on schedule configuration
        """
        config = self.schedule_config["hourly_scan"]
        if not config["enabled"]:
            return
        
        # Check if today is a scheduled day
        today = datetime.datetime.now().strftime('%A')
        if today not in config["days"]:
            logger.info(f"Hourly scan not scheduled for {today}")
            return
        
        # Check if current time is within scheduled hours
        now = datetime.datetime.now().time()
        start_time = datetime.datetime.strptime(config["start_time"], "%H:%M").time()
        end_time = datetime.datetime.strptime(config["end_time"], "%H:%M").time()
        
        if not (start_time <= now <= end_time):
            logger.info(f"Current time {now} is outside scheduled hours {start_time}-{end_time}")
            return
        
        logger.info("Running hourly scan...")
        self._run_scan(config["symbols"], config["timeframe"], config["lookback_days"])
    
    def _run_weekly_scan(self):
        """
        Run weekly scan based on schedule configuration
        """
        config = self.schedule_config["weekly_scan"]
        if not config["enabled"]:
            return
        
        # Check if today is the scheduled day
        today = datetime.datetime.now().strftime('%A')
        if today != config["day"]:
            logger.info(f"Weekly scan not scheduled for {today}")
            return
        
        logger.info("Running weekly scan...")
        self._run_scan(config["symbols"], config["timeframe"], config["lookback_days"])
    
    def _schedule_jobs(self):
        """
        Schedule jobs based on configuration
        """
        # Clear existing jobs
        schedule.clear()
        
        # Schedule daily scan
        if self.schedule_config["daily_scan"]["enabled"]:
            daily_time = self.schedule_config["daily_scan"]["time"]
            schedule.every().day.at(daily_time).do(self._run_daily_scan)
            logger.info(f"Scheduled daily scan at {daily_time}")
        
        # Schedule hourly scan
        if self.schedule_config["hourly_scan"]["enabled"]:
            interval_hours = self.schedule_config["hourly_scan"]["interval_hours"]
            schedule.every(interval_hours).hours.do(self._run_hourly_scan)
            logger.info(f"Scheduled hourly scan every {interval_hours} hours")
        
        # Schedule weekly scan
        if self.schedule_config["weekly_scan"]["enabled"]:
            weekly_day = self.schedule_config["weekly_scan"]["day"].lower()
            weekly_time = self.schedule_config["weekly_scan"]["time"]
            
            if weekly_day == "monday":
                schedule.every().monday.at(weekly_time).do(self._run_weekly_scan)
            elif weekly_day == "tuesday":
                schedule.every().tuesday.at(weekly_time).do(self._run_weekly_scan)
            elif weekly_day == "wednesday":
                schedule.every().wednesday.at(weekly_time).do(self._run_weekly_scan)
            elif weekly_day == "thursday":
                schedule.every().thursday.at(weekly_time).do(self._run_weekly_scan)
            elif weekly_day == "friday":
                schedule.every().friday.at(weekly_time).do(self._run_weekly_scan)
            elif weekly_day == "saturday":
                schedule.every().saturday.at(weekly_time).do(self._run_weekly_scan)
            elif weekly_day == "sunday":
                schedule.every().sunday.at(weekly_time).do(self._run_weekly_scan)
            
            logger.info(f"Scheduled weekly scan on {weekly_day} at {weekly_time}")
    
    def _run_scheduler(self):
        """
        Run the scheduler loop
        """
        self._schedule_jobs()
        
        # Run initial scans
        self._run_daily_scan()
        
        while self.running:
            try:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
            except Exception as e:
                logger.error(f"Error in scheduler loop: {e}")
                time.sleep(300)  # Wait 5 minutes before retrying
    
    def start(self):
        """
        Start continuous operation
        
        Returns:
            bool: Success
        """
        if self.running:
            logger.warning("Continuous operation already running")
            return False
        
        self.running = True
        self.thread = threading.Thread(target=self._run_scheduler)
        self.thread.daemon = True
        self.thread.start()
        
        logger.info("Continuous operation started")
        return True
    
    def stop(self):
        """
        Stop continuous operation
        
        Returns:
            bool: Success
        """
        if not self.running:
            logger.warning("Continuous operation not running")
            return False
        
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
            self.thread = None
        
        logger.info("Continuous operation stopped")
        return True
    
    def status(self):
        """
        Get continuous operation status
        
        Returns:
            dict: Status information
        """
        status_info = {
            "running": self.running,
            "schedule": self.schedule_config,
            "next_scans": []
        }
        
        # Get next scheduled scans
        if self.running:
            for job in schedule.jobs:
                status_info["next_scans"].append({
                    "job": str(job),
                    "next_run": job.next_run.strftime('%Y-%m-%d %H:%M:%S')
                })
        
        return status_info
    
    def run_manual_scan(self, symbols=None, timeframe="1day", lookback_days=30):
        """
        Run a manual scan
        
        Args:
            symbols (list, optional): List of symbols to scan. Defaults to None.
            timeframe (str, optional): Timeframe to scan. Defaults to "1day".
            lookback_days (int, optional): Number of days to look back. Defaults to 30.
            
        Returns:
            dict: Scan results
        """
        logger.info(f"Running manual scan with timeframe {timeframe}...")
        return self._run_scan(symbols, timeframe, lookback_days)
    
    def get_latest_results(self, timeframe=None):
        """
        Get latest scan results
        
        Args:
            timeframe (str, optional): Filter by timeframe. Defaults to None.
            
        Returns:
            dict: Latest scan results
        """
        try:
            # Get list of result files
            result_files = [f for f in os.listdir(self.results_dir) if f.endswith('.json')]
            
            if not result_files:
                logger.warning("No result files found")
                return {}
            
            # Filter by timeframe if specified
            if timeframe:
                result_files = [f for f in result_files if f"scan_{timeframe}_" in f]
            
            if not result_files:
                logger.warning(f"No result files found for timeframe {timeframe}")
                return {}
            
            # Sort by timestamp (newest first)
            result_files.sort(reverse=True)
            
            # Load latest results
            latest_file = os.path.join(self.results_dir, result_files[0])
            
            with open(latest_file, 'r') as f:
                results = json.load(f)
            
            logger.info(f"Loaded latest results from {latest_file}")
            return results
        except Exception as e:
            logger.error(f"Error getting latest results: {e}")
            return {}
