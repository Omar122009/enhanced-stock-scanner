"""
technical_analysis_enhanced.py - Enhanced Technical Analysis module for the Advanced Stock Scanner
"""

import pandas as pd
import numpy as np
import logging
import ta
from ta.trend import SMAIndicator, EMAIndicator, MACD, ADXIndicator
from ta.momentum import RSIIndicator, StochasticOscillator
from ta.volatility import BollingerBands, AverageTrueRange
from ta.volume import VolumeWeightedAveragePrice

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('technical_analysis')

class EnhancedTechnicalAnalysis:
    """
    Enhanced Technical Analysis class for calculating technical indicators
    """
    
    def __init__(self, config):
        """
        Initialize the technical analysis module
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        self.ta_config = config['technical_analysis']
        
        # SMA periods
        self.sma_periods = self.ta_config['sma_periods']
        
        # RSI parameters
        self.rsi_period = self.ta_config['rsi_period']
        self.rsi_overbought = self.ta_config['rsi_overbought']
        self.rsi_oversold = self.ta_config['rsi_oversold']
        
        # MACD parameters
        self.macd_periods = self.ta_config['macd_periods']
        
        # Bollinger Bands parameters
        self.bollinger_periods = self.ta_config['bollinger_periods']
        self.bollinger_std = self.ta_config['bollinger_std']
        
        logger.info("Enhanced Technical Analysis initialized")
    
    def calculate_indicators(self, data):
        """
        Calculate technical indicators for the given data
        
        Args:
            data (pandas.DataFrame): OHLCV data
            
        Returns:
            pandas.DataFrame: Data with technical indicators
        """
        if data is None or data.empty:
            logger.warning("No data provided for technical analysis")
            return data
        
        # Make a copy to avoid modifying the original data
        df = data.copy()
        
        try:
            # Calculate SMA
            for period in self.sma_periods:
                df[f'sma_{period}'] = self._calculate_sma(df, period)
            
            # Calculate EMA
            df['ema_9'] = self._calculate_ema(df, 9)
            df['ema_21'] = self._calculate_ema(df, 21)
            
            # Calculate RSI
            df['rsi'] = self._calculate_rsi(df, self.rsi_period)
            
            # Calculate MACD
            macd_result = self._calculate_macd(df, self.macd_periods[0], self.macd_periods[1], self.macd_periods[2])
            df['macd'] = macd_result['macd']
            df['macd_signal'] = macd_result['signal']
            df['macd_hist'] = macd_result['hist']
            
            # Calculate Bollinger Bands
            bollinger_result = self._calculate_bollinger_bands(df, self.bollinger_periods, self.bollinger_std)
            df['bollinger_upper'] = bollinger_result['upper']
            df['bollinger_middle'] = bollinger_result['middle']
            df['bollinger_lower'] = bollinger_result['lower']
            
            # Calculate ATR
            df['atr'] = self._calculate_atr(df, 14)
            
            # Calculate Stochastic Oscillator
            stoch_result = self._calculate_stochastic(df, 14, 3, 3)
            df['stoch_k'] = stoch_result['k']
            df['stoch_d'] = stoch_result['d']
            
            # Calculate ADX
            df['adx'] = self._calculate_adx(df, 14)
            
            # Calculate support and resistance
            support_resistance = self._calculate_support_resistance(df)
            df['support'] = support_resistance['support']
            df['resistance'] = support_resistance['resistance']
            
            # Calculate trend direction
            df['trend_direction'] = self._calculate_trend_direction(df)
            
            # Calculate trend strength
            df['trend_strength'] = self._calculate_trend_strength(df)
            
            # Calculate volume analysis
            df['volume_analysis'] = self._analyze_volume(df)
            
            # Calculate pattern signals
            df['pattern_signals'] = self._detect_patterns(df)
            
            # Calculate stop loss levels
            df['stop_loss'] = self._calculate_stop_loss(df)
            
            # Calculate price targets
            price_targets = self._calculate_price_targets(df)
            df['price_target_1d'] = price_targets['1d']
            df['price_target_1w'] = price_targets['1w']
            df['price_target_1m'] = price_targets['1m']
            
            # Calculate signal type and confidence score
            signals = self._generate_signals(df)
            df['signal_type'] = signals['signal_type']
            df['confidence_score'] = signals['confidence_score']
            
            logger.info("Technical indicators calculated successfully")
            return df
        except Exception as e:
            logger.error(f"Error calculating technical indicators: {e}")
            raise RuntimeError(f"Error calculating technical indicators: {e}")
    
    def _calculate_sma(self, data, period):
        """Calculate Simple Moving Average"""
        return data['close'].rolling(window=period).mean()
    
    def _calculate_ema(self, data, period):
        """Calculate Exponential Moving Average"""
        return data['close'].ewm(span=period, adjust=False).mean()
    
    def _calculate_rsi(self, data, period):
        """Calculate Relative Strength Index"""
        try:
            rsi_indicator = RSIIndicator(close=data['close'], window=period)
            return rsi_indicator.rsi()
        except Exception as e:
            logger.error(f"Error calculating RSI: {e}")
            # Fallback calculation
            delta = data['close'].diff()
            gain = delta.where(delta > 0, 0)
            loss = -delta.where(delta < 0, 0)
            
            avg_gain = gain.rolling(window=period).mean()
            avg_loss = loss.rolling(window=period).mean()
            
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            return rsi
    
    def _calculate_macd(self, data, fast_period, slow_period, signal_period):
        """Calculate MACD"""
        try:
            macd_indicator = MACD(
                close=data['close'],
                window_slow=slow_period,
                window_fast=fast_period,
                window_sign=signal_period
            )
            
            return {
                'macd': macd_indicator.macd(),
                'signal': macd_indicator.macd_signal(),
                'hist': macd_indicator.macd_diff()
            }
        except Exception as e:
            logger.error(f"Error calculating MACD: {e}")
            # Fallback calculation
            ema_fast = data['close'].ewm(span=fast_period, adjust=False).mean()
            ema_slow = data['close'].ewm(span=slow_period, adjust=False).mean()
            macd = ema_fast - ema_slow
            signal = macd.ewm(span=signal_period, adjust=False).mean()
            hist = macd - signal
            return {
                'macd': macd,
                'signal': signal,
                'hist': hist
            }
    
    def _calculate_bollinger_bands(self, data, period, std_dev):
        """Calculate Bollinger Bands"""
        try:
            bollinger = BollingerBands(
                close=data['close'],
                window=period,
                window_dev=std_dev
            )
            return {
                'upper': bollinger.bollinger_hband(),
                'middle': bollinger.bollinger_mavg(),
                'lower': bollinger.bollinger_lband()
            }
        except Exception as e:
            logger.error(f"Error calculating Bollinger Bands: {e}")
            # Fallback calculation
            middle = data['close'].rolling(window=period).mean()
            std = data['close'].rolling(window=period).std()
            upper = middle + (std * std_dev)
            lower = middle - (std * std_dev)
            return {
                'upper': upper,
                'middle': middle,
                'lower': lower
            }
    
    def _calculate_atr(self, data, period):
        """Calculate Average True Range"""
        try:
            atr_indicator = AverageTrueRange(
                high=data['high'],
                low=data['low'],
                close=data['close'],
                window=period
            )
            return atr_indicator.average_true_range()
        except Exception as e:
            logger.error(f"Error calculating ATR: {e}")
            # Fallback calculation
            high_low = data['high'] - data['low']
            high_close = (data['high'] - data['close'].shift()).abs()
            low_close = (data['low'] - data['close'].shift()).abs()
            
            ranges = pd.concat([high_low, high_close, low_close], axis=1)
            true_range = ranges.max(axis=1)
            
            return true_range.rolling(period).mean()
    
    def _calculate_stochastic(self, data, k_period, k_slowing, d_period):
        """Calculate Stochastic Oscillator"""
        try:
            stoch = StochasticOscillator(
                high=data['high'],
                low=data['low'],
                close=data['close'],
                window=k_period,
                smooth_window=k_slowing
            )
            return {
                'k': stoch.stoch(),
                'd': stoch.stoch_signal()
            }
        except Exception as e:
            logger.error(f"Error calculating Stochastic: {e}")
            # Fallback calculation
            low_min = data['low'].rolling(window=k_period).min()
            high_max = data['high'].rolling(window=k_period).max()
            
            k = 100 * ((data['close'] - low_min) / (high_max - low_min))
            k = k.rolling(window=k_slowing).mean()
            d = k.rolling(window=d_period).mean()
            
            return {
                'k': k,
                'd': d
            }
    
    def _calculate_adx(self, data, period):
        """Calculate Average Directional Index"""
        try:
            adx_indicator = ADXIndicator(
                high=data['high'],
                low=data['low'],
                close=data['close'],
                window=period
            )
            return adx_indicator.adx()
        except Exception as e:
            logger.error(f"Error calculating ADX: {e}")
            # Fallback to a simple trend strength calculation
            return self._calculate_trend_strength(data)
    
    def _calculate_support_resistance(self, data):
        """Calculate support and resistance levels"""
        # Simple implementation using recent lows and highs
        window = 20
        
        # Get recent lows and highs
        recent_lows = data['low'].rolling(window=window, center=True).min()
        recent_highs = data['high'].rolling(window=window, center=True).max()
        
        # Calculate support as the average of the 3 most recent lows
        support = recent_lows.rolling(window=3).mean()
        
        # Calculate resistance as the average of the 3 most recent highs
        resistance = recent_highs.rolling(window=3).mean()
        
        return {
            'support': support.values,
            'resistance': resistance.values
        }
    
    def _calculate_trend_direction(self, data):
        """Calculate trend direction"""
        # Use SMA crossover to determine trend direction
        if 'sma_14' in data.columns and 'sma_40' in data.columns:
            # Create a trend direction series
            trend = pd.Series(index=data.index, dtype='object')
            
            # Calculate trend based on SMA crossover
            trend[(data['sma_14'] > data['sma_40'])] = 'Bullish'
            trend[(data['sma_14'] < data['sma_40'])] = 'Bearish'
            
            # Fill any remaining NaN values with 'Neutral'
            trend.fillna('Neutral', inplace=True)
            
            return trend
        else:
            # Fallback if SMAs are not available
            return pd.Series('Neutral', index=data.index)
    
    def _calculate_trend_strength(self, data):
        """Calculate trend strength (0-100)"""
        # Use ADX as trend strength if available
        if 'adx' in data.columns:
            return data['adx']
        
        # Simple implementation using price movement and volume
        if len(data) < 10:
            return pd.Series(50, index=data.index)
        
        # Calculate price movement
        price_change = (data['close'] - data['close'].shift(10)).abs() / data['close'].shift(10) * 100
        
        # Calculate volume change
        volume_change = (data['volume'] / data['volume'].rolling(window=10).mean()) * 100
        
        # Combine price and volume changes to get trend strength
        trend_strength = (price_change * 0.7 + volume_change * 0.3).clip(0, 100)
        
        return trend_strength
    
    def _analyze_volume(self, data):
        """Analyze volume patterns"""
        # Create a volume analysis series
        volume_analysis = pd.Series(index=data.index, dtype='object')
        
        # Calculate average volume
        avg_volume = data['volume'].rolling(window=20).mean()
        
        # Calculate volume ratio
        volume_ratio = data['volume'] / avg_volume
        
        # Analyze volume based on price movement and volume ratio
        for i in range(1, len(data)):
            if i < 1:
                volume_analysis.iloc[i] = 'Neutral'
                continue
                
            price_up = data['close'].iloc[i] > data['close'].iloc[i-1]
            high_volume = volume_ratio.iloc[i] > 1.5
            very_high_volume = volume_ratio.iloc[i] > 2.5
            low_volume = volume_ratio.iloc[i] < 0.5
            
            if price_up and very_high_volume:
                volume_analysis.iloc[i] = 'Strong Bullish'
            elif price_up and high_volume:
                volume_analysis.iloc[i] = 'Bullish'
            elif not price_up and very_high_volume:
                volume_analysis.iloc[i] = 'Strong Bearish'
            elif not price_up and high_volume:
                volume_analysis.iloc[i] = 'Bearish'
            elif price_up and low_volume:
                volume_analysis.iloc[i] = 'Weak Bullish'
            elif not price_up and low_volume:
                volume_analysis.iloc[i] = 'Weak Bearish'
            else:
                volume_analysis.iloc[i] = 'Neutral'
        
        return volume_analysis
    
    def _detect_patterns(self, data):
        """Detect chart patterns"""
        # Initialize pattern signals
        pattern_signals = pd.Series(index=data.index, dtype='object')
        pattern_signals = pattern_signals.apply(lambda x: [])
        
        try:
            # Custom implementation of candlestick pattern detection
            patterns = {}
            
            # Initialize pattern arrays
            for pattern in ['Hammer', 'Inverted Hammer', 'Engulfing', 'Morning Star', 
                           'Evening Star', 'Doji', 'Shooting Star']:
                patterns[pattern] = np.zeros(len(data))
            
            # Loop through data to detect patterns
            for i in range(2, len(data)):
                # Skip if not enough data
                if i < 2:
                    continue
                
                # Get current and previous candles
                curr_open = data['open'].iloc[i]
                curr_high = data['high'].iloc[i]
                curr_low = data['low'].iloc[i]
                curr_close = data['close'].iloc[i]
                
                prev_open = data['open'].iloc[i-1]
                prev_high = data['high'].iloc[i-1]
                prev_low = data['low'].iloc[i-1]
                prev_close = data['close'].iloc[i-1]
                
                prev2_open = data['open'].iloc[i-2]
                prev2_high = data['high'].iloc[i-2]
                prev2_low = data['low'].iloc[i-2]
                prev2_close = data['close'].iloc[i-2]
                
                # Calculate candle properties
                curr_body_size = abs(curr_close - curr_open)
                curr_range = curr_high - curr_low
                curr_upper_shadow = curr_high - max(curr_open, curr_close)
                curr_lower_shadow = min(curr_open, curr_close) - curr_low
                
                prev_body_size = abs(prev_close - prev_open)
                prev_range = prev_high - prev_low
                
                # Detect Hammer
                if (curr_body_size <= 0.3 * curr_range and  # Small body
                    curr_lower_shadow >= 2 * curr_body_size and  # Long lower shadow
                    curr_upper_shadow <= 0.1 * curr_range):  # Short upper shadow
                    if curr_close > curr_open:  # Bullish
                        patterns['Hammer'][i] = 100
                    else:  # Bearish
                        patterns['Hammer'][i] = -100
                
                # Detect Inverted Hammer
                if (curr_body_size <= 0.3 * curr_range and  # Small body
                    curr_upper_shadow >= 2 * curr_body_size and  # Long upper shadow
                    curr_lower_shadow <= 0.1 * curr_range):  # Short lower shadow
                    if curr_close > curr_open:  # Bullish
                        patterns['Inverted Hammer'][i] = 100
                    else:  # Bearish
                        patterns['Inverted Hammer'][i] = -100
                
                # Detect Engulfing
                if (curr_body_size > prev_body_size and  # Current body engulfs previous body
                    ((curr_close > curr_open and prev_close < prev_open) or  # Bullish engulfing
                     (curr_close < curr_open and prev_close > prev_open))):  # Bearish engulfing
                    if curr_close > curr_open:  # Bullish
                        patterns['Engulfing'][i] = 100
                    else:  # Bearish
                        patterns['Engulfing'][i] = -100
                
                # Detect Morning Star
                if (i >= 2 and
                    prev2_close < prev2_open and  # First candle is bearish
                    abs(prev_close - prev_open) < 0.3 * prev2_body_size and  # Second candle has small body
                    curr_close > curr_open and  # Third candle is bullish
                    curr_close > (prev2_open + prev2_close) / 2):  # Third close above midpoint of first candle
                    patterns['Morning Star'][i] = 100
                
                # Detect Evening Star
                if (i >= 2 and
                    prev2_close > prev2_open and  # First candle is bullish
                    abs(prev_close - prev_open) < 0.3 * prev2_body_size and  # Second candle has small body
                    curr_close < curr_open and  # Third candle is bearish
                    curr_close < (prev2_open + prev2_close) / 2):  # Third close below midpoint of first candle
                    patterns['Evening Star'][i] = -100
                
                # Detect Doji
                if curr_body_size <= 0.1 * curr_range:  # Very small body
                    patterns['Doji'][i] = 100 if curr_close >= curr_open else -100
                
                # Detect Shooting Star
                if (curr_body_size <= 0.3 * curr_range and  # Small body
                    curr_upper_shadow >= 2 * curr_body_size and  # Long upper shadow
                    curr_lower_shadow <= 0.1 * curr_range and  # Short lower shadow
                    curr_close < curr_open):  # Bearish
                    patterns['Shooting Star'][i] = -100
            
            # Add detected patterns to the pattern signals
            for pattern_name, pattern_values in patterns.items():
                for i in range(len(pattern_values)):
                    if pattern_values[i] != 0:
                        if isinstance(pattern_signals.iloc[i], list):
                            pattern_signals.iloc[i].append(f"{pattern_name} ({'Bullish' if pattern_values[i] > 0 else 'Bearish'})")
                        else:
                            pattern_signals.iloc[i] = [f"{pattern_name} ({'Bullish' if pattern_values[i] > 0 else 'Bearish'})"]
        except Exception as e:
            logger.warning(f"Error detecting patterns: {e}")
        
        return pattern_signals
    
    def _calculate_stop_loss(self, data):
        """Calculate stop loss levels"""
        # Initialize stop loss series
        stop_loss = pd.Series(index=data.index)
        
        # Calculate ATR-based stop loss
        if 'atr' in data.columns:
            # For bullish positions, stop loss is current price - 2*ATR
            bullish_stop = data['close'] - 2 * data['atr']
            
            # For bearish positions, stop loss is current price + 2*ATR
            bearish_stop = data['close'] + 2 * data['atr']
            
            # Assign stop loss based on trend direction
            if 'trend_direction' in data.columns:
                for i in range(len(data)):
                    if data['trend_direction'].iloc[i] == 'Bullish':
                        stop_loss.iloc[i] = bullish_stop.iloc[i]
                    elif data['trend_direction'].iloc[i] == 'Bearish':
                        stop_loss.iloc[i] = bearish_stop.iloc[i]
                    else:
                        # For neutral trend, use a wider stop loss
                        stop_loss.iloc[i] = bullish_stop.iloc[i]
            else:
                # Default to bullish stop loss if trend direction is not available
                stop_loss = bullish_stop
        else:
            # Fallback to a percentage-based stop loss if ATR is not available
            stop_loss = data['close'] * 0.95  # 5% below current price
        
        return stop_loss
    
    def _calculate_price_targets(self, data):
        """Calculate price targets"""
        # Initialize price target series
        price_target_1d = pd.Series(index=data.index)
        price_target_1w = pd.Series(index=data.index)
        price_target_1m = pd.Series(index=data.index)
        
        # Calculate price targets based on trend and volatility
        if 'atr' in data.columns and 'trend_direction' in data.columns:
            for i in range(len(data)):
                close = data['close'].iloc[i]
                atr = data['atr'].iloc[i]
                
                if pd.isna(atr):
                    # If ATR is NaN, use a percentage of close price
                    atr = close * 0.02  # 2% of close price
                
                if data['trend_direction'].iloc[i] == 'Bullish':
                    # Bullish targets
                    price_target_1d.iloc[i] = close + 1 * atr
                    price_target_1w.iloc[i] = close + 5 * atr
                    price_target_1m.iloc[i] = close + 15 * atr
                elif data['trend_direction'].iloc[i] == 'Bearish':
                    # Bearish targets
                    price_target_1d.iloc[i] = close - 1 * atr
                    price_target_1w.iloc[i] = close - 5 * atr
                    price_target_1m.iloc[i] = close - 15 * atr
                else:
                    # Neutral targets
                    price_target_1d.iloc[i] = close
                    price_target_1w.iloc[i] = close
                    price_target_1m.iloc[i] = close
        else:
            # Fallback to simple percentage-based targets
            price_target_1d = data['close'] * 1.01  # 1% increase
            price_target_1w = data['close'] * 1.05  # 5% increase
            price_target_1m = data['close'] * 1.10  # 10% increase
        
        return {
            '1d': price_target_1d,
            '1w': price_target_1w,
            '1m': price_target_1m
        }
    
    def _generate_signals(self, data):
        """Generate trading signals and confidence scores"""
        # Initialize signal type and confidence score series
        signal_type = pd.Series(index=data.index, dtype='object')
        confidence_score = pd.Series(index=data.index, dtype='float')
        
        # Default values
        signal_type.fillna('Neutral', inplace=True)
        confidence_score.fillna(50, inplace=True)
        
        # Generate signals based on technical indicators
        for i in range(len(data)):
            if i < 2:  # Skip the first few rows due to NaN values in indicators
                continue
                
            # Initialize score components
            trend_score = 0
            momentum_score = 0
            volume_score = 0
            pattern_score = 0
            
            # Trend analysis
            if 'trend_direction' in data.columns:
                if data['trend_direction'].iloc[i] == 'Bullish':
                    trend_score = 20
                elif data['trend_direction'].iloc[i] == 'Bearish':
                    trend_score = -20
            
            # SMA analysis
            if 'sma_14' in data.columns and 'sma_40' in data.columns:
                if data['sma_14'].iloc[i] > data['sma_40'].iloc[i]:
                    trend_score += 10
                elif data['sma_14'].iloc[i] < data['sma_40'].iloc[i]:
                    trend_score -= 10
            
            # RSI analysis
            if 'rsi' in data.columns:
                rsi = data['rsi'].iloc[i]
                if not pd.isna(rsi):
                    if rsi > self.rsi_overbought:
                        momentum_score -= 15  # Overbought
                    elif rsi < self.rsi_oversold:
                        momentum_score += 15  # Oversold
                    elif rsi > 50 and rsi < self.rsi_overbought:
                        momentum_score += 10  # Bullish momentum
                    elif rsi < 50 and rsi > self.rsi_oversold:
                        momentum_score -= 10  # Bearish momentum
            
            # MACD analysis
            if 'macd' in data.columns and 'macd_signal' in data.columns:
                macd = data['macd'].iloc[i]
                macd_signal = data['macd_signal'].iloc[i]
                if not pd.isna(macd) and not pd.isna(macd_signal):
                    if macd > macd_signal and macd > 0:
                        momentum_score += 15  # Strong bullish momentum
                    elif macd > macd_signal and macd < 0:
                        momentum_score += 10  # Bullish momentum but still negative
                    elif macd < macd_signal and macd < 0:
                        momentum_score -= 15  # Strong bearish momentum
                    elif macd < macd_signal and macd > 0:
                        momentum_score -= 10  # Bearish momentum but still positive
            
            # Bollinger Bands analysis
            if 'bollinger_upper' in data.columns and 'bollinger_lower' in data.columns:
                upper = data['bollinger_upper'].iloc[i]
                lower = data['bollinger_lower'].iloc[i]
                close = data['close'].iloc[i]
                if not pd.isna(upper) and not pd.isna(lower):
                    if close > upper:
                        momentum_score -= 10  # Overbought
                    elif close < lower:
                        momentum_score += 10  # Oversold
            
            # Volume analysis
            if 'volume_analysis' in data.columns:
                volume_analysis = data['volume_analysis'].iloc[i]
                if volume_analysis == 'Strong Bullish':
                    volume_score = 15
                elif volume_analysis == 'Bullish':
                    volume_score = 10
                elif volume_analysis == 'Weak Bullish':
                    volume_score = 5
                elif volume_analysis == 'Strong Bearish':
                    volume_score = -15
                elif volume_analysis == 'Bearish':
                    volume_score = -10
                elif volume_analysis == 'Weak Bearish':
                    volume_score = -5
            
            # Pattern analysis
            if 'pattern_signals' in data.columns:
                patterns = data['pattern_signals'].iloc[i]
                if isinstance(patterns, list) and patterns:
                    for pattern in patterns:
                        if 'Bullish' in pattern:
                            pattern_score += 5
                        elif 'Bearish' in pattern:
                            pattern_score -= 5
            
            # Calculate total score
            total_score = trend_score + momentum_score + volume_score + pattern_score
            
            # Normalize to 0-100 range
            normalized_score = min(max((total_score + 50), 0), 100)
            
            # Assign confidence score
            confidence_score.iloc[i] = normalized_score
            
            # Determine signal type based on total score
            if normalized_score >= 80:
                signal_type.iloc[i] = 'Strong Bullish'
            elif normalized_score >= 60:
                signal_type.iloc[i] = 'Bullish'
            elif normalized_score >= 55:
                signal_type.iloc[i] = 'Moderately Bullish'
            elif normalized_score <= 20:
                signal_type.iloc[i] = 'Strong Bearish'
            elif normalized_score <= 40:
                signal_type.iloc[i] = 'Bearish'
            elif normalized_score <= 45:
                signal_type.iloc[i] = 'Moderately Bearish'
            else:
                signal_type.iloc[i] = 'Neutral'
        
        return {
            'signal_type': signal_type,
            'confidence_score': confidence_score
        }
