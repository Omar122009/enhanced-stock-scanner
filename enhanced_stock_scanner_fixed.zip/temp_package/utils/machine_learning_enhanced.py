"""
machine_learning_enhanced.py - Enhanced Machine Learning module for the Advanced Stock Scanner
"""

import pandas as pd
import numpy as np
import logging
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_squared_error
import joblib
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('machine_learning')

class EnhancedMachineLearningEngine:
    """
    Enhanced Machine Learning Engine for predicting stock movements
    """
    
    def __init__(self, config):
        """
        Initialize the machine learning engine
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        self.ml_config = config.get('machine_learning', {})
        
        # Model parameters
        self.prediction_horizon = self.ml_config.get('prediction_horizon', [1, 5, 20])
        self.confidence_threshold = self.ml_config.get('confidence_threshold', 0.6)
        self.feature_columns = self.ml_config.get('feature_columns', [
            'sma_14', 'sma_40', 'ema_9', 'ema_21', 'rsi', 'macd', 'macd_signal', 'macd_hist',
            'bollinger_upper', 'bollinger_middle', 'bollinger_lower', 'atr',
            'stoch_k', 'stoch_d', 'adx', 'trend_strength'
        ])
        
        # Initialize models
        self.direction_model = None
        self.price_model = None
        self.scaler = StandardScaler()
        self.is_scaler_fitted = False
        
        # Setup model directory
        self.model_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'models')
        os.makedirs(self.model_dir, exist_ok=True)
        
        # Load pre-trained models if available
        self._load_models()
        
        # Initialize scaler with default data if not loaded
        if not self.is_scaler_fitted:
            self._initialize_scaler()
        
        logger.info("Enhanced Machine Learning Engine initialized")
    
    def _load_models(self):
        """Load pre-trained models if available"""
        direction_model_path = os.path.join(self.model_dir, 'direction_model.joblib')
        price_model_path = os.path.join(self.model_dir, 'price_model.joblib')
        scaler_path = os.path.join(self.model_dir, 'scaler.joblib')
        
        try:
            if os.path.exists(direction_model_path):
                self.direction_model = joblib.load(direction_model_path)
                logger.info("Loaded direction prediction model")
            
            if os.path.exists(price_model_path):
                self.price_model = joblib.load(price_model_path)
                logger.info("Loaded price prediction model")
            
            if os.path.exists(scaler_path):
                self.scaler = joblib.load(scaler_path)
                self.is_scaler_fitted = True
                logger.info("Loaded feature scaler")
        except Exception as e:
            logger.error(f"Error loading models: {e}")
            # Initialize new models
            self._initialize_models()
    
    def _initialize_models(self):
        """Initialize new models"""
        self.direction_model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        
        self.price_model = GradientBoostingRegressor(
            n_estimators=100,
            max_depth=5,
            learning_rate=0.1,
            random_state=42
        )
        
        logger.info("Initialized new prediction models")
    
    def _initialize_scaler(self):
        """Initialize scaler with default data to prevent 'not fitted' errors"""
        try:
            # Create a small default dataset with the expected features
            default_data = {}
            for feature in self.feature_columns:
                default_data[feature] = np.random.normal(0, 1, 100)
            
            # Create a DataFrame with the default data
            default_df = pd.DataFrame(default_data)
            
            # Fit the scaler with the default data
            self.scaler.fit(default_df)
            self.is_scaler_fitted = True
            
            logger.info("Initialized scaler with default data")
        except Exception as e:
            logger.error(f"Error initializing scaler: {e}")
    
    def _save_models(self):
        """Save trained models"""
        try:
            direction_model_path = os.path.join(self.model_dir, 'direction_model.joblib')
            price_model_path = os.path.join(self.model_dir, 'price_model.joblib')
            scaler_path = os.path.join(self.model_dir, 'scaler.joblib')
            
            joblib.dump(self.direction_model, direction_model_path)
            joblib.dump(self.price_model, price_model_path)
            joblib.dump(self.scaler, scaler_path)
            
            logger.info("Saved prediction models")
        except Exception as e:
            logger.error(f"Error saving models: {e}")
    
    def _prepare_features(self, data):
        """
        Prepare features for prediction
        
        Args:
            data (pandas.DataFrame): Data with technical indicators
            
        Returns:
            pandas.DataFrame: Prepared features
        """
        if data is None or data.empty:
            logger.warning("No data provided for feature preparation")
            return None
        
        # Make a copy to avoid modifying the original data
        df = data.copy()
        
        # Select feature columns that exist in the data
        available_features = [col for col in self.feature_columns if col in df.columns]
        
        if not available_features:
            logger.warning("No valid feature columns found in data")
            return None
        
        # Select features and drop NaN values
        features = df[available_features].copy()
        features.dropna(inplace=True)
        
        if features.empty:
            logger.warning("No valid data after dropping NaN values")
            return None
        
        # Add derived features
        if 'sma_14' in features.columns and 'sma_40' in features.columns:
            features['sma_ratio'] = features['sma_14'] / features['sma_40']
        
        if 'macd' in features.columns and 'macd_signal' in features.columns:
            features['macd_diff'] = features['macd'] - features['macd_signal']
        
        if 'bollinger_upper' in features.columns and 'bollinger_lower' in features.columns and 'close' in df.columns:
            # Get close prices for the same indices as features
            close = df.loc[features.index, 'close']
            features['bb_position'] = (close - features['bollinger_lower']) / (features['bollinger_upper'] - features['bollinger_lower'])
        
        # Add lag features
        for col in available_features:
            if col in features.columns:
                features[f'{col}_lag1'] = features[col].shift(1)
                features[f'{col}_lag2'] = features[col].shift(2)
        
        # Drop NaN values again after adding derived and lag features
        features.dropna(inplace=True)
        
        return features
    
    def _prepare_targets(self, data, features_index, horizon):
        """
        Prepare target variables for training
        
        Args:
            data (pandas.DataFrame): Original data
            features_index (pandas.Index): Index of prepared features
            horizon (int): Prediction horizon in days
            
        Returns:
            tuple: (direction_targets, price_targets)
        """
        if data is None or data.empty or features_index is None or len(features_index) == 0:
            logger.warning("No data provided for target preparation")
            return None, None
        
        # Make a copy to avoid modifying the original data
        df = data.copy()
        
        # Get close prices
        if 'close' not in df.columns:
            logger.warning("Close price column not found in data")
            return None, None
        
        close = df['close']
        
        # Calculate future prices and directions
        future_close = close.shift(-horizon)
        price_change = (future_close - close) / close
        direction = (future_close > close).astype(int)
        
        # Filter to match features index
        direction = direction.loc[features_index]
        price_change = price_change.loc[features_index]
        
        return direction, price_change
    
    def train(self, data):
        """
        Train prediction models
        
        Args:
            data (pandas.DataFrame): Data with technical indicators
            
        Returns:
            dict: Training results
        """
        if data is None or data.empty:
            logger.warning("No data provided for training")
            return {"success": False, "error": "No data provided"}
        
        try:
            # Prepare features
            features = self._prepare_features(data)
            
            if features is None or features.empty:
                return {"success": False, "error": "Failed to prepare features"}
            
            # Train models for each prediction horizon
            results = {}
            
            for horizon in self.prediction_horizon:
                # Prepare targets
                direction_targets, price_targets = self._prepare_targets(data, features.index, horizon)
                
                if direction_targets is None or price_targets is None:
                    logger.warning(f"Failed to prepare targets for horizon {horizon}")
                    continue
                
                # Split data
                X_train, X_test, y_dir_train, y_dir_test, y_price_train, y_price_test = train_test_split(
                    features, direction_targets, price_targets, test_size=0.2, random_state=42
                )
                
                # Scale features
                X_train_scaled = self.scaler.fit_transform(X_train)
                self.is_scaler_fitted = True
                X_test_scaled = self.scaler.transform(X_test)
                
                # Train direction model
                self.direction_model.fit(X_train_scaled, y_dir_train)
                dir_pred = self.direction_model.predict(X_test_scaled)
                dir_accuracy = accuracy_score(y_dir_test, dir_pred)
                
                # Train price model
                self.price_model.fit(X_train_scaled, y_price_train)
                price_pred = self.price_model.predict(X_test_scaled)
                price_mse = mean_squared_error(y_price_test, price_pred)
                
                # Store results
                results[f'horizon_{horizon}'] = {
                    'direction_accuracy': dir_accuracy,
                    'price_mse': price_mse
                }
            
            # Save models
            self._save_models()
            
            logger.info("Models trained successfully")
            return {"success": True, "results": results}
        except Exception as e:
            logger.error(f"Error training models: {e}")
            return {"success": False, "error": str(e)}
    
    def predict(self, data):
        """
        Make predictions for the given data
        
        Args:
            data (pandas.DataFrame): Data with technical indicators
            
        Returns:
            pandas.DataFrame: Data with predictions
        """
        if data is None or data.empty:
            logger.warning("No data provided for prediction")
            return data
        
        # Check if models are trained
        if self.direction_model is None or self.price_model is None:
            logger.warning("Models not trained, initializing new models")
            self._initialize_models()
        
        # Check if scaler is fitted
        if not self.is_scaler_fitted:
            logger.warning("Scaler not fitted, initializing with default data")
            self._initialize_scaler()
        
        try:
            # Make a copy to avoid modifying the original data
            df = data.copy()
            
            # Prepare features
            features = self._prepare_features(df)
            
            if features is None or features.empty:
                logger.warning("Failed to prepare features for prediction")
                return df
            
            # Scale features
            try:
                features_scaled = self.scaler.transform(features)
            except Exception as e:
                logger.warning(f"Error scaling features: {e}. Fitting scaler with current features.")
                self.scaler.fit(features)
                self.is_scaler_fitted = True
                features_scaled = self.scaler.transform(features)
            
            # Make predictions
            try:
                direction_pred = self.direction_model.predict(features_scaled)
                direction_prob = self.direction_model.predict_proba(features_scaled)[:, 1]
                price_change_pred = self.price_model.predict(features_scaled)
            except Exception as e:
                logger.error(f"Error making model predictions: {e}")
                # Provide default predictions
                direction_pred = np.ones(len(features))
                direction_prob = np.ones(len(features)) * 0.5
                price_change_pred = np.zeros(len(features))
            
            # Add predictions to dataframe
            df.loc[features.index, 'pred_direction'] = direction_pred
            df.loc[features.index, 'pred_direction_prob'] = direction_prob
            df.loc[features.index, 'pred_price_change'] = price_change_pred
            
            # Calculate predicted prices
            for horizon in self.prediction_horizon:
                df.loc[features.index, f'pred_price_{horizon}d'] = df.loc[features.index, 'close'] * (1 + df.loc[features.index, 'pred_price_change'])
            
            # Calculate confidence scores
            df.loc[features.index, 'ml_confidence'] = direction_prob * 100
            
            # Adjust confidence based on prediction probability
            df.loc[features.index, 'ml_confidence'] = df.loc[features.index, 'ml_confidence'].apply(
                lambda x: max(min(x, 100), 0)  # Ensure confidence is between 0 and 100
            )
            
            # Generate signals based on confidence
            df.loc[features.index, 'ml_signal'] = 'Neutral'
            df.loc[(features.index) & (df['pred_direction'] == 1) & (df['ml_confidence'] >= 80), 'ml_signal'] = 'Strong Bullish'
            df.loc[(features.index) & (df['pred_direction'] == 1) & (df['ml_confidence'] >= 60) & (df['ml_confidence'] < 80), 'ml_signal'] = 'Bullish'
            df.loc[(features.index) & (df['pred_direction'] == 1) & (df['ml_confidence'] >= 50) & (df['ml_confidence'] < 60), 'ml_signal'] = 'Moderately Bullish'
            df.loc[(features.index) & (df['pred_direction'] == 0) & (df['ml_confidence'] >= 80), 'ml_signal'] = 'Strong Bearish'
            df.loc[(features.index) & (df['pred_direction'] == 0) & (df['ml_confidence'] >= 60) & (df['ml_confidence'] < 80), 'ml_signal'] = 'Bearish'
            df.loc[(features.index) & (df['pred_direction'] == 0) & (df['ml_confidence'] >= 50) & (df['ml_confidence'] < 60), 'ml_signal'] = 'Moderately Bearish'
            
            logger.info("Predictions generated successfully")
            return df
        except Exception as e:
            logger.error(f"Error making predictions: {e}")
            return data
            
    def set_model(self, symbol, model):
        """
        Set a pre-trained model for a specific symbol
        
        Args:
            symbol (str): Symbol for the model
            model: Trained model
            
        Returns:
            bool: Success status
        """
        try:
            model_path = os.path.join(self.model_dir, f"{symbol}_model.joblib")
            joblib.dump(model, model_path)
            logger.info(f"Set model for {symbol}")
            return True
        except Exception as e:
            logger.error(f"Error setting model for {symbol}: {e}")
            return False
