import json
import os
import hashlib

class UserManagement:
    def __init__(self):
        self.users_file = "data/users.json"
        self._ensure_users_file_exists()
        
    def _ensure_users_file_exists(self):
        """Ensure the users file exists and has at least one admin user."""
        os.makedirs(os.path.dirname(self.users_file), exist_ok=True)
        
        if not os.path.exists(self.users_file):
            # Create default admin user
            default_users = {
                "admin": {
                    "password_hash": self._hash_password("admin"),
                    "is_admin": True,
                    "watchlist": []
                }
            }
            
            with open(self.users_file, 'w') as f:
                json.dump(default_users, f, indent=4)
    
    def get_users(self):
        """Get all users."""
        with open(self.users_file, 'r') as f:
            return json.load(f)
    
    def create_user(self, username, password, is_admin=False):
        """Create a new user."""
        users = self.get_users()
        
        if username in users:
            raise ValueError(f"User {username} already exists")
        
        users[username] = {
            "password_hash": self._hash_password(password),
            "is_admin": is_admin,
            "watchlist": []
        }
        
        with open(self.users_file, 'w') as f:
            json.dump(users, f, indent=4)
    
    def update_password(self, username, new_password):
        """Update a user's password."""
        users = self.get_users()
        
        if username not in users:
            raise ValueError(f"User {username} does not exist")
        
        users[username]["password_hash"] = self._hash_password(new_password)
        
        with open(self.users_file, 'w') as f:
            json.dump(users, f, indent=4)
    
    def delete_user(self, username):
        """Delete a user."""
        users = self.get_users()
        
        if username not in users:
            raise ValueError(f"User {username} does not exist")
        
        del users[username]
        
        with open(self.users_file, 'w') as f:
            json.dump(users, f, indent=4)
    
    def verify_user(self, username, password):
        """Verify a user's credentials."""
        users = self.get_users()
        
        if username not in users:
            return False
        
        stored_hash = users[username]["password_hash"]
        return self._verify_password(password, stored_hash)
    
    def is_admin(self, username):
        """Check if a user is an admin."""
        users = self.get_users()
        
        if username not in users:
            return False
        
        return users[username]["is_admin"]
    
    def get_watchlist(self, username):
        """Get a user's watchlist."""
        users = self.get_users()
        
        if username not in users:
            return []
        
        return users[username].get("watchlist", [])
    
    def add_to_watchlist(self, username, symbol):
        """Add a symbol to a user's watchlist."""
        users = self.get_users()
        
        if username not in users:
            raise ValueError(f"User {username} does not exist")
        
        if "watchlist" not in users[username]:
            users[username]["watchlist"] = []
        
        if symbol not in users[username]["watchlist"]:
            users[username]["watchlist"].append(symbol)
        
        with open(self.users_file, 'w') as f:
            json.dump(users, f, indent=4)
    
    def remove_from_watchlist(self, username, symbol):
        """Remove a symbol from a user's watchlist."""
        users = self.get_users()
        
        if username not in users:
            raise ValueError(f"User {username} does not exist")
        
        if "watchlist" in users[username] and symbol in users[username]["watchlist"]:
            users[username]["watchlist"].remove(symbol)
        
        with open(self.users_file, 'w') as f:
            json.dump(users, f, indent=4)
    
    def _hash_password(self, password):
        """Hash a password."""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def _verify_password(self, password, stored_hash):
        """Verify a password against a stored hash."""
        return self._hash_password(password) == stored_hash
