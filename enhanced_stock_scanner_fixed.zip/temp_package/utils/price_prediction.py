"""
price_prediction.py - Price Prediction module for the Advanced Stock Scanner
"""

import pandas as pd
import numpy as np
import logging
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('price_prediction')

class PricePrediction:
    """
    Price Prediction class for forecasting future price movements
    """
    
    def __init__(self, config):
        """
        Initialize the price prediction module
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        self.scaler = StandardScaler()
        logger.info("Price Prediction module initialized")
    
    def predict_prices(self, data):
        """
        Predict future prices for the given data
        
        Args:
            data (pandas.DataFrame): OHLCV data with technical indicators
            
        Returns:
            pandas.DataFrame: Data with price predictions
        """
        if data is None or data.empty or len(data) < 20:
            logger.warning("Insufficient data for price prediction")
            return data
        
        # Make a copy to avoid modifying the original data
        df = data.copy()
        
        try:
            # Calculate price targets for different timeframes
            df['price_target_1d'] = self._predict_next_day_price(df)
            df['price_target_1w'] = self._predict_next_week_price(df)
            df['price_target_1m'] = self._predict_next_month_price(df)
            
            # Calculate expected price movement percentage
            df['expected_movement_1d_pct'] = (df['price_target_1d'] / df['close'] - 1) * 100
            df['expected_movement_1w_pct'] = (df['price_target_1w'] / df['close'] - 1) * 100
            df['expected_movement_1m_pct'] = (df['price_target_1m'] / df['close'] - 1) * 100
            
            # Calculate price prediction confidence
            df['prediction_confidence'] = self._calculate_prediction_confidence(df)
            
            logger.info("Price predictions calculated successfully")
            return df
        except Exception as e:
            logger.error(f"Error calculating price predictions: {e}")
            raise RuntimeError(f"Error calculating price predictions: {e}")
    
    def _predict_next_day_price(self, data):
        """
        Predict the next day's closing price
        
        Returns:
            pandas.Series: Predicted next day closing price
        """
        predictions = pd.Series(index=data.index)
        
        try:
            # Use the last 20 days of data for prediction
            if len(data) < 20:
                return predictions
            
            # Get the latest price
            latest_price = data['close'].iloc[-1]
            
            # Simple prediction based on recent price movement
            if 'short_term_sentiment' in data.columns:
                sentiment = data['short_term_sentiment'].iloc[-1]
                
                # Calculate ATR if available for volatility adjustment
                if 'atr' in data.columns:
                    atr = data['atr'].iloc[-1]
                else:
                    # Calculate a simple volatility measure
                    atr = (data['high'] - data['low']).tail(14).mean()
                
                # Adjust prediction based on sentiment
                if sentiment == 'Very Bullish':
                    predictions.iloc[-1] = latest_price * (1 + 0.8 * (atr / latest_price))
                elif sentiment == 'Bullish':
                    predictions.iloc[-1] = latest_price * (1 + 0.4 * (atr / latest_price))
                elif sentiment == 'Neutral':
                    predictions.iloc[-1] = latest_price
                elif sentiment == 'Bearish':
                    predictions.iloc[-1] = latest_price * (1 - 0.4 * (atr / latest_price))
                elif sentiment == 'Very Bearish':
                    predictions.iloc[-1] = latest_price * (1 - 0.8 * (atr / latest_price))
                else:
                    predictions.iloc[-1] = latest_price
            else:
                # Use linear regression model if sentiment is not available
                predictions.iloc[-1] = self._linear_regression_prediction(data, 1)
        except Exception as e:
            logger.error(f"Error predicting next day price: {e}")
            # Fallback to current price
            predictions.iloc[-1] = data['close'].iloc[-1]
        
        return predictions
    
    def _predict_next_week_price(self, data):
        """
        Predict the price one week ahead
        
        Returns:
            pandas.Series: Predicted one week ahead closing price
        """
        predictions = pd.Series(index=data.index)
        
        try:
            # Use the last 60 days of data for prediction
            if len(data) < 60:
                return predictions
            
            # Get the latest price
            latest_price = data['close'].iloc[-1]
            
            # Simple prediction based on medium-term sentiment
            if 'medium_term_sentiment' in data.columns:
                sentiment = data['medium_term_sentiment'].iloc[-1]
                
                # Calculate weekly volatility
                weekly_volatility = data['close'].pct_change(5).std() * np.sqrt(5)
                
                # Adjust prediction based on sentiment
                if sentiment == 'Very Bullish':
                    predictions.iloc[-1] = latest_price * (1 + 2.0 * weekly_volatility)
                elif sentiment == 'Bullish':
                    predictions.iloc[-1] = latest_price * (1 + 1.0 * weekly_volatility)
                elif sentiment == 'Neutral':
                    predictions.iloc[-1] = latest_price
                elif sentiment == 'Bearish':
                    predictions.iloc[-1] = latest_price * (1 - 1.0 * weekly_volatility)
                elif sentiment == 'Very Bearish':
                    predictions.iloc[-1] = latest_price * (1 - 2.0 * weekly_volatility)
                else:
                    predictions.iloc[-1] = latest_price
            else:
                # Use linear regression model if sentiment is not available
                predictions.iloc[-1] = self._linear_regression_prediction(data, 5)
        except Exception as e:
            logger.error(f"Error predicting next week price: {e}")
            # Fallback to current price
            predictions.iloc[-1] = data['close'].iloc[-1]
        
        return predictions
    
    def _predict_next_month_price(self, data):
        """
        Predict the price one month ahead
        
        Returns:
            pandas.Series: Predicted one month ahead closing price
        """
        predictions = pd.Series(index=data.index)
        
        try:
            # Use the last 120 days of data for prediction
            if len(data) < 120:
                return predictions
            
            # Get the latest price
            latest_price = data['close'].iloc[-1]
            
            # Simple prediction based on long-term sentiment
            if 'long_term_sentiment' in data.columns:
                sentiment = data['long_term_sentiment'].iloc[-1]
                
                # Calculate monthly volatility
                monthly_volatility = data['close'].pct_change(20).std() * np.sqrt(20)
                
                # Adjust prediction based on sentiment
                if sentiment == 'Very Bullish':
                    predictions.iloc[-1] = latest_price * (1 + 3.0 * monthly_volatility)
                elif sentiment == 'Bullish':
                    predictions.iloc[-1] = latest_price * (1 + 1.5 * monthly_volatility)
                elif sentiment == 'Neutral':
                    predictions.iloc[-1] = latest_price
                elif sentiment == 'Bearish':
                    predictions.iloc[-1] = latest_price * (1 - 1.5 * monthly_volatility)
                elif sentiment == 'Very Bearish':
                    predictions.iloc[-1] = latest_price * (1 - 3.0 * monthly_volatility)
                else:
                    predictions.iloc[-1] = latest_price
            else:
                # Use linear regression model if sentiment is not available
                predictions.iloc[-1] = self._linear_regression_prediction(data, 20)
        except Exception as e:
            logger.error(f"Error predicting next month price: {e}")
            # Fallback to current price
            predictions.iloc[-1] = data['close'].iloc[-1]
        
        return predictions
    
    def _linear_regression_prediction(self, data, days_ahead):
        """
        Use linear regression to predict future price
        
        Args:
            data (pandas.DataFrame): Historical price data
            days_ahead (int): Number of days to predict ahead
            
        Returns:
            float: Predicted price
        """
        try:
            # Prepare features
            df = data.copy().tail(60)  # Use last 60 days
            
            # Create features from price and volume data
            features = []
            
            # Add basic price features
            features.append(df['close'].values)
            features.append(df['high'].values)
            features.append(df['low'].values)
            features.append(df['volume'].values)
            
            # Add technical indicators if available
            if 'rsi' in df.columns:
                features.append(df['rsi'].values)
            
            if 'macd' in df.columns:
                features.append(df['macd'].values)
            
            if 'bollinger_upper' in df.columns and 'bollinger_lower' in df.columns:
                features.append(df['bollinger_upper'].values)
                features.append(df['bollinger_lower'].values)
            
            # Transpose to get features as columns
            X = np.array(features).T
            
            # Handle NaN values
            X = np.nan_to_num(X)
            
            # Target is the closing price
            y = df['close'].values
            
            # Scale features
            X_scaled = self.scaler.fit_transform(X)
            
            # Train linear regression model
            model = LinearRegression()
            model.fit(X_scaled[:-days_ahead], y[days_ahead:])
            
            # Predict future price
            future_X = X_scaled[-1:].reshape(1, -1)
            prediction = model.predict(future_X)[0]
            
            return prediction
        except Exception as e:
            logger.error(f"Error in linear regression prediction: {e}")
            # Fallback to current price
            return data['close'].iloc[-1]
    
    def _calculate_prediction_confidence(self, data):
        """
        Calculate confidence level for price predictions
        
        Returns:
            pandas.Series: Prediction confidence (0-100)
        """
        confidence = pd.Series(index=data.index)
        
        try:
            # Base confidence on data quality and volatility
            # Start with a base confidence
            base_confidence = 60
            
            # Adjust based on data length
            if len(data) < 30:
                data_length_factor = 0.7
            elif len(data) < 60:
                data_length_factor = 0.8
            elif len(data) < 90:
                data_length_factor = 0.9
            else:
                data_length_factor = 1.0
            
            # Adjust based on volatility
            volatility = data['close'].pct_change().std() * 100
            if volatility > 5:
                volatility_factor = 0.7
            elif volatility > 3:
                volatility_factor = 0.8
            elif volatility > 1:
                volatility_factor = 0.9
            else:
                volatility_factor = 1.0
            
            # Adjust based on sentiment evidence if available
            if 'short_term_evidence' in data.columns:
                evidence = data['short_term_evidence'].iloc[-1]
                if evidence == 'Very Strong Evidence':
                    evidence_factor = 1.2
                elif evidence == 'Strong Evidence':
                    evidence_factor = 1.1
                elif evidence == 'Moderate Evidence':
                    evidence_factor = 1.0
                else:
                    evidence_factor = 0.9
            else:
                evidence_factor = 1.0
            
            # Calculate final confidence
            final_confidence = base_confidence * data_length_factor * volatility_factor * evidence_factor
            
            # Clip to 0-100 range
            confidence.iloc[-1] = min(max(final_confidence, 0), 100)
        except Exception as e:
            logger.error(f"Error calculating prediction confidence: {e}")
            # Default confidence
            confidence.iloc[-1] = 50
        
        return confidence
