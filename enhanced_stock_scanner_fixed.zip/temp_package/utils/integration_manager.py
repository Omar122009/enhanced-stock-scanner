"""
integration_manager.py - Integration Manager for the Advanced Stock Scanner
"""

import logging
import time
import traceback
from datetime import datetime
import os
import json
import pandas as pd
import numpy as np

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('integration_manager')

class IntegrationManager:
    """
    Integration Manager class to handle component integration and error handling
    """
    
    def __init__(self, config, data_acquisition, technical_analysis, machine_learning, scanner):
        """
        Initialize the integration manager
        
        Args:
            config (dict): Configuration dictionary
            data_acquisition: Data acquisition instance
            technical_analysis: Technical analysis instance
            machine_learning: Machine learning instance
            scanner: Scanner instance
        """
        self.config = config
        self.data_acquisition = data_acquisition
        self.technical_analysis = technical_analysis
        self.machine_learning = machine_learning
        self.scanner = scanner
        
        # Integration settings
        self.max_retries = config.get('integration', {}).get('max_retries', 3)
        self.retry_delay = config.get('integration', {}).get('retry_delay_seconds', 2)
        
        # Create logs directory
        self.logs_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
        os.makedirs(self.logs_dir, exist_ok=True)
        
        # Setup file handler for logging
        file_handler = logging.FileHandler(os.path.join(self.logs_dir, 'integration.log'))
        file_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        logger.addHandler(file_handler)
        
        logger.info("Integration Manager initialized")
    
    def run_scan_with_retry(self, symbols, timeframes, start_date=None, end_date=None):
        """
        Run scan with retry logic
        
        Args:
            symbols (list): List of symbols to scan
            timeframes (list): List of timeframes to scan
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            
        Returns:
            pandas.DataFrame: Scan results
        """
        for attempt in range(self.max_retries):
            try:
                logger.info(f"Running scan attempt {attempt + 1}/{self.max_retries}")
                
                # Run scan
                results = self.scanner.scan(symbols, timeframes, start_date, end_date)
                
                # Log success
                logger.info(f"Scan completed successfully with {len(results)} results")
                
                return results
            except Exception as e:
                logger.error(f"Error during scan attempt {attempt + 1}/{self.max_retries}: {e}")
                logger.error(traceback.format_exc())
                
                # If this is the last attempt, raise the exception
                if attempt == self.max_retries - 1:
                    raise
                
                # Wait before retrying
                time.sleep(self.retry_delay)
                
                # Try to recover components if needed
                self._recover_components()
    
    def get_detailed_analysis_with_retry(self, symbol, timeframes, start_date=None, end_date=None):
        """
        Get detailed analysis with retry logic
        
        Args:
            symbol (str): Symbol to analyze
            timeframes (list): List of timeframes to analyze
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            
        Returns:
            dict: Detailed analysis
        """
        for attempt in range(self.max_retries):
            try:
                logger.info(f"Getting detailed analysis for {symbol}, attempt {attempt + 1}/{self.max_retries}")
                
                # Get detailed analysis
                analysis = self.scanner.get_detailed_analysis(symbol, timeframes, start_date, end_date)
                
                # Log success
                logger.info(f"Detailed analysis for {symbol} completed successfully")
                
                return analysis
            except Exception as e:
                logger.error(f"Error during detailed analysis for {symbol}, attempt {attempt + 1}/{self.max_retries}: {e}")
                logger.error(traceback.format_exc())
                
                # If this is the last attempt, raise the exception
                if attempt == self.max_retries - 1:
                    raise
                
                # Wait before retrying
                time.sleep(self.retry_delay)
                
                # Try to recover components if needed
                self._recover_components()
    
    def _recover_components(self):
        """
        Attempt to recover components after an error
        """
        logger.info("Attempting to recover components")
        
        try:
            # Check data acquisition health
            data_sources_health = self.data_acquisition.get_source_health()
            
            # Log health status
            for source, status in data_sources_health.items():
                logger.info(f"Data source {source} status: {status['status']}")
            
            # If all sources are unavailable, try to reinitialize data acquisition
            if all(status['status'] == 'unavailable' for status in data_sources_health.values()):
                logger.warning("All data sources are unavailable, attempting to reinitialize data acquisition")
                self.data_acquisition._init_data_sources()
        except Exception as e:
            logger.error(f"Error recovering components: {e}")
    
    def get_data_with_fallback(self, symbols, timeframe, period=None, start_date=None, end_date=None):
        """
        Get data with fallback logic
        
        Args:
            symbols (list): List of symbols to fetch data for
            timeframe (str): Timeframe to fetch data for
            period (str, optional): Period to fetch data for
            start_date (str, optional): Start date in YYYY-MM-DD format
            end_date (str, optional): End date in YYYY-MM-DD format
            
        Returns:
            dict: Dictionary of DataFrames with symbol as key
        """
        try:
            logger.info(f"Getting data for {len(symbols)} symbols with timeframe {timeframe}")
            
            # Try to get data with date range if provided
            if start_date and end_date:
                data = self.data_acquisition.get_multi_symbol_data(symbols, timeframe, start_date, end_date)
            else:
                # Otherwise use period
                data = self.data_acquisition.get_historical_data(symbols, timeframe, period)
            
            # Check if we got data for all symbols
            if data and len(data) == len(symbols):
                logger.info(f"Got data for all {len(symbols)} symbols")
                return data
            
            # If we're missing data for some symbols, log and continue with what we have
            missing_symbols = [s for s in symbols if s not in data]
            if missing_symbols:
                logger.warning(f"Missing data for {len(missing_symbols)} symbols: {missing_symbols}")
            
            return data
        except Exception as e:
            logger.error(f"Error getting data: {e}")
            logger.error(traceback.format_exc())
            
            # Try to recover and retry once
            self._recover_components()
            
            try:
                # Retry with the same parameters
                if start_date and end_date:
                    return self.data_acquisition.get_multi_symbol_data(symbols, timeframe, start_date, end_date)
                else:
                    return self.data_acquisition.get_historical_data(symbols, timeframe, period)
            except Exception as retry_e:
                logger.error(f"Error getting data after retry: {retry_e}")
                raise
    
    def calculate_indicators_safely(self, data):
        """
        Calculate technical indicators with error handling
        
        Args:
            data (pandas.DataFrame): Data to calculate indicators for
            
        Returns:
            pandas.DataFrame: Data with indicators
        """
        try:
            logger.info("Calculating technical indicators")
            return self.technical_analysis.calculate_indicators(data)
        except Exception as e:
            logger.error(f"Error calculating technical indicators: {e}")
            logger.error(traceback.format_exc())
            
            # Try to recover by calculating only essential indicators
            try:
                logger.info("Attempting to calculate essential indicators only")
                return self.technical_analysis.calculate_essential_indicators(data)
            except Exception as retry_e:
                logger.error(f"Error calculating essential indicators: {retry_e}")
                
                # Return original data if all else fails
                logger.warning("Returning original data without indicators")
                return data
    
    def predict_safely(self, data):
        """
        Run machine learning predictions with error handling
        
        Args:
            data (pandas.DataFrame): Data to run predictions on
            
        Returns:
            pandas.DataFrame: Data with predictions
        """
        try:
            logger.info("Running machine learning predictions")
            return self.machine_learning.predict(data)
        except Exception as e:
            logger.error(f"Error running machine learning predictions: {e}")
            logger.error(traceback.format_exc())
            
            # Return original data if predictions fail
            logger.warning("Returning original data without predictions")
            return data
    
    def log_integration_event(self, event_type, details):
        """
        Log integration event to file
        
        Args:
            event_type (str): Type of event
            details (dict): Event details
        """
        try:
            # Create event log
            event = {
                'timestamp': datetime.now().isoformat(),
                'type': event_type,
                'details': details
            }
            
            # Log to file
            log_file = os.path.join(self.logs_dir, 'integration_events.jsonl')
            
            with open(log_file, 'a') as f:
                f.write(json.dumps(event) + '\n')
            
            logger.info(f"Logged {event_type} event")
        except Exception as e:
            logger.error(f"Error logging integration event: {e}")
    
    def get_component_status(self):
        """
        Get status of all components
        
        Returns:
            dict: Status of all components
        """
        status = {
            'data_acquisition': {
                'status': 'unknown',
                'details': {}
            },
            'technical_analysis': {
                'status': 'unknown',
                'details': {}
            },
            'machine_learning': {
                'status': 'unknown',
                'details': {}
            },
            'scanner': {
                'status': 'unknown',
                'details': {}
            }
        }
        
        # Check data acquisition
        try:
            data_sources_health = self.data_acquisition.get_source_health()
            
            # If any source is available, data acquisition is available
            if any(s['status'] == 'available' for s in data_sources_health.values()):
                status['data_acquisition']['status'] = 'available'
            # If any source is degraded, data acquisition is degraded
            elif any(s['status'] == 'degraded' for s in data_sources_health.values()):
                status['data_acquisition']['status'] = 'degraded'
            # If all sources are unavailable, data acquisition is unavailable
            else:
                status['data_acquisition']['status'] = 'unavailable'
            
            status['data_acquisition']['details'] = data_sources_health
        except Exception as e:
            logger.error(f"Error checking data acquisition status: {e}")
            status['data_acquisition']['status'] = 'error'
            status['data_acquisition']['details'] = {'error': str(e)}
        
        # Check technical analysis (simple check)
        try:
            # Create a simple DataFrame to test
            test_data = pd.DataFrame({
                'open': [100, 101, 102, 103, 104],
                'high': [105, 106, 107, 108, 109],
                'low': [95, 96, 97, 98, 99],
                'close': [102, 103, 104, 105, 106],
                'volume': [1000, 1100, 1200, 1300, 1400]
            })
            
            # Try to calculate a simple indicator
            result = self.technical_analysis.calculate_sma(test_data, 3)
            
            if result is not None and not result.empty:
                status['technical_analysis']['status'] = 'available'
            else:
                status['technical_analysis']['status'] = 'error'
        except Exception as e:
            logger.error(f"Error checking technical analysis status: {e}")
            status['technical_analysis']['status'] = 'error'
            status['technical_analysis']['details'] = {'error': str(e)}
        
        # Check machine learning (simple check)
        try:
            # We can't easily test machine learning without proper data
            # Just check if the model is loaded
            if hasattr(self.machine_learning, 'model') and self.machine_learning.model is not None:
                status['machine_learning']['status'] = 'available'
            else:
                status['machine_learning']['status'] = 'unavailable'
        except Exception as e:
            logger.error(f"Error checking machine learning status: {e}")
            status['machine_learning']['status'] = 'error'
            status['machine_learning']['details'] = {'error': str(e)}
        
        # Check scanner (infer from other components)
        if (status['data_acquisition']['status'] in ['available', 'degraded'] and
            status['technical_analysis']['status'] == 'available'):
            status['scanner']['status'] = 'available'
        elif (status['data_acquisition']['status'] == 'unavailable' or
              status['technical_analysis']['status'] == 'error'):
            status['scanner']['status'] = 'unavailable'
        else:
            status['scanner']['status'] = 'degraded'
        
        return status
