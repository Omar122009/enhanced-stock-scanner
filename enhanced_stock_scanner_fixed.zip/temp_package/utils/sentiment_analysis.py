"""
sentiment_analysis.py - Enhanced Sentiment Analysis module for the Advanced Stock Scanner
"""

import pandas as pd
import numpy as np
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('sentiment_analysis')

class SentimentAnalysis:
    """
    Sentiment Analysis class for determining market sentiment and price targets
    """
    
    def __init__(self, config):
        """
        Initialize the sentiment analysis module
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        logger.info("Sentiment Analysis module initialized")
    
    def analyze_sentiment(self, data):
        """
        Analyze sentiment for the given data
        
        Args:
            data (pandas.DataFrame): OHLCV data with technical indicators
            
        Returns:
            pandas.DataFrame: Data with sentiment analysis
        """
        if data is None or data.empty:
            logger.warning("No data provided for sentiment analysis")
            return data
        
        # Make a copy to avoid modifying the original data
        df = data.copy()
        
        try:
            # Calculate short-term sentiment (1-5 days)
            df['short_term_sentiment'] = self._calculate_short_term_sentiment(df)
            df['short_term_evidence'] = self._calculate_short_term_evidence(df)
            
            # Calculate medium-term sentiment (1-4 weeks)
            df['medium_term_sentiment'] = self._calculate_medium_term_sentiment(df)
            df['medium_term_evidence'] = self._calculate_medium_term_evidence(df)
            
            # Calculate long-term sentiment (1-6 months)
            df['long_term_sentiment'] = self._calculate_long_term_sentiment(df)
            df['long_term_evidence'] = self._calculate_long_term_evidence(df)
            
            # Calculate buy price
            df['buy_price'] = self._calculate_buy_price(df)
            
            # Calculate sell price
            df['sell_price'] = self._calculate_sell_price(df)
            
            # Calculate stop loss
            df['stop_loss'] = self._calculate_stop_loss(df)
            
            logger.info("Sentiment analysis completed successfully")
            return df
        except Exception as e:
            logger.error(f"Error performing sentiment analysis: {e}")
            raise RuntimeError(f"Error performing sentiment analysis: {e}")
    
    def _calculate_short_term_sentiment(self, data):
        """
        Calculate short-term sentiment (1-5 days)
        
        Returns:
            pandas.Series: Short-term sentiment (Very Bullish, Bullish, Neutral, Bearish, Very Bearish)
        """
        sentiment = pd.Series(index=data.index, dtype='object')
        
        # Use RSI, MACD, and Stochastic for short-term sentiment
        if 'rsi' in data.columns and 'macd' in data.columns and 'macd_signal' in data.columns:
            # RSI conditions
            rsi_bullish = data['rsi'] > 50
            rsi_very_bullish = data['rsi'] > 70
            rsi_bearish = data['rsi'] < 50
            rsi_very_bearish = data['rsi'] < 30
            
            # MACD conditions
            macd_bullish = data['macd'] > data['macd_signal']
            macd_bearish = data['macd'] < data['macd_signal']
            
            # Stochastic conditions if available
            if 'stoch_k' in data.columns and 'stoch_d' in data.columns:
                stoch_bullish = (data['stoch_k'] > data['stoch_d']) & (data['stoch_k'] < 80)
                stoch_bearish = (data['stoch_k'] < data['stoch_d']) & (data['stoch_k'] > 20)
            else:
                stoch_bullish = pd.Series(False, index=data.index)
                stoch_bearish = pd.Series(False, index=data.index)
            
            # Very Bullish: RSI > 70, MACD bullish, Stochastic bullish
            sentiment[(rsi_very_bullish & macd_bullish)] = 'Very Bullish'
            
            # Bullish: RSI > 50, MACD bullish
            sentiment[(rsi_bullish & macd_bullish & ~rsi_very_bullish)] = 'Bullish'
            
            # Very Bearish: RSI < 30, MACD bearish, Stochastic bearish
            sentiment[(rsi_very_bearish & macd_bearish)] = 'Very Bearish'
            
            # Bearish: RSI < 50, MACD bearish
            sentiment[(rsi_bearish & macd_bearish & ~rsi_very_bearish)] = 'Bearish'
            
            # Fill remaining with Neutral
            sentiment.fillna('Neutral', inplace=True)
        else:
            # Default to Neutral if indicators are not available
            sentiment.fillna('Neutral', inplace=True)
        
        return sentiment
    
    def _calculate_short_term_evidence(self, data):
        """
        Calculate evidence strength for short-term sentiment
        
        Returns:
            pandas.Series: Evidence strength (Very Strong, Strong, Moderate, Weak)
        """
        evidence = pd.Series(index=data.index, dtype='object')
        
        # Count the number of bullish/bearish signals
        if 'rsi' in data.columns and 'macd' in data.columns and 'stoch_k' in data.columns:
            bullish_signals = 0
            bearish_signals = 0
            
            # RSI
            if data['rsi'].iloc[-1] > 70:
                bullish_signals += 2
            elif data['rsi'].iloc[-1] > 50:
                bullish_signals += 1
            elif data['rsi'].iloc[-1] < 30:
                bearish_signals += 2
            elif data['rsi'].iloc[-1] < 50:
                bearish_signals += 1
            
            # MACD
            if 'macd_signal' in data.columns:
                if data['macd'].iloc[-1] > data['macd_signal'].iloc[-1]:
                    bullish_signals += 1
                else:
                    bearish_signals += 1
            
            # Stochastic
            if 'stoch_d' in data.columns:
                if data['stoch_k'].iloc[-1] > data['stoch_d'].iloc[-1]:
                    bullish_signals += 1
                else:
                    bearish_signals += 1
            
            # Price above/below moving averages
            if 'sma_14' in data.columns and 'sma_40' in data.columns:
                if data['close'].iloc[-1] > data['sma_14'].iloc[-1]:
                    bullish_signals += 1
                else:
                    bearish_signals += 1
                
                if data['close'].iloc[-1] > data['sma_40'].iloc[-1]:
                    bullish_signals += 1
                else:
                    bearish_signals += 1
            
            # Determine evidence strength based on signal count
            total_signals = bullish_signals + bearish_signals
            
            if data['short_term_sentiment'].iloc[-1] in ['Bullish', 'Very Bullish']:
                if bullish_signals >= 5:
                    evidence.iloc[-1] = 'Very Strong Evidence'
                elif bullish_signals >= 3:
                    evidence.iloc[-1] = 'Strong Evidence'
                elif bullish_signals >= 2:
                    evidence.iloc[-1] = 'Moderate Evidence'
                else:
                    evidence.iloc[-1] = 'Weak Evidence'
            elif data['short_term_sentiment'].iloc[-1] in ['Bearish', 'Very Bearish']:
                if bearish_signals >= 5:
                    evidence.iloc[-1] = 'Very Strong Evidence'
                elif bearish_signals >= 3:
                    evidence.iloc[-1] = 'Strong Evidence'
                elif bearish_signals >= 2:
                    evidence.iloc[-1] = 'Moderate Evidence'
                else:
                    evidence.iloc[-1] = 'Weak Evidence'
            else:
                evidence.iloc[-1] = 'Moderate Evidence'
        else:
            # Default if indicators are not available
            evidence.fillna('Moderate Evidence', inplace=True)
        
        return evidence
    
    def _calculate_medium_term_sentiment(self, data):
        """
        Calculate medium-term sentiment (1-4 weeks)
        
        Returns:
            pandas.Series: Medium-term sentiment (Very Bullish, Bullish, Neutral, Bearish, Very Bearish)
        """
        sentiment = pd.Series(index=data.index, dtype='object')
        
        # Use moving averages, ADX, and price patterns for medium-term sentiment
        if 'sma_14' in data.columns and 'sma_40' in data.columns:
            # Moving average conditions
            ma_bullish = data['sma_14'] > data['sma_40']
            ma_bearish = data['sma_14'] < data['sma_40']
            
            # Price relative to moving averages
            price_above_ma = data['close'] > data['sma_40']
            price_below_ma = data['close'] < data['sma_40']
            
            # ADX conditions if available
            if 'adx' in data.columns:
                strong_trend = data['adx'] > 25
                very_strong_trend = data['adx'] > 40
            else:
                strong_trend = pd.Series(False, index=data.index)
                very_strong_trend = pd.Series(False, index=data.index)
            
            # Very Bullish: Strong uptrend with price above MAs
            sentiment[(ma_bullish & price_above_ma & very_strong_trend)] = 'Very Bullish'
            
            # Bullish: Uptrend with price above MAs
            sentiment[(ma_bullish & price_above_ma & ~very_strong_trend)] = 'Bullish'
            
            # Very Bearish: Strong downtrend with price below MAs
            sentiment[(ma_bearish & price_below_ma & very_strong_trend)] = 'Very Bearish'
            
            # Bearish: Downtrend with price below MAs
            sentiment[(ma_bearish & price_below_ma & ~very_strong_trend)] = 'Bearish'
            
            # Fill remaining with Neutral
            sentiment.fillna('Neutral', inplace=True)
        else:
            # Default to Neutral if indicators are not available
            sentiment.fillna('Neutral', inplace=True)
        
        return sentiment
    
    def _calculate_medium_term_evidence(self, data):
        """
        Calculate evidence strength for medium-term sentiment
        
        Returns:
            pandas.Series: Evidence strength (Very Strong, Strong, Moderate, Weak)
        """
        evidence = pd.Series(index=data.index, dtype='object')
        
        # Count the number of bullish/bearish signals for medium term
        if 'sma_14' in data.columns and 'sma_40' in data.columns:
            bullish_signals = 0
            bearish_signals = 0
            
            # Moving averages
            if data['sma_14'].iloc[-1] > data['sma_40'].iloc[-1]:
                bullish_signals += 2
            else:
                bearish_signals += 2
            
            # Price relative to moving averages
            if data['close'].iloc[-1] > data['sma_40'].iloc[-1]:
                bullish_signals += 1
            else:
                bearish_signals += 1
            
            # ADX
            if 'adx' in data.columns:
                if data['adx'].iloc[-1] > 25:
                    if data['medium_term_sentiment'].iloc[-1] in ['Bullish', 'Very Bullish']:
                        bullish_signals += 2
                    elif data['medium_term_sentiment'].iloc[-1] in ['Bearish', 'Very Bearish']:
                        bearish_signals += 2
            
            # Volume
            if 'volume_analysis' in data.columns:
                if data['volume_analysis'].iloc[-1] in ['Bullish', 'Strong Bullish']:
                    bullish_signals += 1
                elif data['volume_analysis'].iloc[-1] in ['Bearish', 'Strong Bearish']:
                    bearish_signals += 1
            
            # Determine evidence strength based on signal count
            if data['medium_term_sentiment'].iloc[-1] in ['Bullish', 'Very Bullish']:
                if bullish_signals >= 4:
                    evidence.iloc[-1] = 'Very Strong Evidence'
                elif bullish_signals >= 3:
                    evidence.iloc[-1] = 'Strong Evidence'
                elif bullish_signals >= 2:
                    evidence.iloc[-1] = 'Moderate Evidence'
                else:
                    evidence.iloc[-1] = 'Weak Evidence'
            elif data['medium_term_sentiment'].iloc[-1] in ['Bearish', 'Very Bearish']:
                if bearish_signals >= 4:
                    evidence.iloc[-1] = 'Very Strong Evidence'
                elif bearish_signals >= 3:
                    evidence.iloc[-1] = 'Strong Evidence'
                elif bearish_signals >= 2:
                    evidence.iloc[-1] = 'Moderate Evidence'
                else:
                    evidence.iloc[-1] = 'Weak Evidence'
            else:
                evidence.iloc[-1] = 'Moderate Evidence'
        else:
            # Default if indicators are not available
            evidence.fillna('Moderate Evidence', inplace=True)
        
        return evidence
    
    def _calculate_long_term_sentiment(self, data):
        """
        Calculate long-term sentiment (1-6 months)
        
        Returns:
            pandas.Series: Long-term sentiment (Very Bullish, Bullish, Neutral, Bearish, Very Bearish)
        """
        sentiment = pd.Series(index=data.index, dtype='object')
        
        # Use longer-term moving averages for long-term sentiment
        if 'sma_40' in data.columns:
            # Calculate 100-day SMA if not already present
            if 'sma_100' not in data.columns:
                if len(data) >= 100:
                    data['sma_100'] = data['close'].rolling(window=100).mean()
                else:
                    # Not enough data for 100-day SMA
                    sentiment.fillna('Neutral', inplace=True)
                    return sentiment
            
            # Moving average conditions
            ma_bullish = data['sma_40'] > data['sma_100']
            ma_bearish = data['sma_40'] < data['sma_100']
            
            # Price relative to moving averages
            price_above_ma = data['close'] > data['sma_100']
            price_below_ma = data['close'] < data['sma_100']
            
            # Very Bullish: Strong uptrend with price well above long MA
            sentiment[(ma_bullish & price_above_ma & (data['close'] > data['sma_100'] * 1.1))] = 'Very Bullish'
            
            # Bullish: Uptrend with price above long MA
            sentiment[(ma_bullish & price_above_ma & ~(data['close'] > data['sma_100'] * 1.1))] = 'Bullish'
            
            # Very Bearish: Strong downtrend with price well below long MA
            sentiment[(ma_bearish & price_below_ma & (data['close'] < data['sma_100'] * 0.9))] = 'Very Bearish'
            
            # Bearish: Downtrend with price below long MA
            sentiment[(ma_bearish & price_below_ma & ~(data['close'] < data['sma_100'] * 0.9))] = 'Bearish'
            
            # Fill remaining with Neutral
            sentiment.fillna('Neutral', inplace=True)
        else:
            # Default to Neutral if indicators are not available
            sentiment.fillna('Neutral', inplace=True)
        
        return sentiment
    
    def _calculate_long_term_evidence(self, data):
        """
        Calculate evidence strength for long-term sentiment
        
        Returns:
            pandas.Series: Evidence strength (Very Strong, Strong, Moderate, Weak)
        """
        evidence = pd.Series(index=data.index, dtype='object')
        
        # Count the number of bullish/bearish signals for long term
        if 'sma_40' in data.columns and 'sma_100' in data.columns:
            bullish_signals = 0
            bearish_signals = 0
            
            # Moving averages
            if data['sma_40'].iloc[-1] > data['sma_100'].iloc[-1]:
                bullish_signals += 2
            else:
                bearish_signals += 2
            
            # Price relative to moving averages
            if data['close'].iloc[-1] > data['sma_100'].iloc[-1]:
                bullish_signals += 1
            else:
                bearish_signals += 1
            
            # Price deviation from long MA
            if data['close'].iloc[-1] > data['sma_100'].iloc[-1] * 1.1:
                bullish_signals += 1
            elif data['close'].iloc[-1] < data['sma_100'].iloc[-1] * 0.9:
                bearish_signals += 1
            
            # Determine evidence strength based on signal count
            if data['long_term_sentiment'].iloc[-1] in ['Bullish', 'Very Bullish']:
                if bullish_signals >= 4:
                    evidence.iloc[-1] = 'Very Strong Evidence'
                elif bullish_signals >= 3:
                    evidence.iloc[-1] = 'Strong Evidence'
                elif bullish_signals >= 2:
                    evidence.iloc[-1] = 'Moderate Evidence'
                else:
                    evidence.iloc[-1] = 'Weak Evidence'
            elif data['long_term_sentiment'].iloc[-1] in ['Bearish', 'Very Bearish']:
                if bearish_signals >= 4:
                    evidence.iloc[-1] = 'Very Strong Evidence'
                elif bearish_signals >= 3:
                    evidence.iloc[-1] = 'Strong Evidence'
                elif bearish_signals >= 2:
                    evidence.iloc[-1] = 'Moderate Evidence'
                else:
                    evidence.iloc[-1] = 'Weak Evidence'
            else:
                evidence.iloc[-1] = 'Moderate Evidence'
        else:
            # Default if indicators are not available
            evidence.fillna('Moderate Evidence', inplace=True)
        
        return evidence
    
    def _calculate_buy_price(self, data):
        """
        Calculate recommended buy price
        
        Returns:
            pandas.Series: Recommended buy price
        """
        buy_price = pd.Series(index=data.index)
        
        # Get the latest price
        latest_price = data['close'].iloc[-1]
        
        # Calculate support levels if available
        if 'support' in data.columns:
            support = data['support'].iloc[-1]
        else:
            # Calculate a simple support level
            low_min = data['low'].tail(20).min()
            support = low_min
        
        # Calculate ATR if available for volatility adjustment
        if 'atr' in data.columns:
            atr = data['atr'].iloc[-1]
        else:
            # Calculate a simple volatility measure
            atr = (data['high'] - data['low']).tail(14).mean()
        
        # Adjust buy price based on sentiment
        if data['short_term_sentiment'].iloc[-1] in ['Very Bullish', 'Bullish']:
            # For bullish sentiment, buy at current price or slightly below
            buy_price.iloc[-1] = latest_price * 0.99
        elif data['short_term_sentiment'].iloc[-1] == 'Neutral':
            # For neutral sentiment, buy at support or slightly above
            buy_price.iloc[-1] = support + (0.5 * atr)
        else:
            # For bearish sentiment, buy at strong support
            buy_price.iloc[-1] = support - (0.5 * atr)
        
        return buy_price
    
    def _calculate_sell_price(self, data):
        """
        Calculate recommended sell price
        
        Returns:
            pandas.Series: Recommended sell price
        """
        sell_price = pd.Series(index=data.index)
        
        # Get the latest price
        latest_price = data['close'].iloc[-1]
        
        # Calculate resistance levels if available
        if 'resistance' in data.columns:
            resistance = data['resistance'].iloc[-1]
        else:
            # Calculate a simple resistance level
            high_max = data['high'].tail(20).max()
            resistance = high_max
        
        # Calculate ATR if available for volatility adjustment
        if 'atr' in data.columns:
            atr = data['atr'].iloc[-1]
        else:
            # Calculate a simple volatility measure
            atr = (data['high'] - data['low']).tail(14).mean()
        
        # Adjust sell price based on sentiment
        if data['short_term_sentiment'].iloc[-1] in ['Very Bearish', 'Bearish']:
            # For bearish sentiment, sell at current price or slightly above
            sell_price.iloc[-1] = latest_price * 1.01
        elif data['short_term_sentiment'].iloc[-1] == 'Neutral':
            # For neutral sentiment, sell at resistance or slightly below
            sell_price.iloc[-1] = resistance - (0.5 * atr)
        else:
            # For bullish sentiment, sell at strong resistance
            sell_price.iloc[-1] = resistance + (1.5 * atr)
        
        return sell_price
    
    def _calculate_stop_loss(self, data):
        """
        Calculate recommended stop loss price
        
        Returns:
            pandas.Series: Recommended stop loss price
        """
        stop_loss = pd.Series(index=data.index)
        
        # Get the latest price
        latest_price = data['close'].iloc[-1]
        
        # Calculate ATR if available for volatility adjustment
        if 'atr' in data.columns:
            atr = data['atr'].iloc[-1]
        else:
            # Calculate a simple volatility measure
            atr = (data['high'] - data['low']).tail(14).mean()
        
        # Calculate recent lows
        recent_low = data['low'].tail(10).min()
        
        # Adjust stop loss based on sentiment
        if data['short_term_sentiment'].iloc[-1] in ['Very Bullish', 'Bullish']:
            # For bullish sentiment, set stop loss below recent low
            stop_loss.iloc[-1] = min(recent_low - (0.5 * atr), latest_price * 0.95)
        elif data['short_term_sentiment'].iloc[-1] == 'Neutral':
            # For neutral sentiment, set stop loss at a moderate distance
            stop_loss.iloc[-1] = latest_price * 0.93
        else:
            # For bearish sentiment, set tighter stop loss
            stop_loss.iloc[-1] = latest_price * 0.97
        
        return stop_loss
