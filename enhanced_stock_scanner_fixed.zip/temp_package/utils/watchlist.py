"""
watchlist.py - Watchlist module for the Advanced Stock Scanner
"""

import os
import json
import logging
import pandas as pd

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('watchlist')

class WatchlistManager:
    """
    Watchlist Manager for managing user watchlists
    """
    
    def __init__(self, config):
        """
        Initialize the watchlist manager
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        
        # Setup watchlist directory
        self.watchlist_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'watchlists')
        os.makedirs(self.watchlist_dir, exist_ok=True)
        
        logger.info("Watchlist Manager initialized")
    
    def get_watchlist_file(self, username):
        """Get watchlist file path for a user"""
        return os.path.join(self.watchlist_dir, f"{username}_watchlist.json")
    
    def get_watchlist(self, username):
        """
        Get user's watchlist
        
        Args:
            username (str): Username
            
        Returns:
            list: Watchlist symbols
        """
        watchlist_file = self.get_watchlist_file(username)
        
        if os.path.exists(watchlist_file):
            try:
                with open(watchlist_file, 'r') as f:
                    watchlist_data = json.load(f)
                return watchlist_data.get('symbols', [])
            except Exception as e:
                logger.error(f"Error loading watchlist for {username}: {e}")
                return []
        else:
            return []
    
    def add_to_watchlist(self, username, symbol):
        """
        Add symbol to user's watchlist
        
        Args:
            username (str): Username
            symbol (str): Symbol to add
            
        Returns:
            bool: Success status
        """
        watchlist = self.get_watchlist(username)
        
        # Check if symbol already exists
        if symbol in watchlist:
            logger.info(f"Symbol {symbol} already in watchlist for {username}")
            return True
        
        # Add symbol
        watchlist.append(symbol)
        
        # Save watchlist
        return self._save_watchlist(username, watchlist)
    
    def remove_from_watchlist(self, username, symbol):
        """
        Remove symbol from user's watchlist
        
        Args:
            username (str): Username
            symbol (str): Symbol to remove
            
        Returns:
            bool: Success status
        """
        watchlist = self.get_watchlist(username)
        
        # Check if symbol exists
        if symbol not in watchlist:
            logger.warning(f"Symbol {symbol} not in watchlist for {username}")
            return False
        
        # Remove symbol
        watchlist.remove(symbol)
        
        # Save watchlist
        return self._save_watchlist(username, watchlist)
    
    def clear_watchlist(self, username):
        """
        Clear user's watchlist
        
        Args:
            username (str): Username
            
        Returns:
            bool: Success status
        """
        # Save empty watchlist
        return self._save_watchlist(username, [])
    
    def _save_watchlist(self, username, symbols):
        """
        Save watchlist to file
        
        Args:
            username (str): Username
            symbols (list): Watchlist symbols
            
        Returns:
            bool: Success status
        """
        watchlist_file = self.get_watchlist_file(username)
        
        try:
            with open(watchlist_file, 'w') as f:
                json.dump({'symbols': symbols}, f, indent=4)
            logger.info(f"Watchlist saved for {username}")
            return True
        except Exception as e:
            logger.error(f"Error saving watchlist for {username}: {e}")
            return False
    
    def get_watchlist_data(self, username, data_acquisition):
        """
        Get data for watchlist symbols
        
        Args:
            username (str): Username
            data_acquisition (DataAcquisition): Data acquisition instance
            
        Returns:
            pandas.DataFrame: Data for watchlist symbols
        """
        watchlist = self.get_watchlist(username)
        
        if not watchlist:
            logger.warning(f"Empty watchlist for {username}")
            return pd.DataFrame()
        
        try:
            # Get data for watchlist symbols
            data = data_acquisition.get_data_for_symbols(watchlist, timeframe='1day')
            return data
        except Exception as e:
            logger.error(f"Error getting data for watchlist: {e}")
            return pd.DataFrame()
