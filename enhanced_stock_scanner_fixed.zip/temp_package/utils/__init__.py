"""
Utils package initialization
"""
