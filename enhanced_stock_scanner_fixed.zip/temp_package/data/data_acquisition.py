"""
Data acquisition module wrapper
"""

import sys
import os

# Add the parent directory to the path so we can import the data_acquisition module
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from data_acquisition import DataAcquisition
