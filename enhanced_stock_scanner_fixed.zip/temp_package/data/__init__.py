"""
Data module initialization
"""
